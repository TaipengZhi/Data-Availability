function R = fz_callone(method, x, fs, ff, opts)
% 独立方法分派（供 parfor worker 调用；勿内嵌为局部函数）
persistent threadsSet
if isempty(threadsSet)
    try maxNumCompThreads(1); catch, end   % 每 worker 单线程，4 worker 对应 4 物理核，避免超订阅
    threadsSet=1;
end
switch method
    case 'Proposed', R=fz_pipeline(x,fs,ff,opts,opts.lambda_K);
    case 'B1',       R=fz_baseline_ext('B1',x,fs,ff,opts);
    case 'B6',       R=fz_baseline_ext('B6',x,fs,ff,opts);
    case 'B7_iesf',  R=fz_b7_iesf(x,fs,ff,opts);
    otherwise,       R=fz_baseline(method,x,fs,ff,opts);
end
end
