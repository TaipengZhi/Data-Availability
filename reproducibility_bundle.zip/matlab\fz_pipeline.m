function R = fz_pipeline(x, fs, ff, opts, lambdaK)
% FZ_PIPELINE 冻结 v2.1 完整目标引导测量流水线（七步）。
% 输入 x(时域), fs, ff(由几何+实际转速解析的目标频率), opts=fz_defaults, lambdaK
% 输出 R：选中带、K*/alpha*、模态子集、THNR、fhat、收敛审计等。
% 盲召回步骤不接收 ff；ff 仅用于 THNR 裁决、参数寻优、模态子集与最终频率估计。
if nargin<4||isempty(opts), opts=fz_defaults(); end
if nargin<5, lambdaK=opts.lambda_K; end
x=x(:).'; N=length(x);

%% 步骤② Gini 全盲召回 top-5
[cand,auditBands]=fz_gini_recall(x,fs,opts);
if isempty(cand), error('fz_pipeline:noBand','Gini 召回无可行频带'); end

%% 步骤③ THNR 选带（带通后直接包络，不跑 VMD）
Xfft=fft(x-mean(x),N);
bandTHNR=nan(size(cand,1),1);
for i=1:size(cand,1)
    xb=fz_bandpass_mask(Xfft,N,cand(i,3),cand(i,4),fs);
    [A,fq]=fz_amp_env_spectrum(xb,fs);
    rr=fz_thnr(A,fq,ff,opts);
    bandTHNR(i)=rr.thnr;
end
% 并列取 Gini 名次靠前者（cand 已按 Gini 降序，故取首个达到最大值的）
[mx,~]=max(bandTHNR);
sel=find(abs(bandTHNR-mx)<=opts.tie_db & isfinite(bandTHNR),1,'first');
if isempty(sel), [~,sel]=max(bandTHNR); end
x_narrow=fz_bandpass_mask(Xfft,N,cand(sel,3),cand(sel,4),fs);
selBand=cand(sel,:); bw=selBand(2);

%% 步骤④ 序列化 K-alpha 寻优
opt=fz_sequential_optimize(x_narrow,bw,ff,fs,opts,lambdaK);
Kstar=opt.Kstar; alphaStar=opt.alphaStar;

%% 步骤⑤ 最终 VMD（统一 500 iter）+ 模态子集穷举
[u,~,~,finfo]=fz_vmd(x_narrow,alphaStar,opts.vmd_tau,Kstar,opts.vmd_DC,opts.vmd_init,opts.vmd_tol,opts.vmd_max_iter);
imfs=u.';
convlog=opt.convlog;
convlog{end+1}=struct('stage','final','K',Kstar,'alpha',alphaStar,...
    'iter',finfo.iter,'converged',finfo.converged,'uDiff',finfo.uDiff,...
    'max_iter',finfo.max_iter,'tol',finfo.tol);
selModes=fz_mode_subset_select(imfs,fs,ff,opts);
xrec=selModes.recon; A=selModes.A; fq=selModes.f;

%% 步骤⑥⑦ THNR 与抛物线频率估计
Rthnr=fz_thnr(A,fq,ff,opts);
delta=Rthnr.delta;
[fhat,pkinfo]=fz_parabolic_peak(A,fq,ff,delta);
ef=abs(fhat-ff)/ff*100;

% 未收敛统计
nUnconv=sum(~cellfun(@(c)c.converged,convlog));

R=struct();
R.candidates=cand; R.band_audit=auditBands; R.band_thnr=bandTHNR;
R.selected_band=selBand;            % [fc,bw,fl,fh,gini,level]
R.x_narrow=x_narrow;
R.Kstar=Kstar; R.alphaStar=alphaStar; R.alpha0=opt.alpha0;
R.keep_modes=selModes.keep;
R.xrec=xrec; R.A=A; R.f=fq;
R.thnr=Rthnr.thnr; R.thnr_detail=Rthnr;
R.fhat=fhat; R.peak_info=pkinfo; R.ef_pct=ef;
R.imfs=imfs;
R.convlog=convlog; R.n_unconverged=nUnconv; R.final_converged=finfo.converged;
end
