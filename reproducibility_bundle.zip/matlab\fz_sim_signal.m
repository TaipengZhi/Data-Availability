﻿function s = fz_sim_signal(opts, speed_rpm, snr_dB, noise_type, rngSeed, fix_period)
% fix_period (optional, default true): impulses at t=0, Tf, 2Tf,... (physically correct period).
% Pass false only in fz_period_sensitivity.m to reproduce the legacy off-by-one diagnostic (0, 2Tf, 3Tf,...).
% FZ_SIM_SIGNAL 物理一致的外圈故障仿真（冻结书 §11.1）。
%   x(t)=A*sum_i exp[-beta(t-iTf)] cos[2*pi f_res(t-iTf)] + n(t)
%   - ff=BPFO 由 6205 几何与【实际转速】解析（不再用固定 13 Hz）；
%   - f_res=3600 Hz 结构共振载频；fs=12000 Hz，时长 1 s；
%   noise_type: 'white' | 'pink' | 'impulse'
%               impulse = -10 dB 白噪基底 + 随机冲击(出现率/对数正态幅值/INR 显式)。
% rngSeed: 随机种子（标定集与 Pd 集必须用不同种子）。
% 输出含干净故障分量 fault（供 NRMSE）、合成 x、ff、frot 等。
if nargin>=5 && ~isempty(rngSeed), rng(rngSeed); end
if nargin<6 || isempty(fix_period), fix_period=true; end
% DEFAULT TRUE: impulses at t=0, Tf, 2Tf,... (physically correct periodic fault train).
% Only fz_period_sensitivity.m passes false explicitly to reproduce the legacy off-by-one
% (0, 2Tf, 3Tf,...) for the diagnostic comparison; archived results remain reproducible.
fs=opts.sim_fs; N=round(fs*opts.sim_duration); t=(0:N-1)/fs;
[ff,frot]=fz_kinematic_ff(opts.bearing,speed_rpm,'BPFO');
fres=opts.f_res; beta=opts.damping_ratio*2*pi*fres;
Tf=1/ff;

% --- 故障冲击序列（严格周期） ---
fault=zeros(1,N);
if fix_period
    t0=0;
    while t0 < t(end)
        idx=t>=t0;
        if any(idx)
            i0=find(idx,1);
            tt=(0:N-i0)/fs;
            w=exp(-beta*tt).*cos(2*pi*fres*tt);
            fault(i0:N)=fault(i0:N)+w;
        end
        t0=t0+Tf;
    end
else
    i=1; t0=0;
    while t0 < t(end)
        idx=t>=t0;
        if any(idx)
            i0=find(idx,1);
            tt=(0:N-i0)/fs;
            w=exp(-beta*tt).*cos(2*pi*fres*tt);
            fault(i0:N)=fault(i0:N)+w;
        end
        i=i+1; t0=i*Tf;
    end
end
A=1; fault=A*fault;

% --- 噪声基底（按 SNR 归一化到故障 RMS） ---
targetNoiseRms=rms(fault)/10^(snr_dB/20);
switch lower(noise_type)
    case 'white'
        nbase=randn(1,N); nbase=nbase/rms(nbase)*targetNoiseRms;
        ximp=zeros(1,N);
    case 'pink'
        nbase=pink_noise(N); nbase=nbase/rms(nbase)*targetNoiseRms;
        ximp=zeros(1,N);
    case 'impulse'
        % -10 dB 白噪基底
        baseRms=rms(fault)/10^(-10/20);
        nbase=randn(1,N); nbase=nbase/rms(nbase)*baseRms;
        ximp=random_impulses(N,fs,fault,opts);
    otherwise
        error('未知噪声类型 %s',noise_type);
end
x=fault+nbase+ximp;

s=struct('x',x,'fault',fault,'noise',nbase,'impulse',ximp,'ff',ff,'frot',frot,...
    'fres',fres,'fs',fs,'speed_rpm',speed_rpm,'snr_dB',snr_dB,'noise_type',noise_type,...
    'N',N,'t',t);
end

function n=pink_noise(N)
% 1/f 粉色噪声：频域幅度整形 1/sqrt(f)
w=randn(1,N);
W=fft(w);
nf=ceil((N+1)/2);
scale=ones(1,nf);
k=2:nf; scale(k)=1./sqrt(k-1);
if mod(N,2)==0
    sc=[scale, scale(end-1:-1:2)];
else
    sc=[scale, scale(end:-1:2)];
end
n=real(ifft(W.*sc));
end

function xi=random_impulses(N,fs,fault,opts)
% 随机冲击：出现率 lambda_imp；对数正态幅值(中位 R_med)；载频在分析带内随机；
% 整体缩放使 INR=10^(INR_dB/10)（干扰冲击功率/故障冲击功率）。
xi=zeros(1,N);
rate=opts.impulse_rate; T=N/fs;
M=poisson_count(rate*T);
flo=opts.freq_low; fhi=opts.freq_high_ratio*fs;
betaI=opts.damping_ratio*2*pi;  % 以各自载频计
faultPeak=max(abs(fault));
for k=1:M
    pos=randi(N);
    fcI=flo+(fhi-flo)*rand;
    b=betaI*2*pi*fcI; %#ok<NASGU>
    b=opts.damping_ratio*2*pi*fcI;
    % 对数正态幅值：中位数=R_med*故障峰值
    med=opts.impulse_R_med*faultPeak;
    amp=med*exp(normrnd_safe(0,0.5));
    i0=pos; tt=(0:N-i0)/fs;
    w=amp*exp(-b*tt).*cos(2*pi*fcI*tt);
    xi(i0:N)=xi(i0:N)+w;
end
targetPow=mean(fault.^2)*10^(opts.impulse_INR_dB/10);
if mean(xi.^2)>eps
    xi=xi*sqrt(targetPow/mean(xi.^2));
end
end

function m=poisson_count(mu)
% 简易泊松抽样（不依赖统计工具箱）
L=exp(-mu); k=0; p=1;
while p>L, k=k+1; p=p*rand; end
m=k-1; m=max(m,1);
end

function z=normrnd_safe(mu,sig)
% 标准正态抽样（不依赖统计工具箱），z=mu+sig*Z
u1=max(rand,eps); u2=rand;
Z=sqrt(-2*log(u1))*cos(2*pi*u2);
z=mu+sig*Z;
end
