function fz_period_sensitivity()
% Sensitivity: does the off-by-one impulse timing (0,2Tf,3Tf... vs 0,Tf,2Tf...)
% change detection / frequency / NRMSE at the worst-case -15 dB white noise?
opts=fz_defaults(); fs=opts.sim_fs;
orb_fl=opts.f_res-750; orb_fh=opts.f_res+750;
speeds=[600 1200 1800]; snr=-15; nRep=12;
methods={'Proposed','B3_gini_thnr_no_vmd'}; nM=numel(methods);
fprintf('=== period sensitivity, snr=%g dB, nRep=%d ===\n',snr,nRep);

for sp=1:numel(speeds)
  speed=speeds(sp);
  [ff,~]=fz_kinematic_ff(opts.bearing,speed,'BPFO');
  S=load(fullfile('results_white_full',sprintf('calib_%grpm.mat',speed)));
  Tm=S.Tm; idxP=find(strcmp(S.methods,'Proposed')); idxB=find(strcmp(S.methods,'B3_gini_thnr_no_vmd'));
  thB=zeros(nRep,nM); efB=zeros(nRep,nM); nrB=zeros(nRep,nM);
  thC=zeros(nRep,nM); efC=zeros(nRep,nM); nrC=zeros(nRep,nM);
  sri=find(abs(opts.sim_snr_white-snr)<1e-9,1);
  for r=1:nRep
    seed=70000+sp*100000+sri*10000+r;
    sB=fz_sim_signal(opts,speed,snr,'white',seed,false);
    sC=fz_sim_signal(opts,speed,snr,'white',seed,true);
    % noise waveform is identical: fault construction consumes no RNG draws
    AtrueB=fz_oracle_true(sB.fault,fs,orb_fl,orb_fh,opts.fmax_env);
    AtrueC=fz_oracle_true(sC.fault,fs,orb_fl,orb_fh,opts.fmax_env);
    vB=fz_run_metrics_cell(methods,sB.x,fs,ff,opts,AtrueB,orb_fl,orb_fh);
    vC=fz_run_metrics_cell(methods,sC.x,fs,ff,opts,AtrueC,orb_fl,orb_fh);
    for m=1:nM
      thB(r,m)=vB{m}.thnr; efB(r,m)=vB{m}.ef; nrB(r,m)=vB{m}.nrm;
      thC(r,m)=vC{m}.thnr; efC(r,m)=vC{m}.ef; nrC(r,m)=vC{m}.nrm;
    end
  end
  for m=1:nM
    Tm_m=Tm(m);
    PdB=mean(thB(:,m)>Tm_m); PdC=mean(thC(:,m)>Tm_m);
    fprintf('\n[%d rpm, %s] buggy: Pd=%.2f efMed=%.3f nrmMed=%.4f | corrected: Pd=%.2f efMed=%.3f nrmMed=%.4f | dPd=%.2f dEf=%.4f dNrm=%.4f\n',...
      speed,methods{m},PdB,median(efB(:,m)),median(nrB(:,m)),...
      PdC,median(efC(:,m)),median(nrC(:,m)),...
      PdC-PdB, median(efC(:,m))-median(efB(:,m)), median(nrC(:,m))-median(nrB(:,m)));
  end
end
fprintf('\n=== done ===\n');
end
