function fz_bmin_check()
% FZ_BMIN_CHECK v2.1 参数附录决策试算：仅评估固定最小带宽 Bmin 这一个常数。
% 决策准则（物理，非刷性能）：最细可用带宽必须容纳共振载频两侧前三阶调制边带，
% 即 bw_min >= 6*ff（H=3）。覆盖最严目标 -> 仿真外圈1800rpm(ff=107.5,需645Hz)、
% CWRU BPFI(ff=162.2,需973Hz)。THNR/alpha/未收敛仅作记录，不作为选值依据。
opts0=fz_defaults(); fs=opts0.sim_fs;
fprintf('\n===== Bmin 物理判据(几何) =====\n');
ff_sim=opts0.bearing.Z/2*(1800/60)*(1-opts0.bearing.d/opts0.bearing.D);
ff_bpfi=opts0.bearing.Z/2*(1797/60)*(1+opts0.bearing.d/opts0.bearing.D);
fprintf('仿真外圈1800 ff=%.1f -> 需bw>=%.0f ; CWRU BPFI ff=%.1f -> 需bw>=%.0f\n',...
    ff_sim,6*ff_sim,ff_bpfi,6*ff_bpfi);
for B=[200 500 1000]
    opts=opts0; opts.min_bandwidth=B;
    s=fz_sim_signal(opts,1800,-10,'white',888);
    [cand,aud]=fz_gini_recall(s.x,fs,opts);
    R=fz_pipeline(s.x,fs,s.ff,opts,opts.lambda_K);
    sb=R.selected_band; bw=sb(2);
    need=[s.fres-3*s.ff,s.fres+3*s.ff];
    inside=need(1)>=sb(3)&&need(2)<=sb(4);
    fprintf(['\n--- Bmin=%d --- 有效层级%s 过滤%s\n'],B,mat2str(aud.effective_levels),mat2str(aud.filtered_levels));
    fprintf('top5层级=[%s] 带宽=[%s]\n',num2str(cand(:,6)'),num2str(unique(cand(:,2))'));
    fprintf('入选 bw=%.0f [%g,%g] 边带完整=%d | THNR=%.2f ef=%.2f%% K=%d alpha=%.0f 未收敛=%d/%d\n',...
        bw,sb(3),sb(4),inside,R.thnr,R.ef_pct,R.Kstar,R.alphaStar,R.n_unconverged,numel(R.convlog));
end
fprintf('\n===== Bmin 试算结束 =====\n');
end
