function fz_cwru_test(outdir)
% FZ_CWRU_TEST  CWRU 1/2/3hp 文件级跨负载验证（最小工作量）。
%  0hp 标定的 lambdaK 与 T_{m,c} 锁死；1/2/3hp 只作独立测试。
%  按各文件实际转速算 BPFI/BPFO/BSF；统计先按原始 .mat 文件聚合。
%  不计算 NRMSE（CWRU 无真值）；Pfa 只作描述性结果。
if nargin<1, outdir=fullfile(fileparts(mfilename('fullpath')),'results_cwru'); end
opts=fz_defaults(); fs=12000; win=12000; root='D:\two_stage_vmd_fggi_project\dataset\CRWU';
methods={'Proposed','B2_gini_only','B3_gini_thnr_no_vmd','B4_fixed_vmd','B5_fixed_vmd_thnr','B1','B6'};
cnames={'inner','outer','ball'};
% 载入标定
calibfile=fullfile(outdir,'cwru_calib.mat');
S=load(calibfile); T=S.T; lam=S.lam;
if ~isscalar(lam), error('lambdaK 不是标量: %s',mat2str(lam)); end
opts.lambda_K=lam;
fprintf('载入标定: lambdaK=%.3g, T 7x3\n',lam);
% 负载与转速
loads=[1 2 3]; speed=[1772 1750 1730];
Z=9; d=7.94e-3; D=39.04e-3;
nM=numel(methods);
res=struct();
for li=1:numel(loads)
 ll=loads(li); fr=speed(li)/60;
 ff.inner=Z*fr/2*(1+d/D); ff.outer=Z*fr/2*(1-d/D); ff.ball=D/(2*d)*(1-(d/D)^2)*fr;
 fprintf('\n=== %d hp (转速 %d rpm) BPFI=%.2f BPFO=%.2f BSF=%.2f ===\n',ll,speed(li),ff.inner,ff.outer,ff.ball);
 for ti=1:3
  c=cnames{ti};
  fp=getfile(root,c,ll);
  W=loadcw(fp,fs,win); nWin=size(W,1);
  fprintf('  %s: %s, %d 窗口\n',c,fp,nWin);
  thnrAll=nan(nWin,nM); efAll=nan(nWin,nM); fhatAll=nan(nWin,nM); fcAll=nan(nWin,nM);
  parfor k=1:nWin
   row=nan(1,nM); rowef=nan(1,nM); rowfh=nan(1,nM); rowfc=nan(1,nM);
   for m=1:nM
    try
     Rm=fz_callone(methods{m},W(k,:),fs,ff.(c),opts);
     row(m)=Rm.thnr; rowef(m)=Rm.ef_pct; rowfh(m)=Rm.fhat;
     if isfield(Rm,'final_converged')&&~isempty(Rm.final_converged), rowfc(m)=Rm.final_converged; end
    catch ME
     fprintf('    %s k=%d 错误: %s\n',methods{m},k,ME.message);
    end
   end
   thnrAll(k,:)=row; efAll(k,:)=rowef; fhatAll(k,:)=rowfh; fcAll(k,:)=rowfc;
  end
  for m=1:nM
   key=sprintf('L%d_%s_%s',ll,c,methods{m});
   res.(key)=struct('load',ll,'type',c,'method',methods{m},...
    'file',fp,'nWin',nWin,'ff',ff.(c),...
    'medThnr',median(thnrAll(:,m),'omitnan'),...
    'medEf',median(efAll(:,m),'omitnan'),...
    'medFhat',median(fhatAll(:,m),'omitnan'),...
    'detectRate',mean(thnrAll(:,m)>T(m,ti),'omitnan'),...
    'failRate',mean(fcAll(:,m)==0,'omitnan'));
  end
  fprintf('  %s 文件级: ',c);
  for m=1:nM, fprintf('%s medThnr=%.2f medEf=%.3f%% det=%.0f%% fail=%.0f%% | ',methods{m},...
    median(thnrAll(:,m),'omitnan'),median(efAll(:,m),'omitnan'),...
    100*mean(thnrAll(:,m)>T(m,ti),'omitnan'),100*mean(fcAll(:,m)==0,'omitnan')); end
  fprintf('\n');
 end
 % 正常文件 Pfa（描述性：三目标最大 THNR > 对应阈值）
 fpN=fullfile(root,'Normal Baseline',sprintf('normal_%d.mat',ll));
 if exist(fpN,'file')
  WN=loadcw(fpN,fs,win); nN=size(WN,1);
  pfaCnt=zeros(1,nM);
  parfor k=1:nN
   row=nan(1,nM);
   for m=1:nM
    try
     thmax=-inf;
     for ci=1:3
      Rm=fz_callone(methods{m},WN(k,:),fs,ff.(cnames{ci}),opts);
      thmax=max(thmax,Rm.thnr);
     end
     row(m)=thmax;
    catch, end
   end
   pfaCnt=pfaCnt+(row>max(T,[],2)');
  end
  fprintf('  normal_%d: %d 窗口, 描述性Pfa: ',ll,nN);
  for m=1:nM, fprintf('%s=%.0f%% ',methods{m},100*pfaCnt(m)/nN); end
  fprintf('\n');
 end
end
save(fullfile(outdir,'cwru_test.mat'),'res','methods','loads','speed','T','lam','-v7.3');
fprintf('\n已存 cwru_test.mat\n');
end

function fp=getfile(root,c,ll)
switch c
 case 'inner', fp=fullfile(root,'12k Drive End Bearing Fault Data','Inner Race','0007',sprintf('IR007_%d.mat',ll));
 case 'ball',  fp=fullfile(root,'12k Drive End Bearing Fault Data','Ball','0007',sprintf('B007_%d.mat',ll));
 case 'outer', fp=fullfile(root,'12k Drive End Bearing Fault Data','Outer Race','Centered','0007',sprintf('OR007@6_%d.mat',ll));
end
end
function W=loadcw(fp,fs,win)
 if ~exist(fp,'file'), error('缺文件 %s',fp); end
 ld=load(fp); vn=fieldnames(ld); di=find(contains(vn,'_DE_time'),1);
 sig=ld.(vn{di}); sig=sig(:)'; n=floor(length(sig)/win);
 W=zeros(n,win);
 for k=1:n, W(k,:)=sig((k-1)*win+1:k*win); end
end
