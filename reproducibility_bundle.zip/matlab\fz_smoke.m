function S = fz_smoke(nCal, nFault, nNormalTest)
% FZ_SMOKE 检测链冒烟（冻结书 §16.2）：1200 rpm / -10 dB 白噪，parfor 4 worker。
%   nCal 个无故障【标定】样本 -> 方法特异阈值 T_{m,BPFO}（95 分位）
%   nNormalTest 个【独立】无故障样本 -> 经验 Pfa
%   nFault 个故障样本 -> Pd、ef、THNR；统计 VMD 未收敛数与最终分解收敛率。
% 20 样本下 Pfa 只能以 5% 步长变化，冒烟只验证阈值程序/分位数/方法特异阈值正确性。
if nargin<1||isempty(nCal), nCal=20; end
if nargin<2||isempty(nFault), nFault=20; end
if nargin<3||isempty(nNormalTest), nNormalTest=20; end
opts=fz_defaults(); fs=opts.sim_fs; N=round(fs*opts.sim_duration);
methods={'Proposed','B2_gini_only','B3_gini_thnr_no_vmd','B4_fixed_vmd','B5_fixed_vmd_thnr'};
nM=numel(methods);
speed=1200; snr=-10;
[ff,~]=fz_kinematic_ff(opts.bearing,speed,'BPFO');
s0=fz_sim_signal(opts,speed,snr,'white',1); noiseRms=rms(s0.noise);

if isempty(gcp('nocreate')), try, parpool('processes',4); catch, end; end

%% 单样本计时（串行，1 次）
fprintf('\n===== 单样本计时(Proposed) =====\n');
sT=fz_sim_signal(opts,speed,snr,'white',2);
tic; rT=runOne(sT.x,fs,ff,opts); tOne=toc;
fprintf('Proposed 单样本耗时 %.2f s, THNR=%.2f dB, ef=%.2f%% K=%d 未收敛=%d 最终收敛=%d\n',...
    tOne,rT(1,1),rT(2,1),rT(4,1),rT(3,1),rT(5,1)>0);

%% 标定（无故障）
fprintf('\n===== 标定 %d 个无故障样本 =====\n',nCal);
cal=nan(nCal,nM);
parfor i=1:nCal
    rng(1000+i); x=noiseRms*randn(1,N);
    tmp=runOne(x,fs,ff,opts);
    cal(i,:)=tmp(1,:);
end
T=nan(1,nM);
for m=1:nM, T(m)=fz_calibrate_threshold(cal(:,m),opts); end

%% 独立无故障验证（Pfa）
fprintf('\n===== 独立无故障验证 %d 个 =====\n',nNormalTest);
nt=nan(nNormalTest,nM);
parfor i=1:nNormalTest
    rng(2000+i); x=noiseRms*randn(1,N);
    tmp=runOne(x,fs,ff,opts);
    nt(i,:)=tmp(1,:);
end
Pfa=mean(bsxfun(@gt,nt,T),1);

%% 故障样本（Pd / ef / 未收敛 / 最终收敛）
fprintf('\n===== 故障 %d 个 =====\n',nFault);
ft=nan(nFault,nM); ef=nan(nFault,nM); uncMat=zeros(nFault,nM); convMat=zeros(nFault,nM);
parfor i=1:nFault
    s=fz_sim_signal(opts,speed,snr,'white',3000+i);
    rr=runOne(s.x,fs,ff,opts);   % 行: thnr,ef,nUnc,K,finalConv
    ft(i,:)=rr(1,:); ef(i,:)=rr(2,:); uncMat(i,:)=rr(3,:); convMat(i,:)=rr(5,:);
end
nUnc=sum(uncMat,1); fConv=sum(convMat>0,1);

fprintf('\n================ 冒烟结果 (1200rpm,-10dB) ================\n');
fprintf('%-24s %8s %8s %9s %9s %8s %10s\n','方法','阈值T','THNR均','ef中位%','Pd%','Pfa%','最终收敛%');
for m=1:nM
    fprintf('%-24s %8.2f %8.2f %9.2f %9.1f %8.1f %10.1f  未收敛%d\n',methods{m},T(m),...
        mean(ft(:,m),'omitnan'),median(ef(:,m),'omitnan'),100*mean(ft(:,m)>T(m),1),100*Pfa(m),...
        100*fConv(m)/nFault,nUnc(m));
end
fprintf('注: %d样本下Pfa步长=%.1f%%\n',nNormalTest,100/nNormalTest);
fprintf('=========================================================\n');

S=struct('methods',{methods},'T',T,'cal',cal,'normalTest',nt,'fault',ft,...
    'ef',ef,'Pd',mean(bsxfun(@gt,ft,T),1),'Pfa',Pfa,'nUnconverged',nUnc,...
    'finalConv',fConv,'tOne',tOne,'ff',ff,'noiseRms',noiseRms);
save(fullfile(fileparts(mfilename('fullpath')),'fz_smoke_result.mat'),'S');
end

function rr=runOne(x,fs,ff,opts)
% 返回 5×nM：行1 THNR，行2 ef%，行3 未收敛次数，行4 K(仅Proposed)，行5 最终收敛(1/0)
methods={'Proposed','B2_gini_only','B3_gini_thnr_no_vmd','B4_fixed_vmd','B5_fixed_vmd_thnr'};
rr=nan(5,numel(methods));
rp=fz_pipeline(x,fs,ff,opts,opts.lambda_K);
rr(1,1)=rp.thnr; rr(2,1)=rp.ef_pct; rr(3,1)=rp.n_unconverged; rr(4,1)=rp.Kstar; rr(5,1)=rp.final_converged;
for m=2:numel(methods)
    rb=fz_baseline(methods{m},x,fs,ff,opts);
    rr(1,m)=rb.thnr; rr(2,m)=rb.ef_pct; rr(3,m)=rb.n_unconverged;
    rr(4,m)=rb.Kstar; rr(5,m)=isfield(rb,'convlog')&&~isempty(rb.convlog)&&rb.convlog{end}.converged;
end
end
