%% fz_check_iter_equivalence.m
%  200 vs 500 次 VMD 迭代等价性检查（简化版）
%  在 MATLAB 命令窗口运行：
%    >> cd D:\two_stage_vmd_fggi_project\frozen_v21
%    >> fz_check_iter_equivalence
%
%  粉噪/冲击各 10 个固定种子，对比 200 vs 500 迭代下
%  Proposed、B4、B5 的 THNR、ef、fhat、K、收敛状态
%  预计 15-20 分钟

clear; clc;
addpath('D:\two_stage_vmd_fggi_project\frozen_v21');
cd('D:\two_stage_vmd_fggi_project\frozen_v21');

opts200 = fz_defaults(); opts200.vmd_max_iter = 200;
opts500 = fz_defaults(); opts500.vmd_max_iter = 500;
fs = opts200.sim_fs; N = round(fs*opts200.sim_duration);
speed = 1200; snr = -10;
[ff, ~] = fz_kinematic_ff(opts200.bearing, speed, 'BPFO');

cmp_methods = {'Proposed','B4_fixed_vmd','B5_fixed_vmd_thnr'};
noise_types = {'pink','impulse'};
nRep = 10;

fprintf('==================================================\n');
fprintf(' 200 vs 500 迭代等价性检查\n');
fprintf(' speed=%g  snr=%g  ff=%.2f Hz  nRep=%d/噪声\n', speed, snr, ff, nRep);
fprintf('==================================================\n');

for ni = 1:numel(noise_types)
    ntype = noise_types{ni};
    fprintf('\n========== %s ==========\n', ntype);

    for mi = 1:numel(cmp_methods)
        mname = cmp_methods{mi};
        thnr200 = nan(nRep,1); thnr500 = nan(nRep,1);
        ef200 = nan(nRep,1);   ef500 = nan(nRep,1);
        k200 = nan(nRep,1);    k500 = nan(nRep,1);
        fc200 = nan(nRep,1);   fc500 = nan(nRep,1);

        for r = 1:nRep
            seed = 100000 + ni*100000 + r;
            s = fz_sim_signal(opts200, speed, snr, ntype, seed);

            R200 = fz_callone(mname, s.x, fs, ff, opts200);
            R500 = fz_callone(mname, s.x, fs, ff, opts500);

            thnr200(r) = R200.thnr; thnr500(r) = R500.thnr;
            ef200(r) = R200.ef_pct; ef500(r) = R500.ef_pct;
            if isfield(R200,'K') && ~isempty(R200.K), k200(r)=R200.K; end
            if isfield(R500,'K') && ~isempty(R500.K), k500(r)=R500.K; end
            if isfield(R200,'final_converged'), fc200(r)=R200.final_converged; end
            if isfield(R500,'final_converged'), fc500(r)=R500.final_converged; end
        end

        dTH = abs(thnr200 - thnr500);
        dEF = abs(ef200 - ef500);
        kMatch = sum(k200 == k500, 'omitnan');

        fprintf('\n  [%s]\n', mname);
        fprintf('    THNR 200: mean=%.2f  |  500: mean=%.2f\n', mean(thnr200), mean(thnr500));
        fprintf('    ef   200: mean=%.4f%% |  500: mean=%.4f%%\n', mean(ef200), mean(ef500));
        fprintf('    最大THNR差=%.3f dB  最大ef差=%.4f%%  K一致=%d/%d\n', ...
            max(dTH), max(dEF), kMatch, nRep);
        if any(~isnan(fc200)), fprintf('    收敛率 200=%.0f%%  500=%.0f%%\n', ...
            100*mean(fc200), 100*mean(fc500)); end
    end
end

fprintf('\n==================================================\n');
fprintf(' 判定标准:\n');
fprintf('  最大THNR差 <0.5 dB, ef差 <0.05%, K一致>=8/10 -> 等价\n');
fprintf('  任一超限 -> 需用500重跑 Proposed/B4/B5\n');
fprintf('==================================================\n');
