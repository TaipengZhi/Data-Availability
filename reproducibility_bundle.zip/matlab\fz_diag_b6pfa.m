function fz_diag_b6pfa(outdir)
% 诊断 B6@1200rpm 验证集 Pfa=19% 的来源
if nargin<1, outdir=fullfile(fileparts(mfilename('fullpath')),'results_white_full'); end
S=load(fullfile(outdir,'calib_1200rpm.mat'));
methods=S.methods;
fprintf('=== B6 Pfa 诊断 (1200 rpm) ===\n');
fprintf('methods: '); fprintf('%s ',methods{:}); fprintf('\n');
b=7;  % B6 列
cal=S.calTh(:,b); val=S.valTh(:,b); Tm=S.Tm(b);
fprintf('\nB6 标定集 THNR: mean=%.3f median=%.3f std=%.3f p95(Tm)=%.3f\n',...
    mean(cal),median(cal),std(cal),Tm);
fprintf('B6 验证集 THNR: mean=%.3f median=%.3f std=%.3f\n',mean(val),median(val),std(val));
fprintf('验证集超过 Tm=%.3f 的个数 = %d / %d (Pfa=%.2f)\n',Tm,sum(val>Tm),numel(val),mean(val>Tm));
fprintf('标定集超过 Tm 的个数 = %d (应≈5/100=95分位定义)\n',sum(cal>Tm));
% 标定 vs 验证分布是否一致（KS 直觉：均值差）
fprintf('\n标定-验证均值差 = %.3f dB（>0.3 提示分布漂移）\n',mean(val)-mean(cal));
% 对照其他方法
fprintf('\n各方法标定mean / 验证mean / Pfa:\n');
for m=1:numel(methods)
    fprintf('  %-9s calMean=%.3f valMean=%.3f Pfa=%.2f\n',methods{m},...
        mean(S.calTh(:,m)),mean(S.valTh(:,m)),S.Pfa(m));
end
fprintf('\n=== 诊断结束 ===\n');
end
