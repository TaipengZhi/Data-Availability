function [An,flim] = fz_oracle_true(fault,fs,fl,fh,fmax_env)
% 干净故障分量过 oracle 带 -> 0-fmax_env Hz 幅值包络谱(2-范数归一化)
N=numel(fault); X=fft(fault-mean(fault),N);
xb=fz_bandpass_mask(X,N,fl,fh,fs);
[A,fq]=fz_amp_env_spectrum(xb,fs);
m=fq<=fmax_env; A=A(m); fq=fq(m);
n=norm(A,2);
if n>0, An=A/n; else, An=A; end
flim=fq;
end
