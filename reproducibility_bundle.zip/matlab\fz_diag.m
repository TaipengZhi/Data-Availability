opts=fz_defaults; fs=opts.sim_fs; N=round(fs*opts.sim_duration); ff=71.7;
rng(1); x=randn(1,N);
ms={'Proposed','B2_gini_only','B3_gini_thnr_no_vmd','B4_fixed_vmd','B5_fixed_vmd_thnr','B1','B6'};
for k=1:numel(ms)
    try
        fprintf('start %s\n',ms{k}); tic;
        R=callone(ms{k},x,fs,ff,opts);
        fprintf('  ok thnr=%.2f ef=%.3f nunc=%g\n',R.thnr,R.ef_pct,R.n_unconverged); toc;
    catch e
        fprintf('  ERR %s: %s\n',ms{k},e.message);
    end
end
function R=callone(method,x,fs,ff,opts)
switch method
    case 'Proposed', R=fz_pipeline(x,fs,ff,opts,opts.lambda_K);
    case 'B1',       R=fz_baseline_ext('B1',x,fs,ff,opts);
    case 'B6',       R=fz_baseline_ext('B6',x,fs,ff,opts);
    otherwise,       R=fz_baseline(method,x,fs,ff,opts);
end
end
