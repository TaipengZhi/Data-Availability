# -*- coding: utf-8 -*-
"""Rebuild Fig3 (Pd heatmap) and Fig4 (ef/NRMSE curves) adding B8 IESFOgram."""
import os
import numpy as np
import scipy.io as sio
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = r"D:\two_stage_vmd_fggi_project\frozen_v21\results_white_full"
ROOT8 = r"D:\two_stage_vmd_fggi_project\frozen_v21\results_white_iesfog"
OUT = r"C:\Users\Zhi\Doubao\chats\2026-09-13\new-chat-1\v4_stats"
SPEEDS = [600, 1200, 1800]; SNRS = [-15, -10, -5, 0, 5]

# ---- load main methods ----
d0 = sio.loadmat(os.path.join(ROOT, "white_1200rpm_-10dB.mat"), squeeze_me=True)
methods = [str(m) for m in np.atleast_1d(d0["methods"])]
midx = {m: i for i, m in enumerate(methods)}

def loadm(sp, snr):
    return sio.loadmat(os.path.join(ROOT, f"white_{sp}rpm_{snr}dB.mat"), squeeze_me=True)

# ---- B8 loader ----
def loadb8(sp, snr):
    return sio.loadmat(os.path.join(ROOT8, f"b8_{sp}rpm_{snr}dB.mat"), squeeze_me=True)
Tm8 = {sp: float(sio.loadmat(os.path.join(ROOT8, f"b8_calib_{sp}rpm.mat"),
       squeeze_me=True)["Tm"]) for sp in SPEEDS}

# ============ Fig 3: Pd heatmap, 5 panels ============
panels = ["Proposed", "B3_gini_thnr_no_vmd", "B1", "B6", "B8"]
labels = ["Proposed", "B3", "B1", "B6", "B8 (IESFOgram)"]
maps = {}
for p in panels:
    M = np.full((3, 5), np.nan)
    for si, sp in enumerate(SPEEDS):
        for ni, sn in enumerate(SNRS):
            if p == "B8":
                d = loadb8(sp, sn); M[si, ni] = np.mean(d["thnr"].ravel() > Tm8[sp])
            else:
                d = loadm(sp, sn); M[si, ni] = float(np.atleast_1d(d["Pd"])[midx[p]])
    maps[p] = M

fig, axes = plt.subplots(1, 5, figsize=(18, 3.3))
im = None
for ax, p, lab in zip(axes, panels, labels):
    M = maps[p]
    im = ax.imshow(M, cmap="RdYlGn", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(range(5)); ax.set_xticklabels([f"{s}" for s in SNRS])
    ax.set_yticks(range(3)); ax.set_yticklabels(SPEEDS)
    ax.set_xlabel("SNR (dB)"); ax.set_title(lab, fontsize=11)
    for i in range(3):
        for j in range(5):
            ax.text(j, i, f"{M[i,j]:.2f}", ha="center", va="center", fontsize=8.5, color="black")
axes[0].set_ylabel("Shaft speed (r/min)")
fig.subplots_adjust(right=0.92, wspace=0.20)
cax = fig.add_axes([0.935, 0.16, 0.012, 0.70])
cb = fig.colorbar(im, cax=cax); cb.set_label("$P_d$")
fig.savefig(os.path.join(OUT, "fig_pd_heatmap.png"), dpi=600, bbox_inches="tight")
fig.savefig(os.path.join(OUT, "fig_pd_heatmap.pdf"), bbox_inches="tight")
plt.close(fig)
print("wrote fig_pd_heatmap (5 panels incl B8)")

# ============ Fig 4: ef / NRMSE curves, add B8 ============
PLOT = [("Proposed", "#1b7837", "o"),
        ("B3_gini_thnr_no_vmd", "#762a83", "s"),
        ("B2_gini_only", "#5aae61", "^"),
        ("B1", "#d73027", "D"),
        ("B6", "#4575b4", "v"),
        ("B8", "#ff7f00", "P")]
LAB = {"Proposed":"Proposed","B3_gini_thnr_no_vmd":"B3","B2_gini_only":"B2",
       "B1":"B1","B6":"B6","B8":"B8 (IESFOgram)"}

fig, axes = plt.subplots(3, 2, figsize=(11, 11), sharex=True)
for ri, sp in enumerate(SPEEDS):
    for mname, col, mk in PLOT:
        emed, eq1, eq3, nmed, nq1, nq3 = [np.zeros(len(SNRS)) for _ in range(6)]
        for j, sn in enumerate(SNRS):
            if mname == "B8":
                d = loadb8(sp, sn)
                e = d["ef"].ravel(); n = d["nrm"].ravel()
            else:
                d = loadm(sp, sn); mi = midx[mname]
                e = d["ef"][:, mi]; n = d["nrm"][:, mi]
            emed[j], eq1[j], eq3[j] = np.median(e), *np.percentile(e, [25, 75])
            nmed[j], nq1[j], nq3[j] = np.median(n), *np.percentile(n, [25, 75])
        axes[ri,0].plot(SNRS, emed, color=col, marker=mk, ms=4, label=LAB[mname])
        axes[ri,0].fill_between(SNRS, eq1, eq3, color=col, alpha=0.10)
        axes[ri,1].plot(SNRS, nmed, color=col, marker=mk, ms=4, label=LAB[mname])
        axes[ri,1].fill_between(SNRS, nq1, nq3, color=col, alpha=0.10)
    axes[ri,0].set_yscale("log")
    axes[ri,0].set_ylabel(f"{sp} r/min\n$e_f$ (%)")
    axes[ri,1].set_ylabel("NRMSE$_{env}$")
    axes[ri,0].grid(alpha=.3, which="both"); axes[ri,1].grid(alpha=.3)
axes[0,0].set_title("Frequency error (median, IQR)")
axes[0,1].set_title("Envelope-spectrum NRMSE (median, IQR)")
for ax in axes[-1,:]: ax.set_xlabel("SNR (dB)")
axes[0,1].legend(fontsize=8, loc="upper right")
fig.tight_layout()
fig.savefig(os.path.join(OUT, "fig_ef_nrm_curves.png"), dpi=600, bbox_inches="tight")
fig.savefig(os.path.join(OUT, "fig_ef_nrm_curves.pdf"), bbox_inches="tight")
plt.close(fig)
print("wrote fig_ef_nrm_curves (incl B8)")
