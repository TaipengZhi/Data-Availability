function fz_rescue_downstream(outdir)
% FZ_RESCUE_DOWNSTREAM  对3个超J*候选补算下游：ef/NRMSE_env/检测判定，与正式解比较。
if nargin<1, outdir=fullfile(fileparts(mfilename('fullpath')),'results_white_full'); end
opts=fz_defaults(); fs=opts.sim_fs; lambdaK=opts.lambda_K; fmax=opts.fmax_env;
orb_fl=opts.f_res-750; orb_fh=opts.f_res+750;
L=load(fullfile(outdir,'rescue_results.mat')); rec=L.rec;
fprintf('\n===== 3个超J*候选下游复算 =====\n');
for n=1:numel(rec)
 for j=1:numel(rec(n).beatStar)
  if ~rec(n).beatStar(j), continue; end
  speed=rec(n).speed; snr=rec(n).snr; r=rec(n).r;
  sp=find(opts.sim_speeds==speed); sri=find(opts.sim_snr_white==snr);
  [ff,~]=fz_kinematic_ff(opts.bearing,speed,'BPFO');
  % 标定阈值 Tm
  S=load(fullfile(outdir,sprintf('calib_%grpm.mat',speed)));
  Tm1=S.Tm(1);  % Proposed=第1列
  % 复现信号与正式解
  seed=70000+sp*100000+sri*10000+r;
  s=fz_sim_signal(opts,speed,snr,'white',seed);
  R=fz_pipeline(s.x,fs,ff,opts,lambdaK);
  % oracle真值
  Atrue=fz_oracle_true(s.fault,fs,orb_fl,orb_fh,fmax);
  % ---- 正式解下游 ----
  [Are_c,~]=fz_amp_env_spectrum(R.xrec,fs);
  [Ar_c,~]=fz_norm_env_half(Are_c,fs,fmax); Lc=min(numel(Ar_c),numel(Atrue));
  nrm_c=norm(Ar_c(1:Lc)-Atrue(1:Lc))/norm(Atrue(1:Lc));
  det_c=R.thnr>Tm1;
  % ---- 救援解下游 ----
  Kr=rec(n).candK(j); aratio=rec(n).candAlphaRatio(j);
  alpha_r=aratio*R.alpha0;
  [u,~,~,info]=fz_vmd(R.x_narrow,alpha_r,opts.vmd_tau,Kr,opts.vmd_DC,opts.vmd_init,opts.vmd_tol,2000);
  imfs=u.'; out=fz_mode_subset_select(imfs,fs,ff,opts);
  delta=R.thnr_detail.delta;
  [fh_r,~]=fz_parabolic_peak(out.A,out.f,ff,delta);
  ef_r=abs(fh_r-ff)/ff*100;
  [Are_r,~]=fz_amp_env_spectrum(out.recon,fs);
  [Ar_r,~]=fz_norm_env_half(Are_r,fs,fmax); Lr=min(numel(Ar_r),numel(Atrue));
  nrm_r=norm(Ar_r(1:Lr)-Atrue(1:Lr))/norm(Atrue(1:Lr));
  det_r=out.thnr>Tm1;
  fprintf('\n工况 %grpm/%gdB r=%g (救援K=%g, a/a0=%.2f):\n',speed,snr,r,Kr,aratio);
  fprintf('  正式解: thnr=%.3f ef=%.4f%% NRMSE=%.4f 检测=%d (Tm=%.3f)\n',...
     R.thnr,R.ef_pct,nrm_c,det_c,Tm1);
  fprintf('  救援解: thnr=%.3f ef=%.4f%% NRMSE=%.4f 检测=%d\n',out.thnr,ef_r,nrm_r,det_r);
  if det_c~=det_r, fprintf('  >>> 检测判定翻转! <<<\n'); else, fprintf('  检测判定不变\n'); end
  clear R s u imfs out;
 end
end
fprintf('\n===== 下游复算完成 =====\n');
end
