﻿function res = fz_run_pressure(outdir)
% FZ_RUN_PRESSURE  精简压力测试（串行稳定版）：1200rpm, -10dB。
%   粉噪50标定+50验证+50故障；随机冲击同。500 iter（与论文协议一致）。
opts=fz_defaults(); fs=opts.sim_fs;
opts.vmd_max_iter=500;
speed=1200; snr=-10; nRep=50; nCal=50; nVal=50;
if nargin<1||isempty(outdir)
    outdir=fullfile(fileparts(mfilename('fullpath')),'results_pressure');
end
if ~exist(outdir,'dir'), mkdir(outdir); end
methods={'Proposed','B2_gini_only','B3_gini_thnr_no_vmd','B4_fixed_vmd','B5_fixed_vmd_thnr','B1','B6'};
nM=numel(methods);
N=round(fs*opts.sim_duration);
orb_fl=opts.f_res-750; orb_fh=opts.f_res+750;
[ff,~]=fz_kinematic_ff(opts.bearing,speed,'BPFO');
fprintf('=== 压力测试(串行): speed=%g, ff=%.2f, snr=%g, nRep=%d, nCal=%d, nVal=%d ===\n',...
    speed,ff,snr,nRep,nCal,nVal);

res=struct();
for ni=1:2
    if ni==1, ntype='pink'; else, ntype='impulse'; end
    fprintf('\n----- %s -----\n',ntype);

    calfile=fullfile(outdir,sprintf('calib_%s.mat',ntype));
    if exist(calfile,'file')
        S=load(calfile); Tm=S.Tm; Pfa=S.Pfa; PfaCI=S.PfaCI;
        fprintf('  加载标定: Pfa=%s\n',mat2str(round(Pfa,3)));
    else
        calTh=nan(nCal,nM);
        for i=1:nCal
            t0=tic; seed=80000+ni*100000+i;
            x=fz_pure_noise(ntype,N,fs,opts,seed);
            calTh(i,:)=fz_run_thnr_row(methods,x,fs,ff,opts);
            fprintf('  cal %d/%d %.1fs\n',i,nCal,toc(t0));
        end
        Tm=quantile_rank(calTh);
        valTh=nan(nVal,nM);
        for i=1:nVal
            t0=tic; seed=90000+ni*100000+i;
            x=fz_pure_noise(ntype,N,fs,opts,seed);
            valTh(i,:)=fz_run_thnr_row(methods,x,fs,ff,opts);
            fprintf('  val %d/%d %.1fs\n',i,nVal,toc(t0));
        end
        Pfa=mean(bsxfun(@gt,valTh,Tm),1);
        PfaCI=nan(nM,2);
        for m=1:nM, PfaCI(m,:)=wilson(sum(valTh(:,m)>Tm(m)),nVal); end
        save(calfile,'ntype','ff','Tm','Pfa','PfaCI','calTh','valTh','methods');
        fprintf('  标定完成: Pfa=%s\n',mat2str(round(Pfa,3)));
    end

    chk=fullfile(outdir,sprintf('pressure_%s_%grpm_%gdB.mat',ntype,speed,snr));
    if exist(chk,'file')
        fprintf('  跳过故障集\n');
    else
        ef=nan(nRep,nM); thnr=nan(nRep,nM); nrm=nan(nRep,nM); fc=nan(nRep,nM);
        for r=1:nRep
            t0=tic; seed=100000+ni*100000+r;
            s=fz_sim_signal(opts,speed,snr,ntype,seed);
            [Atrue,~]=fz_oracle_true(s.fault,fs,orb_fl,orb_fh,opts.fmax_env);
            vals=fz_run_metrics_cell(methods,s.x,fs,ff,opts,Atrue,orb_fl,orb_fh);
            for m=1:nM
                thnr(r,m)=vals{m}.thnr; ef(r,m)=vals{m}.ef; nrm(r,m)=vals{m}.nrm; fc(r,m)=vals{m}.fc;
            end
            fprintf('  fault %d/%d %.1fs\n',r,nRep,toc(t0));
        end
        Pd=mean(bsxfun(@gt,thnr,Tm),1);
        save(chk,'speed','snr','ff','Tm','Pfa','PfaCI','thnr','ef','nrm','fc','Pd','methods','ntype');
        fprintf('  Pd=%s efMed=%s done\n',mat2str(round(Pd,2)),mat2str(round(median(ef,1),3)));
    end

    S=load(chk);
    res.(ntype)=struct('speed',speed,'snr',snr,'ff',ff,'Tm',Tm,'Pfa',Pfa,'PfaCI',PfaCI,...
        'thnr',S.thnr,'ef',S.ef,'nrm',S.nrm,'fc',S.fc,'Pd',S.Pd,'methods',{methods});
end
save(fullfile(outdir,'pressure_summary.mat'),'res','methods','speed','snr');
fprintf('\n=== 压力测试完成: %s ===\n',outdir);
end

function T=quantile_rank(X)
[n,nm]=size(X); k=ceil(0.95*n); T=nan(1,nm);
for j=1:nm, s=sort(X(:,j)); T(j)=s(k); end
end

function ci=wilson(k,n)
z=1.96; p_hat=k/n; den=1+z^2/n;
ctr=(p_hat+z^2/(2*n))/den;
hw=z*sqrt(p_hat*(1-p_hat)/n+z^2/(4*n^2))/den;
ci=[ctr-hw,ctr+hw];
end
