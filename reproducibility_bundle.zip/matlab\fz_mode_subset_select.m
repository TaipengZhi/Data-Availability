function out = fz_mode_subset_select(imfs, fs, ff, opts)
% FZ_MODE_SUBSET_SELECT 模态子集【穷举】选择（冻结书 §3 步骤⑤，取代 ESNR greedy/FGGI 初筛）。
% 枚举全部 2^K-1 个非空子集，取重构 THNR 最大者；K<=5（<=31 子集）保证全局最优。
% 并列规则：THNR 差 <0.01 dB 视为并列，取模态数更少者（再并列取字典序，保证可复现）。
if nargin<4, opts=fz_defaults(); end
K=size(imfs,1);
candIdx=1:K;
if K==1
    recon=imfs(1,:); [A,fq]=fz_amp_env_spectrum(recon,fs); R=fz_thnr(A,fq,ff,opts);
    out=struct('keep',1,'thnr',R.thnr,'recon',recon,'A',A,'f',fq,'n_subsets',1);
    return;
end
if K<=6
    bestT=-inf; bestMask=[]; scores=nan(2^K-1,1);
    for code=1:(2^K-1)
        mask=false(1,K); tmp=code;
        for b=1:K, mask(b)=bitand(tmp,1)==1; tmp=bitshift(tmp,-1); end
        recon=sum(imfs(mask,:),1);
        [A,fq]=fz_amp_env_spectrum(recon,fs);
        R=fz_thnr(A,fq,ff,opts);
        t=R.thnr; scores(code)=t;
        if ~isfinite(t), continue; end
        nM=nnz(mask);
        if isempty(bestMask) || t>bestT+opts.tie_db ...
                || (abs(t-bestT)<=opts.tie_db && nM<nnz(bestMask))
            bestT=t; bestMask=mask;
        end
    end
    keep=candIdx(bestMask);
    recon=sum(imfs(bestMask,:),1);
    [A,fq]=fz_amp_env_spectrum(recon,fs);
    out=struct('keep',keep,'thnr',bestT,'recon',recon,'A',A,'f',fq,'n_subsets',2^K-1,'scores',scores);
    return;
end
% --- K>6 兜底：贪心反向选择（冻结主流程 K<=5 不触发；保留以防调用方误用）---
cur=1:K;
[A,fq]=fz_amp_env_spectrum(sum(imfs(cur,:),1),fs); curT=fz_thnr(A,fq,ff,opts).thnr;
improved=true;
while improved && numel(cur)>1
    improved=false; trialT=curT; rm=0;
    for i=1:numel(cur)
        tr=cur; tr(i)=[];
        [At,ft]=fz_amp_env_spectrum(sum(imfs(tr,:),1),fs); tt=fz_thnr(At,ft,ff,opts).thnr;
        if tt>trialT+opts.tie_db, trialT=tt; rm=i; improved=true; end
    end
    if improved, cur(rm)=[]; curT=trialT; end
end
keep=cur; recon=sum(imfs(keep,:),1); [A,fq]=fz_amp_env_spectrum(recon,fs);
out=struct('keep',keep,'thnr',curT,'recon',recon,'A',A,'f',fq,'n_subsets',NaN,'scores',[]);
end
