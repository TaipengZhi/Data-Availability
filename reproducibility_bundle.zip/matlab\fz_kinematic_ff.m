function [ff, frot] = fz_kinematic_ff(bearing, speed_rpm, target)
% FZ_KINEMATIC_FF 由几何参数与【实际转速】解析目标故障重复频率。
% bearing : .Z .d .D .theta(rad)
% speed_rpm: 实际转速 rpm
% target  : 'BPFI' | 'BPFO' | 'BSF'
% 返回 ff(Hz), frot(Hz)=n/60
frot = speed_rpm/60;
Z = bearing.Z; d = bearing.d; D = bearing.D; th = bearing.theta;
switch upper(target)
    case 'BPFI'
        ff = Z/2*frot*(1 + (d/D)*cos(th));
    case 'BPFO'
        ff = Z/2*frot*(1 - (d/D)*cos(th));
    case 'BSF'
        ff = D/(2*d)*frot*(1 - ((d/D)*cos(th))^2);
    otherwise
        error('fz_kinematic_ff:unknownTarget','未知目标类型 %s',target);
end
end
