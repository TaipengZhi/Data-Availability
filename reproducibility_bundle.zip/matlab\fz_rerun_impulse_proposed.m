%% fz_rerun_impulse_proposed.m
%  用 500 iter 重跑冲击噪声下的 Proposed（标定50+验证50+故障50）
%  B2/B3/B4/B5/B1/B6 已证明 200/500 等价，保留原值不重跑
%  在 MATLAB 命令窗口运行：
%    >> cd D:\two_stage_vmd_fggi_project\frozen_v21
%    >> fz_rerun_impulse_proposed
%  预计约 100 分钟

clear; clc;
addpath('D:\two_stage_vmd_fggi_project\frozen_v21');
cd('D:\two_stage_vmd_fggi_project\frozen_v21');

opts = fz_defaults();            % 默认 500 iter
fs = opts.sim_fs; N = round(fs*opts.sim_duration);
speed = 1200; snr = -10; nRep = 50; nCal = 50; nVal = 50;
[ff, ~] = fz_kinematic_ff(opts.bearing, speed, 'BPFO');
orb_fl = opts.f_res - 750;
orb_fh = opts.f_res + 750;
outdir = fullfile(pwd, 'results_pressure');

fprintf('==================================================\n');
fprintf(' 重跑冲击 Proposed (500 iter)\n');
fprintf(' speed=%g  ff=%.2f  snr=%g  vmd_max_iter=%d\n', speed, ff, snr, opts.vmd_max_iter);
fprintf('==================================================\n');

%% 1. 加载现有标定，保留 B2-B6 的 Tm
calOld = load(fullfile(outdir, 'calib_impulse.mat'));
Tm_old = calOld.Tm;
Pfa_old = calOld.Pfa;
PfaCI_old = calOld.PfaCI;
methods = calOld.methods;
nM = numel(methods);
mP = find(strcmp(methods, 'Proposed'));
fprintf('保留 B2-B6 阈值，重算 Proposed (index=%d)\n', mP);

%% 2. 重跑 Proposed 标定 50
fprintf('\n--- Proposed 标定 50 ---\n');
calThP = nan(nCal, 1);
for i = 1:nCal
    t0 = tic;
    seed = 90000 + 2*100000 + i;
    x = fz_pure_noise('impulse', N, fs, opts, seed);
    R = fz_callone('Proposed', x, fs, ff, opts);
    calThP(i) = R.thnr;
    fprintf('  标定 %d/%d (%.1fs)\n', i, nCal, toc(t0));
end
Tm_new = Tm_old;
Tm_new(mP) = quantile_rank(calThP);

%% 3. 重跑 Proposed 验证 50
fprintf('\n--- Proposed 验证 50 ---\n');
valThP = nan(nVal, 1);
for i = 1:nVal
    t0 = tic;
    seed = 80000 + 2*100000 + i;
    x = fz_pure_noise('impulse', N, fs, opts, seed);
    R = fz_callone('Proposed', x, fs, ff, opts);
    valThP(i) = R.thnr;
    fprintf('  验证 %d/%d (%.1fs)\n', i, nVal, toc(t0));
end
Pfa_new = Pfa_old;
Pfa_new(mP) = mean(valThP > Tm_new(mP));
PfaCI_new = PfaCI_old;
PfaCI_new(mP,:) = wilson(sum(valThP > Tm_new(mP)), nVal);

fprintf('Proposed 新 Tm=%.3f  新 Pfa=%.2f  CI=[%.2f, %.2f]\n', ...
    Tm_new(mP), Pfa_new(mP), PfaCI_new(mP,1), PfaCI_new(mP,2));

%% 4. 保存更新后的标定（保留其他方法 calTh/valTh）
calNew = calOld;
calNew.Tm = Tm_new;
calNew.Pfa = Pfa_new;
calNew.PfaCI = PfaCI_new;
% calTh/valTh 是 50×7 矩阵，只更新 Proposed 列
if isfield(calOld,'calTh') && ~isempty(calOld.calTh)
    calNew.calTh(:,mP) = calThP;
end
if isfield(calOld,'valTh') && ~isempty(calOld.valTh)
    calNew.valTh(:,mP) = valThP;
end
calNew.vmd_max_iter = 500;
save(fullfile(outdir, 'calib_impulse.mat'), '-struct', 'calNew');
fprintf('已更新 calib_impulse.mat\n');

%% 5. 重跑 Proposed 故障 50
fprintf('\n--- Proposed 故障 50 ---\n');
thnrP = nan(nRep, 1); efP = nan(nRep, 1);
nrmP = nan(nRep, 1); fcP = nan(nRep, 1);
for r = 1:nRep
    t0 = tic;
    seed = 100000 + 2*100000 + r;
    s = fz_sim_signal(opts, speed, snr, 'impulse', seed);
    [Atrue,~] = fz_oracle_true(s.fault, fs, orb_fl, orb_fh, opts.fmax_env);
    vals = fz_run_metrics_cell({'Proposed'}, s.x, fs, ff, opts, Atrue, orb_fl, orb_fh);
    thnrP(r) = vals{1}.thnr;
    efP(r)   = vals{1}.ef;
    nrmP(r)  = vals{1}.nrm;
    if isfield(vals{1},'fc') && ~isempty(vals{1}.fc)
        fcP(r) = vals{1}.fc;
    end
    fprintf('  故障 %d/%d: THNR=%.2f ef=%.3f%% nrm=%.3f (%.1fs)\n', ...
        r, nRep, thnrP(r), efP(r), nrmP(r), toc(t0));
end

%% 6. 合并到现有结果（其他方法列保留）
chkOld = load(fullfile(outdir, 'pressure_impulse_1200rpm_-10dB.mat'));
thnrAll = chkOld.thnr; efAll = chkOld.ef;
nrmAll = chkOld.nrm; fcAll = chkOld.fc;

thnrAll(:,mP) = thnrP;
efAll(:,mP)   = efP;
nrmAll(:,mP)  = nrmP;
fcAll(:,mP)   = fcP;

Pd_new = mean(thnrAll > Tm_new, 1);

%% 7. 保存
chkNew = chkOld;
chkNew.thnr = thnrAll;
chkNew.ef = efAll;
chkNew.nrm = nrmAll;
chkNew.fc = fcAll;
chkNew.Tm = Tm_new;
chkNew.Pfa = Pfa_new;
chkNew.PfaCI = PfaCI_new;
chkNew.Pd = Pd_new;
chkNew.vmd_max_iter_proposed = 500;
save(fullfile(outdir, 'pressure_impulse_1200rpm_-10dB.mat'), '-struct', 'chkNew');

%% 8. 汇总
fprintf('\n==================================================\n');
fprintf(' 冲击 Proposed (500 iter) 重跑完成\n');
fprintf('==================================================\n');
fprintf('Proposed: Pd=%.2f  efMed=%.3f%%  nrmMed=%.3f  Pfa=%.2f\n', ...
    Pd_new(mP), median(efP), median(nrmP), Pfa_new(mP));
fprintf('\n全部方法 Pd: %s\n', mat2str(round(Pd_new,2)));
fprintf('全部方法 efMed: %s\n', mat2str(round(median(efAll,1),3)));
fprintf('全部方法 nrmMed: %s\n', mat2str(round(median(nrmAll,1),3)));

%% ===== 局部函数 =====
function T = quantile_rank(X)
    X = X(~isnan(X));
    n = numel(X);
    k = ceil(0.95*n);
    s = sort(X);
    T = s(k);
end

function ci = wilson(k, n)
    z = 1.96; p_hat = k/n; den = 1 + z^2/n;
    ctr = (p_hat + z^2/(2*n))/den;
    hw  = z*sqrt(p_hat*(1-p_hat)/n + z^2/(4*n^2))/den;
    ci  = [ctr-hw, ctr+hw];
end

function y = normalize(A)
    A = A(:);
    nrm = norm(A);
    if nrm > 0, y = A / nrm; else y = A; end
end
