﻿function res = fz_run_uncertainty(outdir)
% FZ_RUN_UNCERTAINTY  最小不确定度分析：1200rpm/-10dB, 20 固定白噪样本, Proposed。
%   转速输入误差: -1%, 0, +1%；几何参数误差: -0.5%, 0, +0.5%。
%   完整重跑目标引导选择链（不是事后平移评价频率）。
%   输出: ef（vs 真实 ff）、THNR（算法输出）、检测判定（vs 白噪标定 Tm）。
opts=fz_defaults(); fs=opts.sim_fs;
opts.vmd_max_iter=500;  % 与论文/主实验一致
speed=1200; snr=-10; nRep=20;
if nargin<1||isempty(outdir)
    outdir=fullfile(fileparts(mfilename('fullpath')),'results_uncertainty');
end
if ~exist(outdir,'dir'), mkdir(outdir); end

% 真实运动学参数
b=opts.bearing;
[ff_true,~]=fz_kinematic_ff(b,speed,'BPFO');
fprintf('=== 不确定度: speed=%g rpm, ff_true=%.3f Hz, nRep=%d ===\n',speed,ff_true,nRep);

% 加载白噪主实验 1200rpm 标定阈值（Proposed 列=第1列）
whiteDir=fullfile(fileparts(mfilename('fullpath')),'results_white_full');
W=load(fullfile(whiteDir,'calib_1200rpm.mat'));
Tm_Proposed=W.Tm(1);  % Proposed 是 methods{1}
fprintf('白噪标定 Tm(Proposed)=%.3f dB\n',Tm_Proposed);

% 参数扰动网格
dSpeed=[-0.01 0 0.01]; dGeom=[-0.005 0 0.005];
speedLbl={'-1%','0','+1%'}; geomLbl={'-0.5%','0','+0.5%'};

res=struct();
for si=1:3
  for gi=1:3
    speed_in=speed*(1+dSpeed(si));
    b_in=b; b_in.d=b.d*(1+dGeom(gi)); b_in.D=b.D;  % 只扰动 d，D 固定（d/D 不再恒定）
    [ff_in,~]=fz_kinematic_ff(b_in,speed_in,'BPFO');
    spNames={'sp1','sp2','sp3'}; spMixed={'spm1','spz','spp1'}; geNames={'gem05','ge2','gep05'};
    if gi==2
      tag=[spNames{si} '_' geNames{gi}];
    else
      tag=[spMixed{si} '_' geNames{gi}];
    end
    fprintf('\n--- 转速%s 几何%s: ff_in=%.3f Hz (偏差%.2f%%) ---\n',...
      speedLbl{si},geomLbl{gi},ff_in,100*(ff_in/ff_true-1));

    ef=nan(nRep,1); thnr=nan(nRep,1); det=nan(nRep,1); fc=nan(nRep,1);
    parfor r=1:nRep
      seed=70000+2*100000+2*10000+r;  % 与白噪主实验 1200rpm/-10dB 相同种子
      s=fz_sim_signal(opts,speed,snr,'white',seed);
      R=fz_callone('Proposed',s.x,fs,ff_in,opts);
      ef(r)=abs(R.fhat-ff_true)/ff_true*100;  % ef vs 真实 ff（非 ff_in）
      thnr(r)=R.thnr;
      det(r)=R.thnr>Tm_Proposed;
      fc(r)=R.final_converged;
    end
    res.(tag)=struct('speed_in',speed_in,'ff_in',ff_in,'dSpeed',dSpeed(si),'dGeom',dGeom(gi),...
      'ef',ef,'thnr',thnr,'det',det,'fc',fc,...
      'efMed',median(ef),'thnrMed',median(thnr),'detRate',mean(det),'fcFail',mean(fc==0));
    fprintf('  efMed=%.3f%% thnrMed=%.2f detRate=%.0f%% fcFail=%.0f%%\n',...
      median(ef),median(thnr),100*mean(det),100*mean(fc==0));
  end
end
save(fullfile(outdir,'uncertainty.mat'),'res','ff_true','Tm_Proposed','speed','snr','nRep',...
  'dSpeed','dGeom','speedLbl','geomLbl');
fprintf('\n=== 不确定度分析完成: %s ===\n',outdir);
end
