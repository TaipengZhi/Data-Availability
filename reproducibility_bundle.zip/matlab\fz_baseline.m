function R = fz_baseline(method, x, fs, ff, opts)
% FZ_BASELINE 冻结基线（冻结书 §10）。所有方法共用相同窗/NFFT/分析范围/抛物线频率估计。
%   'B2_gini_only'        盲：Gini top1 单带 + 包络，无 VMD
%   'B3_gini_thnr_no_vmd' 目标型：Gini top5 + THNR 选带，无 VMD
%   'B4_fixed_vmd'        盲：Gini top1 带通 + Fixed VMD(K=4,alpha=2000) + 峭度选单模
%   'B5_fixed_vmd_thnr'   目标型：Gini top1 带通 + Fixed VMD + THNR 子集穷举
% B1(Fast Kurtogram)、B6(Original two-stage VMD) 全量阶段接入，冒烟先覆盖 B2-B5 与 Proposed。
if nargin<4, opts=fz_defaults(); end
x=x(:).'; N=length(x); Xfft=fft(x-mean(x),N);
[cand,audit]=fz_gini_recall(x,fs,opts);
R=struct('method',method,'band_audit',audit);
convlog={};

    function envout=env_of(xb)
        [A,fq]=fz_amp_env_spectrum(xb,fs);
        rr=fz_thnr(A,fq,ff,opts);
        [fh,pi_]=fz_parabolic_peak(A,fq,ff,rr.delta);
        envout=struct('A',A,'f',fq,'thnr',rr.thnr,'fhat',fh,'pinfo',pi_,'ef',abs(fh-ff)/ff*100);
    end
    function xb=passband(row)
        xb=fz_bandpass_mask(Xfft,N,cand(row,3),cand(row,4),fs);
    end

switch method
    case 'B2_gini_only'
        xb=passband(1); e=env_of(xb);
        R.selected_band=cand(1,:); R.Kstar=NaN; R.alphaStar=NaN; R.keep_modes=NaN;
        R.xrec=xb; R.A=e.A; R.f=e.f; R.thnr=e.thnr; R.fhat=e.fhat; R.ef_pct=e.ef;
    case 'B3_gini_thnr_no_vmd'
        bt=nan(size(cand,1),1);
        for i=1:size(cand,1), bt(i)=env_of(passband(i)).thnr; end
        [mx,~]=max(bt); sel=find(abs(bt-mx)<=opts.tie_db & isfinite(bt),1,'first');
        if isempty(sel), [~,sel]=max(bt); end
        xb=passband(sel); e=env_of(xb);
        R.band_thnr=bt; R.selected_band=cand(sel,:);
        R.Kstar=NaN; R.alphaStar=NaN; R.keep_modes=NaN;
        R.xrec=xb; R.A=e.A; R.f=e.f; R.thnr=e.thnr; R.fhat=e.fhat; R.ef_pct=e.ef;
    case {'B4_fixed_vmd','B5_fixed_vmd_thnr'}
        xb=passband(1);
        K=4; a=2000;
        [u,~,~,info]=fz_vmd(xb,a,opts.vmd_tau,K,opts.vmd_DC,opts.vmd_init,opts.vmd_tol,opts.vmd_max_iter);
        imfs=u.';
        convlog{end+1}=struct('stage','fixed_vmd','K',K,'alpha',a,'iter',info.iter,...
            'converged',info.converged,'uDiff',info.uDiff,...
            'max_iter',info.max_iter,'tol',info.tol);
        if strcmp(method,'B4_fixed_vmd')
            kt=zeros(1,K);
            for m=1:K, kt(m)=kurt_fast(imfs(m,:)); end
            [~,keep]=max(kt);
            recon=imfs(keep,:); keepModes=keep;
        else
            sm=fz_mode_subset_select(imfs,fs,ff,opts);
            recon=sm.recon; keepModes=sm.keep;
        end
        e=env_of(recon);
        R.selected_band=cand(1,:); R.Kstar=K; R.alphaStar=a; R.keep_modes=keepModes;
        R.xrec=recon; R.A=e.A; R.f=e.f; R.thnr=e.thnr; R.fhat=e.fhat; R.ef_pct=e.ef;
    otherwise
        error('未知基线 %s',method);
end
R.convlog=convlog;
R.n_unconverged=sum(~cellfun(@(c)c.converged,convlog));
if isempty(convlog), R.final_converged=NaN;   % B2/B3 无 VMD，不适用
else, R.final_converged=convlog{end}.converged;  % B4/B5 唯一一次 VMD 即最终解
end
end

function k=kurt_fast(x)
x=x(:)-mean(x); v=mean(x.^2);
if v<eps, k=0; else, k=mean(x.^4)/v^2; end
end
