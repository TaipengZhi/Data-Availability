function fz_cwru_inventory()
% FZ_CWRU_INVENTORY  CWRU 文件级数据清单探针（不跑算法，只核对数据归属）。
%  冻结范围：DE驱动端、故障尺寸0.007"、12kHz、非重叠1s窗口。
%  0hp=标定集；1/2/3hp=独立测试集。
root='D:\two_stage_vmd_fggi_project\dataset\CRWU';
fs=12000; win=12000;  % 1s 非重叠窗口
loads=[0 1 2 3];
speed=[1797 1772 1750 1730];  % rpm, 按 CWRU 官方
% 6205-2RS 几何
Z=9; d=7.94e-3; D=39.04e-3;
types={'inner','outer','ball','normal'};
fprintf('\n%-8s %-4s %-7s %-5s %-7s %-8s %-6s %-8s %s\n',...
 'file','load','type','size','fs(Hz)','rpm','win','split','ff(Hz) BPFI/BPFO/BSF');
for li=1:4
 ll=loads(li); fr=speed(li)/60;
 bpfi=Z*fr/2*(1+d/D);
 bpfo=Z*fr/2*(1-d/D);
 bsf=D/(2*d)*(1-(d/D)^2)*fr;
 for ti=1:4
  ty=types{ti};
  switch ty
   case 'normal', fn=sprintf('normal_%d.mat',ll); fp=fullfile(root,'Normal Baseline',fn);
   case 'inner', fn=sprintf('IR007_%d.mat',ll); fp=fullfile(root,'12k Drive End Bearing Fault Data','Inner Race','0007',fn);
   case 'ball', fn=sprintf('B007_%d.mat',ll); fp=fullfile(root,'12k Drive End Bearing Fault Data','Ball','0007',fn);
   case 'outer', fn=sprintf('OR007@6_%d.mat',ll); fp=fullfile(root,'12k Drive End Bearing Fault Data','Outer Race','Centered','0007',fn);
  end
  if ~exist(fp,'file'), fprintf('%-30s 缺文件\n',fp); continue; end
  ld=load(fp); vn=fieldnames(ld); di=find(contains(vn,'_DE_time'),1);
  sig=ld.(vn{di}); nwin=floor(length(sig)/win);
  split=ternary(ll==0,'calib','test');
  switch ty
   case 'inner', ff=bpfi; case 'outer', ff=bpfo; case 'ball', ff=bsf; otherwise, ff=0;
  end
  fprintf('%-8s %-4d %-7s %-5s %-7d %-8d %-6d %-8s %.2f\n',...
   fn,ll,ty,'0.007',fs,speed(li),nwin,split,ff);
 end
end
fprintf('\n转速对应: 0hp=1797 1hp=1772 2hp=1750 3hp=1730 rpm\n');
fprintf('标定集=0hp全部4类；测试集=1/2/3hp。窗口非重叠，统计先按文件聚合。\n');
end
function o=ternary(c,a,b), if c, o=a; else, o=b; end; end
