function fz_cwru_picklambda(outdir)
% 复用 T，重跑 lambdaK 网格选择（修正 minlex 返回值）。
if nargin<1, outdir=fullfile(fileparts(mfilename('fullpath')),'results_cwru'); end
opts=fz_defaults(); fs=12000; win=12000; root='D:\two_stage_vmd_fggi_project\dataset\CRWU';
S=load(fullfile(outdir,'cwru_calib.mat')); T=S.T; ffC=S.ffC;
cnames=fieldnames(ffC);
winF=struct();
winF.inner=loadcw(fullfile(root,'12k Drive End Bearing Fault Data','Inner Race','0007','IR007_0.mat'),fs,win);
winF.outer=loadcw(fullfile(root,'12k Drive End Bearing Fault Data','Outer Race','Centered','0007','OR007@6_0.mat'),fs,win);
winF.ball =loadcw(fullfile(root,'12k Drive End Bearing Fault Data','Ball','0007','B007_0.mat'),fs,win);
lgrid=[0 .1 .25 .5 1 2]; rec=nan(numel(lgrid),3);
for li=1:numel(lgrid)
 opt=opts; opt.lambda_K=lgrid(li);
 pd=[]; ef=[]; kk=[];
 for ci=1:3
  c=cnames{ci}; W=winF.(c);
  for k=1:size(W,1)
   R=fz_pipeline(W(k,:),fs,ffC.(c),opt,lgrid(li));
   pd=[pd; R.thnr>T(1,ci)]; ef=[ef; R.ef_pct]; kk=[kk; R.Kstar];
  end
 end
 rec(li,:)=[mean(pd), median(ef), mean(kk)];
 fprintf('lambda=%g: Pd=%.3f medEf=%.4f meanK=%.2f\n',lgrid(li),rec(li,1),rec(li,2),rec(li,3));
end
score=[-rec(:,1), rec(:,2), rec(:,3), -lgrid(:)];
[~,bi]=sortrows(score); bi=bi(1); lam=lgrid(bi);
fprintf('选定 lambdaK=%.3g (Pd=%.3f medEf=%.4f meanK=%.2f)\n',lam,rec(bi,1),rec(bi,2),rec(bi,3));
save(fullfile(outdir,'cwru_calib.mat'),'T','lam','ffC','methods','win','fs','Z','d','D','-append');
fprintf('已更新 cwru_calib.mat (lam=%g)\n',lam);
end
function W=loadcw(fp,fs,win)
 ld=load(fp); vn=fieldnames(ld); di=find(contains(vn,'_DE_time'),1);
 sig=ld.(vn{di}); sig=sig(:)'; n=floor(length(sig)/win); W=zeros(n,win);
 for k=1:n, W(k,:)=sig((k-1)*win+1:k*win); end
end
