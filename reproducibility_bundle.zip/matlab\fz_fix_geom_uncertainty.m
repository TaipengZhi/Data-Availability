%% fz_fix_geom_uncertainty.m
%  修正几何参数扰动：只扰动 d（滚珠直径），D 不变
%  补跑 6 组合（3转速 × 2几何水平）× 20样本 = 120次
%  在 MATLAB 命令窗口运行：
%    >> cd D:\two_stage_vmd_fggi_project\frozen_v21
%    >> fz_fix_geom_uncertainty
%  预计约 60-90 分钟

clear; clc;
addpath('D:\two_stage_vmd_fggi_project\frozen_v21');
cd('D:\two_stage_vmd_fggi_project\frozen_v21');

opts = fz_defaults();
fs = opts.sim_fs;
speed = 1200; snr = -10; nRep = 20;
b = opts.bearing;
[ff_true, ~] = fz_kinematic_ff(b, speed, 'BPFO');

% 加载已有结果
old = load(fullfile('results_uncertainty','uncertainty.mat'));
res = old.res;

% 加载白噪标定阈值
W = load(fullfile('results_white_full','calib_1200rpm.mat'));
Tm = W.Tm(1);

fprintf('==================================================\n');
fprintf(' 修正几何扰动（只扰动 d，D 不变）\n');
fprintf(' ff_true=%.3f  Tm=%.3f\n', ff_true, Tm);
fprintf('==================================================\n');

% 预生成 20 个固定信号
SIG = cell(nRep,1);
for r = 1:nRep
    seed = 70000 + 2*100000 + 2*10000 + r;
    s = fz_sim_signal(opts, speed, snr, 'white', seed);
    SIG{r} = s.x;
end

dSpeed = [-0.01, 0, +0.01];
dGeom = [-0.005, +0.005];   % 只跑两个非零几何水平（0已有结果）
speedLbl = {'-1%','0','+1%'};
geomLbl = {'-0.5%','+0.5%'};
spTag = {'m1','z','p1'};  % 转速标签
geTag = {'m05','p05'};   % 几何标签

for si = 1:3
    for gi = 1:2
        speed_in = speed * (1 + dSpeed(si));
        b_in = b;
        b_in.d = b.d * (1 + dGeom(gi));   % 只扰动 d
        [ff_in, ~] = fz_kinematic_ff(b_in, speed_in, 'BPFO');
        tag = sprintf('sp%s_ge%s', spTag{si}, geTag{gi});

        fprintf('\n----- 转速%s 几何%s: ff_in=%.3f Hz (偏差%+.2f%%) -----\n', ...
            speedLbl{si}, geomLbl{gi}, ff_in, 100*(ff_in/ff_true-1));

        ef = nan(nRep,1); thnr = nan(nRep,1); det = nan(nRep,1);
        for r = 1:nRep
            t0 = tic;
            R = fz_callone('Proposed', SIG{r}, fs, ff_in, opts);
            ef(r) = abs(R.fhat - ff_true)/ff_true*100;
            thnr(r) = R.thnr;
            det(r) = R.thnr > Tm;
            fprintf('  r=%2d: fhat=%6.2f  ef=%6.3f%%  THNR=%6.2f  det=%d (%.1fs)\n', ...
                r, R.fhat, ef(r), thnr(r), det(r), toc(t0));
        end

        res.(tag) = struct('speed_in',speed_in,'ff_in',ff_in, ...
            'dSpeed',dSpeed(si),'dGeom',dGeom(gi), ...
            'ef',ef,'thnr',thnr,'det',det, ...
            'efMed',median(ef),'thnrMed',median(thnr),'detRate',mean(det));
        fprintf('  >> efMed=%.3f%%  thnrMed=%.2f  detRate=%.0f%%\n', ...
            median(ef), median(thnr), 100*mean(det));
    end
end

% 保存
save(fullfile('results_uncertainty','uncertainty.mat'), 'res', 'ff_true', ...
    'Tm_Proposed', 'speed', 'snr', 'nRep', '-append');

% 汇总表
fprintf('\n==================================================\n');
fprintf(' 修正后不确定度汇总\n');
fprintf('==================================================\n');
fprintf('%-10s %-10s %-12s %-12s %-10s %-10s\n', ...
    '转速误差','几何误差','ff_in(Hz)','efMed(%)','THNRMed','detRate');
for si = 1:3
    for gi = 1:3
        if gi == 2
            tag = sprintf('sp%s_ge0', spTag{si});
        else
            gidx = gi - (gi>2);
            tag = sprintf('sp%s_ge%s', spTag{si}, geTag{gidx});
        end
        if isfield(res, tag)
            d = res.(tag);
            glbl = '0';
            if gi==1, glbl=geomLbl{1}; end
            if gi==3, glbl=geomLbl{2}; end
            fprintf('%-10s %-10s %-12.3f %-12.3f %-10.2f %-10.0f%%\n', ...
                speedLbl{si}, glbl, d.ff_in, d.efMed, d.thnrMed, 100*d.detRate);
        end
    end
end
fprintf('\n已保存: results_uncertainty\\uncertainty.mat\n');
