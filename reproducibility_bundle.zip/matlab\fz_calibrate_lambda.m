function [lamStar, tbl] = fz_calibrate_lambda(normalSigs, faultSigs, fs, ff, opts)
% FZ_CALIBRATE_LAMBDA  仅用 0hp/标定集数据标定模态数惩罚 lambda_K（冻结收口规则）。
%   严格优先级： Pd 最高 -> (Pd差<=1pp) ef 中位小 -> 平均 K 小 -> 较大 lambda_K。
%   不得使用任何测试/1-3hp 数据；全量运行器若见 lambda_K 仍为占位 0.5 且无本标定记录，应报错退出。
%
% 输入:
%   normalSigs : 0hp 正常信号 (nN x N 矩阵 或 1 x nN cell)
%   faultSigs  : 0hp 故障信号 (nF x N 矩阵 或 1 x nF cell)
%   fs, ff     : 采样率, 目标频率
%   opts       : fz_defaults()
% 输出:
%   lamStar    : 选定 lambda_K
%   tbl        : 每个候选 lambda 的 (T,Pd,efMed,Kmean,thrTable) 表
if nargin<5||isempty(opts), opts=fz_defaults(); end
normalSigs=sig_cell(normalSigs); faultSigs=sig_cell(faultSigs);
lams=opts.lambda_grid;
nN=numel(normalSigs); nF=numel(faultSigs);

nL=numel(lams);
T=nan(nL,1); Pd=nan(nL,1); efMed=nan(nL,1); Kmean=nan(nL,1);
thr=cell(nL,1);
for li=1:nL
    lam=lams(li);
    % 正常样本 THNR（用于该 lambda 下的阈值）
    tn=nan(nN,1);
    for i=1:nN
        Rn=fz_pipeline(normalSigs{i},fs,ff,opts,lam); tn(i)=Rn.thnr;
    end
    T(li)=fz_calibrate_threshold(tn,opts);
    % 故障样本 THNR / ef / K
    tf=nan(nF,1); efv=nan(nF,1); kv=nan(nF,1);
    for i=1:nF
        Rf=fz_pipeline(faultSigs{i},fs,ff,opts,lam);
        tf(i)=Rf.thnr; efv(i)=Rf.ef_pct; kv(i)=Rf.Kstar;
    end
    thr{li}=tn;
    Pd(li)=mean(tf>T(li));
    efMed(li)=median(efv,'omitnan');
    Kmean(li)=mean(kv,'omitnan');
    fprintf('  lambda=%.3f  T=%.2f  Pd=%.3f  efMed=%.3f%%  Kmean=%.2f\n',...
        lam,T(li),Pd(li),efMed(li),Kmean(li));
end

% --- 严格优先级选优 ---
[bestPd,~]=max(Pd);
cand=find(Pd>=bestPd-0.01);                 % 与最高 Pd 差 <=1pp
[~,i1]=min(efMed(cand)); c1=cand(i1);
if numel(cand)==1, c=c1;
else
    sub=cand(abs(efMed(cand)-efMed(c1))<=1e-9);
    [~,i2]=min(Kmean(sub)); c=sub(i2);
    if numel(sub)>1
        [~,i3]=max(lams(sub)); c=sub(i3);   % 仍并列 -> 较大 lambda_K
    end
end
lamStar=lams(c);
fprintf(">>> 选定 lambda_K = %.3f (Pd=%.3f, efMed=%.3f%%, Kmean=%.2f)\n",...
    lamStar,Pd(c),efMed(c),Kmean(c));

tbl=table(lams(:),T,Pd,efMed,Kmean,'VariableNames',...
    {'lambda','T','Pd','efMed_pct','Kmean'});
end

function c=sig_cell(s)
if isnumeric(s)
    if isvector, c={s(:).'};
    else, c=num2cell(s,2).'; c=cellfun(@(r)r(:).',c,'UniformOutput',false); end
else
    c=s;
end
end
