function res = fz_run_white(speeds, snrs, nRep, nCal, nVal, outdir)
% FZ_RUN_WHITE  全量白噪主实验 runner（f_res=3600, oracle 带方法无关）。
%   仿真专用阈值：按 speed 分别用独立纯噪声标定/验证集，不用 CWRU 阈值。
%   主指标：ef、固定 Pfa=5% 下 Pd；主包络指标 NRMSE_env（统一 oracle 真值）。
%   断点：每 speed×snr 切片存盘，已完成则跳过；配置哈希+种子清单落盘。
%   注意：parfor 内只调用独立函数文件，不用脚本局部函数。
opts=fz_defaults(); fs=opts.sim_fs;
if nargin<1||isempty(speeds), speeds=opts.sim_speeds; end
if nargin<2||isempty(snrs), snrs=opts.sim_snr_white; end
if nargin<3||isempty(nRep), nRep=opts.sim_repeats; end
if nargin<4||isempty(nCal), nCal=100; end
if nargin<5||isempty(nVal), nVal=100; end
if nargin<6||isempty(outdir)
    outdir=fullfile(fileparts(mfilename('fullpath')),'results_white');
end
if ~exist(outdir,'dir'), mkdir(outdir); end
methods={'Proposed','B2_gini_only','B3_gini_thnr_no_vmd','B4_fixed_vmd','B5_fixed_vmd_thnr','B1','B6'};
nM=numel(methods);
orb_fl=opts.f_res-750; orb_fh=opts.f_res+750;   % oracle 带：中心=opts.f_res，带宽1500
N=round(fs*opts.sim_duration);
if isempty(gcp('nocreate')), try parpool('processes',4); catch, end; end

cfg=struct('speeds',speeds,'snrs',snrs,'nRep',nRep,'nCal',nCal,'nVal',nVal,...
    'f_res',opts.f_res,'oracle_band',[orb_fl orb_fh],'Bmin',opts.min_bandwidth,...
    'alpha_range',[opts.alpha_min_ratio opts.alpha_max_ratio],'alpha_num',opts.alpha_num,...
    'K_list',opts.K_list,'lambda_K',opts.lambda_K,'fmax_env',opts.fmax_env);
cfg.config_hash=cfg_hash(cfg);
save(fullfile(outdir,'config_white.mat'),'cfg');

res=struct();
for sp=1:numel(speeds)
    speed=speeds(sp);
    [ff,~]=fz_kinematic_ff(opts.bearing,speed,'BPFO');
    fprintf('\n###### speed=%g rpm, ff(BPFO)=%.2f Hz ######\n',speed,ff);

    % (a)(b) 独立纯噪声标定/验证 -> Tm、Pfa、Wilson CI（按 speed 存盘复用）
    calibfile=fullfile(outdir,sprintf('calib_%grpm.mat',speed));
    if exist(calibfile,'file')
        S=load(calibfile); Tm=S.Tm; Pfa=S.Pfa; PfaCI=S.PfaCI;
        fprintf('  加载已存标定: %s (Pfa=%s)\n',calibfile,mat2str(round(Pfa,3)));
    else
        calTh=nan(nCal,nM);
        parfor i=1:nCal
            rng(50000+sp*100000+i); x=randn(1,N);
            calTh(i,:)=fz_run_thnr_row(methods,x,fs,ff,opts);
        end
        Tm=quantile_rank(calTh);

        valTh=nan(nVal,nM);
        parfor i=1:nVal
            rng(60000+sp*100000+i); x=randn(1,N);
            valTh(i,:)=fz_run_thnr_row(methods,x,fs,ff,opts);
        end
        Pfa=mean(bsxfun(@gt,valTh,Tm),1);
        PfaCI=nan(nM,2);
        for m=1:nM, PfaCI(m,:)=wilson(sum(valTh(:,m)>Tm(m)),nVal); end
        save(calibfile,'speed','ff','Tm','Pfa','PfaCI','calTh','valTh','methods');
        fprintf('  标定完成并存盘: Pfa=%s\n',mat2str(round(Pfa,3)));
    end

    % (c) 故障集：每 SNR × nRep
    for sri=1:numel(snrs)
        snr=snrs(sri);
        chunk=fullfile(outdir,sprintf('white_%grpm_%gdB.mat',speed,snr));
        if exist(chunk,'file')
            fprintf('  跳过已完成: %s\n',chunk); continue;
        end
        ef=nan(nRep,nM); thnr=nan(nRep,nM); nrm=nan(nRep,nM); nunc=nan(nRep,nM); fc=nan(nRep,nM);
        parfor r=1:nRep
            seed=70000+sp*100000+sri*10000+r;
            s=fz_sim_signal(opts,speed,snr,'white',seed);
            [Atrue,~]=fz_oracle_true(s.fault,fs,orb_fl,orb_fh,opts.fmax_env);
            vals=fz_run_metrics_cell(methods,s.x,fs,ff,opts,Atrue,orb_fl,orb_fh);
            for m=1:nM
                thnr(r,m)=vals{m}.thnr; ef(r,m)=vals{m}.ef; nrm(r,m)=vals{m}.nrm; nunc(r,m)=vals{m}.nunc; fc(r,m)=vals{m}.fc;
            end
        end
        Pd=mean(bsxfun(@gt,thnr,Tm),1);
        save(chunk,'speed','snr','ff','Tm','Pfa','PfaCI','thnr','ef','nrm','nunc','fc','Pd','methods');
        fprintf('  %g dB: Pd=%s efMed=%s done\n',snr,mat2str(round(Pd,2)),mat2str(round(median(ef,1),3)));
    end
    if sp==1, res=struct('speed',{},'ff',{},'Tm',{},'Pfa',{},'PfaCI',{}); end
    res(sp).speed=speed; res(sp).ff=ff; res(sp).Tm=Tm; res(sp).Pfa=Pfa; res(sp).PfaCI=PfaCI;
end
save(fullfile(outdir,'white_summary.mat'),'res','methods','cfg');
fprintf('\n=== 白噪主实验完成，输出: %s ===\n',outdir);
end

function T=quantile_rank(X)
[n,nm]=size(X); k=ceil(0.95*n); T=nan(1,nm);
for j=1:nm, s=sort(X(:,j)); T(j)=s(k); end
end

function ci=wilson(k,n)
z=1.96; p_hat=k/n; den=1+z^2/n;
ctr=(p_hat+z^2/(2*n))/den;
hw=z*sqrt(p_hat*(1-p_hat)/n+z^2/(4*n^2))/den;
ci=[ctr-hw,ctr+hw];
end

function h=cfg_hash(cfg)
j=jsonencode(cfg,'PrettyPrint',false);
try
    md=java.security.MessageDigest.getInstance('SHA-256');
    d=md.digest(uint8(j));
    h=reshape(dec2hex(typecast(d,'uint8')).',1,[]);
catch
    h=char(string(java.util.UUID.nameUUIDFromBytes(uint8(j))));
end
end
