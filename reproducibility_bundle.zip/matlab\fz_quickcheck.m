function fz_quickcheck()
% 快速冒烟：短信号验证全流程可运行、字段完整、数值合理（非正式结果）。
opts=fz_defaults(); fs=opts.sim_fs;
opts.sim_duration=0.25;   % N=3000，仅用于快速检查
speed=1200;
s=fz_sim_signal(opts,speed,-10,'white',42);
ff=s.ff;
fprintf('N=%d ff(BPFO@%drpm)=%.3f Hz fres=%d\n',s.N,speed,ff,s.fres);

fprintf('\n--- Gini 盲召回 ---\n');
[cand,aud]=fz_gini_recall(s.x,fs,opts);
disp(array2table(cand,'VariableNames',{'fc','bw','fl','fh','gini','level'}));
fprintf('有效层级%s 过滤层级%s\n',mat2str(aud.effective_levels),mat2str(aud.filtered_levels));

fprintf('\n--- Proposed pipeline ---\n');
tic; R=fz_pipeline(s.x,fs,ff,opts,opts.lambda_K); t=toc;
fprintf('耗时%.2fs 选带[%.0f,%.0f]bw%.0f L%d K=%d alpha=%.0f keep=[%s]\n',...
    t,R.selected_band(3),R.selected_band(4),R.selected_band(2),R.selected_band(6),...
    R.Kstar,R.alphaStar,num2str(R.keep_modes));
fprintf('THNR=%.2f dB fhat=%.3f ef=%.2f%% 未收敛=%d/%d 最终收敛=%d\n',...
    R.thnr,R.fhat,R.ef_pct,R.n_unconverged,numel(R.convlog),R.final_converged);
fprintf('alpha0=%.0f alpha_g=%.0f\n',R.alpha0,sqrt(opts.alpha_min_ratio*opts.alpha_max_ratio)*R.alpha0);

fprintf('\n--- 基线 ---\n');
for mm={'B2_gini_only','B3_gini_thnr_no_vmd','B4_fixed_vmd','B5_fixed_vmd_thnr'}
    rb=fz_baseline(mm{1},s.x,fs,ff,opts);
    fprintf('%-22s THNR=%6.2f fhat=%6.2f ef=%5.2f%% keep=[%s] 未收敛=%d\n',...
        mm{1},rb.thnr,rb.fhat,rb.ef_pct,num2str(rb.keep_modes),rb.n_unconverged);
end

fprintf('\n--- 粉噪/随机冲击信号生成检查 ---\n');
sp=fz_sim_signal(opts,speed,-10,'pink',5);
si=fz_sim_signal(opts,speed,-10,'impulse',6);
fprintf('pink rms(x)=%.3f  impulse rms(x)=%.3f (white fault rms=%.3f)\n',rms(sp.x),rms(si.x),rms(s.fault));
fprintf('\nQUICKCHECK_OK\n');
end
