function fz_alpha_hitrate(nRep)
% FZ_ALPHA_HITRATE 统计 20 个故障样本的 alpha*/K* 触限率（全量前收口规则）。
%   规则（用户冻结）：
%     r_alpha_upper = #(alpha* 达上限 16*alpha0)/nRep
%     <=5% 保持范围；>5% 全量前一次性扩到 32*alpha0（alpha_num 12->14）并重跑；
%     扩展后仍普遍触限 -> 停止并检查 alpha0 缩放公式。
%   用与全量一致的 f_res（默认 3600）、1200 rpm/-10dB white、seed 3001..。
if nargin<1||isempty(nRep), nRep=20; end
opts=fz_defaults(); fs=opts.sim_fs;
speed=1200; snr=-10;
if isempty(gcp('nocreate')), try, parpool('processes',4); catch, end; end

aStar=nan(nRep,1); a0=nan(nRep,1); Ks=nan(nRep,1);
thn=nan(nRep,1); ef=nan(nRep,1); upHit=false(nRep,1); loHit=false(nRep,1);
parfor i=1:nRep
    s=fz_sim_signal(opts,speed,snr,'white',3000+i);
    R=fz_pipeline(s.x,fs,s.ff,opts,opts.lambda_K);
    aStar(i)=R.alphaStar; a0(i)=R.alpha0; Ks(i)=R.Kstar;
    thn(i)=R.thnr; ef(i)=R.ef_pct;
    upHit(i)= R.alphaStar >= opts.alpha_max_ratio*R.alpha0*(1-1e-9);
    loHit(i)= R.alphaStar <= opts.alpha_min_ratio*R.alpha0*(1+1e-9);
end
rUp=mean(upHit); rLo=mean(loHit);
fprintf('\n===== alpha 触限统计 (n=%d, f_res=%g Hz, 1200rpm/-10dB) =====\n',nRep,opts.f_res);
fprintf('alpha*: min=%.1f median=%.1f max=%.1f (alpha0 中位=%.1f, 上限16*a0=%.0f)\n',...
    min(aStar),median(aStar),max(aStar),median(a0),16*median(a0));
edges=(opts.K_list(1)-0.5):1:(opts.K_list(end)+0.5);
fprintf('K* 分布: %s\n',mat2tab(histcounts(Ks,edges),opts.K_list));
fprintf('THNR 中位=%.2f dB, ef 中位=%.3f%%\n',median(thn),median(ef));
fprintf(">>> 触上限(16*a0)率 = %.1f%% (%d/%d)\n",100*rUp,sum(upHit),nRep);
fprintf(">>> 触下限(0.05*a0)率 = %.1f%% (%d/%d)\n",100*rLo,sum(loHit),nRep);
if rUp>0.05
    fprintf(">>> 判定: >5%%，按规则全量前扩 alpha_max_ratio=32、alpha_num=14 后重跑本统计。\n");
else
    fprintf(">>> 判定: <=5%%，保持 [0.05*a0,16*a0] 不变。\n");
end
fprintf('===========================================================\n');
save(fullfile(fileparts(mfilename('fullpath')),'fz_alpha_hitrate.mat'),...
    'aStar','a0','Ks','thn','ef','upHit','loHit','rUp','rLo');
end

function s=mat2tab(cnt,ks)
s='';
for j=1:numel(ks), s=[s,sprintf('K=%d:%d ',ks(j),cnt(j))]; end %#ok<AGROW>
end
