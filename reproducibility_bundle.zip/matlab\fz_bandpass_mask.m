function xb = fz_bandpass_mask(Xfft, N, fl, fh, fs)
% FZ_BANDPASS_MASK FFT 频域掩码零相位理想带通（与旧实现一致），返回等长实信号。
mask = false(1,N);
fax = linspace(0,fs,N+1); fax=fax(1:end-1);
ip = fax>=fl & fax<fh;
in = N - ip + 2; in(in>N)=1;
mask(ip)=true; mask(in)=true;
xb = real(ifft(Xfft.*mask,N));
end
