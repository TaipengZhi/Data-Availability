% fz_summary_uncertainty.m  (v3: 字段名直接写死)
clear; clc;
d = load(fullfile('results_uncertainty','uncertainty.mat'));
res = d.res;
fn  = fieldnames(res);

fprintf('==================================================\n');
fprintf('不确定度分析汇总 (proposed, 1200rpm/-10dB, n=20)\n');
fprintf('==================================================\n');
fprintf('%-16s %8s %8s %8s %8s %8s %8s %8s\n', ...
    'field','ff_in','efMed','efIQR','THNRmed','THNRiqr','det%','fcFail%');

for i = 1:numel(fn)
    s = res.(fn{i});
    ef  = s.ef(:);
    th  = s.thnr(:);
    det = s.det(:);
    if isfield(s,'fcFail')
        fcf = double(s.fcFail(:));
    elseif isfield(s,'fc')
        % fc 可能是收敛标志：1=收敛 0=失败；取反作为失败率
        fcf = double(~s.fc(:));
    else
        fcf = zeros(size(ef));
    end
    medEf = median(ef);
    iqrEf = prctile(ef,75) - prctile(ef,25);
    medTh = median(th);
    iqrTh = prctile(th,75) - prctile(th,25);
    fprintf('%-16s %8.2f %8.4f %8.4f %8.2f %8.2f %7.0f%% %7.0f%%\n', ...
        fn{i}, s.ff_in, medEf, iqrEf, medTh, iqrTh, ...
        mean(det)*100, mean(fcf)*100);
end

% 配对变化
fprintf('\n=== 相对基准 spz_ge2 的配对变化 ===\n');
base = res.sp2_ge2;
bEf = base.ef(:); bTh = base.thnr(:); bDet = base.det(:); bFcf = zeros(size(bEf));
if isfield(base,'fcFail'); bFcf = double(base.fcFail(:));
elseif isfield(base,'fc'); bFcf = double(~base.fc(:)); end
fprintf('%-16s %12s %12s %10s %10s\n', ...
    'field','ΔefMed(pp)','ΔTHNRMed(dB)','Δdet(pp)','ΔfcFail(pp)');
for i = 1:numel(fn)
    if strcmp(fn{i},'sp2_ge2'); continue; end
    s = res.(fn{i});
    sEf = s.ef(:); sTh = s.thnr(:); sDet = s.det(:);
    sFcf = zeros(size(sEf));
    if isfield(s,'fcFail'); sFcf = double(s.fcFail(:));
    elseif isfield(s,'fc'); sFcf = double(~s.fc(:)); end
    fprintf('%-16s %+12.4f %+12.2f %+10.0f %+10.0f\n', ...
        fn{i}, median(sEf)-median(bEf), median(sTh)-median(bTh), ...
        mean(sDet)*100-mean(bDet)*100, mean(sFcf)*100-mean(bFcf)*100);
end

% 按转速合并
fprintf('\n=== 按转速合并（几何扰动取 median） ===\n');
speed_keys = {'sp1','sp2','sp3'};
speed_lbl  = {'转速-1%','转速0','转速+1%'};
for k = 1:numel(speed_keys)
    ks = speed_keys{k};
    sub = fn(startsWith(fn, ks));
    aEf=[]; aTh=[]; aDet=[]; aFcf=[];
    for j = 1:numel(sub)
        s = res.(sub{j});
        aEf = [aEf; s.ef(:)];
        aTh = [aTh; s.thnr(:)];
        aDet= [aDet; s.det(:)];
        if isfield(s,'fcFail'); aFcf=[aFcf; double(s.fcFail(:))];
        elseif isfield(s,'fc'); aFcf=[aFcf; double(~s.fc(:))]; end
    end
    fprintf('%-10s n=%3d efMed=%.4f efIQR=%.4f THNRmed=%.2f THNRiqr=%.2f det=%.0f%% fcFail=%.0f%%\n', ...
        speed_lbl{k}, numel(aEf), median(aEf), ...
        prctile(aEf,75)-prctile(aEf,25), median(aTh), ...
        prctile(aTh,75)-prctile(aTh,25), mean(aDet)*100, mean(aFcf)*100);
end
fprintf('\n完成。\n');
