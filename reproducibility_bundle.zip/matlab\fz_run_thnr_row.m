function v = fz_run_thnr_row(methods, x, fs, ff, opts)
% 供 parfor：跑全部方法，返回 THNR 行向量
nM=numel(methods); v=nan(1,nM);
for m=1:nM
    R=fz_callone(methods{m},x,fs,ff,opts);
    if ~isempty(R), v(m)=R.thnr; end
end
end
