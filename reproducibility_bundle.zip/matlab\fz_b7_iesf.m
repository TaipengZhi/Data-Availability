function R = fz_b7_iesf(x, fs, ff, opts)
% B7 IESFOgram/CFFOgram-style TARGET-REFERENCED optimization gram.
% Same-prior baseline: over a fine (center, bandwidth) paving in the high-frequency
% region, maximise the target harmonic-to-noise ratio (THNR) of the envelope spectrum,
% then demodulate the selected band. Uses the known fault frequency ff exactly like
% the proposed method; no VMD. Band selection and detection share THNR, as in the
% original IESFOgram/CFFOgram target-referenced scheme.
if nargin<4, opts=fz_defaults(); end
x=x(:).'; N=length(x); Xfft=fft(x-mean(x),N);
flo=opts.freq_low; fhi=opts.freq_high_ratio*fs;
bwSet=[1000 1500 2000 3000 4000];
step=200;

bestThr=-inf; bestSel=[]; bestA=[]; bestFq=[]; bestXb=[]; bestDelta=NaN;
nCand=0;
for bw=bwSet
    cMin=max(flo+bw/2, bw/2);
    cMax=min(fhi-bw/2, fs/2-bw/2);
    if cMax < cMin, continue; end
    ctrs=(ceil(cMin/step)*step):step:(floor(cMax/step)*step);
    for fc=ctrs
        fl=fc-bw/2; fh=fc+bw/2;
        xb=fz_bandpass_mask(Xfft,N,fl,fh,fs);
        [A,fq]=fz_amp_env_spectrum(xb,fs);
        rr=fz_thnr(A,fq,ff,opts);
        nCand=nCand+1;
        if isfinite(rr.thnr) && rr.thnr>bestThr
            bestThr=rr.thnr; bestSel=[fc,bw,fl,fh];
            bestA=A; bestFq=fq; bestXb=xb; bestDelta=rr.delta;
        end
    end
end
[fh_est,pi_]=fz_parabolic_peak(bestA,bestFq,ff,bestDelta);
R=struct('method','B7_iesf','n_candidates',nCand,'selected_band',bestSel,...
    'Kstar',NaN,'alphaStar',NaN,'keep_modes',NaN,...
    'xrec',bestXb,'A',bestA,'f',bestFq,'thnr',bestThr,...
    'fhat',fh_est,'pinfo',pi_,'ef_pct',abs(fh_est-ff)/ff*100,...
    'n_unconverged',NaN,'final_converged',NaN);
end
