function c = fz_cwru_calib2(outdir)
% FZ_CWRU_CALIB2  精简：采用已标定 T_{m,c}，只重跑 lambdaK 并修正 lexsort。
if nargin<1, outdir=fullfile(fileparts(mfilename('fullpath')),'results_cwru'); end
opts=fz_defaults(); fs=12000; win=12000; root='D:\two_stage_vmd_fggi_project\dataset\CRWU';
% 已标定 T_{m,c}（0hp normal_0 20窗口 95%秩分位；行=Proposed,B2..B6；列=inner/outer/ball）
T=[2.291,2.9406,4.3568;
  -2.0545,-0.98553,-0.77757;
   0.69319,2.0693,1.9374;
  -0.7561,-0.38352,3.1493;
  -0.068797,3.1907,4.5746;
  -20.85,-9.9779,1.5426;
  -12.877,-4.2872,-1.3519];
methods={'Proposed','B2_gini_only','B3_gini_thnr_no_vmd','B4_fixed_vmd','B5_fixed_vmd_thnr','B1','B6'};
fr0=1797/60; Z=9; d=7.94e-3; D=39.04e-3;
ffC.inner=Z*fr0/2*(1+d/D); ffC.outer=Z*fr0/2*(1-d/D); ffC.ball=D/(2*d)*(1-(d/D)^2)*fr0;
cnames={'inner','outer','ball'};
winF.inner=loadcw(fullfile(root,'12k Drive End Bearing Fault Data','Inner Race','0007','IR007_0.mat'),fs,win);
winF.outer=loadcw(fullfile(root,'12k Drive End Bearing Fault Data','Outer Race','Centered','0007','OR007@6_0.mat'),fs,win);
winF.ball =loadcw(fullfile(root,'12k Drive End Bearing Fault Data','Ball','0007','B007_0.mat'),fs,win);

lgrid=[0 .1 .25 .5 1 2];
rec=nan(numel(lgrid),3);
for li=1:numel(lgrid)
 opt=opts; opt.lambda_K=lgrid(li);
 pd=[]; ef=[]; kk=[];
 for ci=1:3
  c=cnames{ci}; W=winF.(c);
  for k=1:size(W,1)
   R=fz_pipeline(W(k,:),fs,ffC.(c),opt,lgrid(li));
   pd=[pd; R.thnr>T(1,ci)]; ef=[ef; R.ef_pct]; kk=[kk; R.Kstar];
  end
 end
 rec(li,:)=[mean(pd),median(ef),mean(kk)];
 fprintf('lambda=%g: Pd=%.3f medEf=%.4f meanK=%.2f\n',lgrid(li),rec(li,1),rec(li,2),rec(li,3));
end
% lexsort: Pd最高(-Pd小) -> ef最小 -> meanK最小 -> lambda较大(-lambda小)
score=[-rec(:,1), rec(:,2), rec(:,3), -lgrid(:)];
[~,idx]=sortrows(score); bi=idx(1); lam=lgrid(bi);
fprintf('选定 lambdaK=%.3g (Pd=%.3f medEf=%.4f meanK=%.2f)\n',lam,rec(bi,1),rec(bi,2),rec(bi,3));

if ~exist(outdir,'dir'), mkdir(outdir); end
save(fullfile(outdir,'cwru_calib.mat'),'T','lam','ffC','methods','win','fs','Z','d','D','lgrid','rec');
fprintf('已存 cwru_calib.mat\n');
end

function W=loadcw(fp,fs,win)
 ld=load(fp); vn=fieldnames(ld); di=find(contains(vn,'_DE_time'),1);
 sig=ld.(vn{di}); sig=sig(:)'; n=floor(length(sig)/win);
 W=zeros(n,win);
 for k=1:n, W(k,:)=sig((k-1)*win+1:k*win); end
end
