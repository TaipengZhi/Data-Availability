function fz_rescue(outdir)
% FZ_RESCUE  轻量救援审计（稳健版：增量存盘/try-catch/clear/断点续跑）。
if nargin<1, outdir=fullfile(fileparts(mfilename('fullpath')),'results_white_full'); end
opts=fz_defaults(); fs=opts.sim_fs; lambdaK=opts.lambda_K;
speeds=opts.sim_speeds; snrs=opts.sim_snr_white;
savefile=fullfile(outdir,'rescue_results.mat');
if exist(savefile,'file')
    L=load(savefile); rec=L.rec;
else
    rec=struct('speed',{},'snr',{},'r',{},'Kstar',{},'Jstar',{},...
        'candK',{},'candAlphaRatio',{},'rescuedConv',{},'Jrescue',{},'beatStar',{});
end
done=zeros(numel(rec),1);
for sp=1:numel(speeds)
 speed=speeds(sp); [ff,~]=fz_kinematic_ff(opts.bearing,speed,'BPFO');
 for sri=1:numel(snrs)
  snr=snrs(sri);
  D=load(fullfile(outdir,sprintf('white_%grpm_%gdB.mat',speed,snr)));
  nunc=D.nunc(:,1); idx=find(nunc>0); sel=idx(1:min(2,numel(idx)));
  for ii=1:numel(sel)
   r=sel(ii);
   if any([rec.speed]==speed & [rec.snr]==snr & [rec.r]==r), continue; end
   try
    seed=70000+sp*100000+sri*10000+r;
    s=fz_sim_signal(opts,speed,snr,'white',seed);
    R=fz_pipeline(s.x,fs,ff,opts,lambdaK);
    Jstar=R.thnr-lambdaK*R.Kstar;
    bw=R.selected_band(2); alpha0=opts.alpha_scale*fs/bw;
    unconv=R.convlog(cellfun(@(c)~c.converged,R.convlog));
    n=numel(rec)+1;
    rec(n).speed=speed; rec(n).snr=snr; rec(n).r=r;
    rec(n).Kstar=R.Kstar; rec(n).Jstar=Jstar;
    rec(n).candK=zeros(1,numel(unconv)); rec(n).candAlphaRatio=zeros(1,numel(unconv));
    rec(n).rescuedConv=false(1,numel(unconv)); rec(n).Jrescue=nan(1,numel(unconv)); rec(n).beatStar=false(1,numel(unconv));
    for jj=1:numel(unconv)
     c=unconv{jj};
     rec(n).candK(jj)=c.K;
     rec(n).candAlphaRatio(jj)=c.alpha/alpha0;
     try
      [u,~,~,info]=fz_vmd(R.x_narrow,c.alpha,opts.vmd_tau,c.K,opts.vmd_DC,1,opts.vmd_tol,2000);
      if info.converged
       rec(n).rescuedConv(jj)=true;
       imfs=u.'; res=fz_mode_subset_select(imfs,fs,ff,opts);
       Jr=res.thnr-lambdaK*c.K; rec(n).Jrescue(jj)=Jr;
       if Jr>Jstar+opts.tie_db, rec(n).beatStar(jj)=true; end
      end
     catch ME2
      fprintf('  候选失败 K=%g: %s\n',c.K,ME2.message);
     end
    end
    fprintf('完成 %grpm/%gdB r=%g: 候选%d 救援收敛%d 超J*%d\n',...
        speed,snr,r,numel(unconv),sum(rec(n).rescuedConv),sum(rec(n).beatStar));
   catch ME1
    fprintf('样本失败 %grpm/%gdB r=%g: %s\n',speed,snr,r,ME1.message);
   end
   save(savefile,'rec');
   clear R s u imfs;
  end
 end
end
% 汇总
totR=sum(cellfun(@numel,{rec.Jrescue}));
totC=sum([rec.rescuedConv]==1,'all');
totB=sum([rec.beatStar]==1,'all');
fprintf('\n===== 救援审计汇总 =====\n');
fprintf('样本数=%d 救援候选=%d 2000iter收敛=%d 超过J*=%d\n',numel(rec),totR,totC,totB);
fprintf('超J*候选明细:\n');
for n=1:numel(rec)
 for j=1:numel(rec(n).beatStar)
  if rec(n).beatStar(j)
   fprintf('  %grpm/%gdB r=%g: K=%g a/a0=%.2f J_rescue=%.3f J*=%.3f\n',...
      rec(n).speed,rec(n).snr,rec(n).r,rec(n).candK(j),rec(n).candAlphaRatio(j),rec(n).Jrescue(j),rec(n).Jstar);
  end
 end
end
if totB==0, fprintf('判定:无超J* -> 方案A成立,门控通过\n'); else, fprintf('判定:%d个超J* -> 方案A不成立,需重评\n',totB); end
end
