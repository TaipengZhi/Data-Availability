function fz_cwru_audit(outdir)
% FZ_CWRU_AUDIT  CWRU收口审计：逐窗口THNR重算 + 负载匹配区分度。
%  增量存盘+断点续跑+每负载后clear防OOM。
if nargin<1, outdir=fullfile(fileparts(mfilename('fullpath')),'results_cwru'); end
opts=fz_defaults(); fs=12000; win=12000; root='D:\two_stage_vmd_fggi_project\dataset\CRWU';
methods={'Proposed','B2_gini_only','B3_gini_thnr_no_vmd','B4_fixed_vmd','B5_fixed_vmd_thnr','B1','B6'};
cnames={'inner','outer','ball'};
S=load(fullfile(outdir,'cwru_calib.mat')); T=S.T; lam=S.lam;
opts.lambda_K=lam;
fprintf('=== lambdaK核对: lam=%g (标量=%d) ===\n',lam,isscalar(lam));
loads=[1 2 3]; speed=[1772 1750 1730];
Z=9; d=7.94e-3; D=39.04e-3; nM=numel(methods);
auditfile=fullfile(outdir,'cwru_audit.mat');
audit=struct();
if exist(auditfile,'file')
 old=load(auditfile); audit=old.audit;
 fprintf('断点续跑：已有负载 %s\n',strjoin(fieldnames(audit),', '));
end
for li=1:3
 ll=loads(li);
 if isfield(audit,sprintf('L%d',ll))
  fprintf('--- %d hp 已有结果，跳过 ---\n',ll); continue;
 end
 fr=speed(li)/60;
 ff.inner=Z*fr/2*(1+d/D); ff.outer=Z*fr/2*(1-d/D); ff.ball=D/(2*d)*(1-(d/D)^2)*fr;
 fprintf('\n--- %d hp (ff: inner=%.2f outer=%.2f ball=%.2f) ---\n',ll,ff.inner,ff.outer,ff.ball);
 % 正常文件
 fpN=fullfile(root,'Normal Baseline',sprintf('normal_%d.mat',ll));
 WN=loadcw(fpN,fs,win); nN=size(WN,1);
 normalTHNR=nan(nN,nM,3);
 parfor k=1:nN
  row=nan(1,nM,3);
  for ci=1:3
   for m=1:nM
    try
     Rm=fz_callone(methods{m},WN(k,:),fs,ff.(cnames{ci}),opts);
     row(1,m,ci)=Rm.thnr;
    catch, end
   end
  end
  normalTHNR(k,:,:)=row;
 end
 clear WN;
 % 故障文件
 faultTHNR=struct(); faultEf=struct();
 for ti=1:3
  c=cnames{ti}; fp=getfile(root,c,ll);
  W=loadcw(fp,fs,win); nF=size(W,1);
  th=nan(nF,nM); efv=nan(nF,nM);
  parfor k=1:nF
   row=nan(1,nM); rowef=nan(1,nM);
   for m=1:nM
    try
     Rm=fz_callone(methods{m},W(k,:),fs,ff.(c),opts);
     row(m)=Rm.thnr; rowef(m)=Rm.ef_pct;
    catch, end
   end
   th(k,:)=row; efv(k,:)=rowef;
  end
  faultTHNR.(c)=th; faultEf.(c)=efv;
  clear W;
  fprintf('  %s: %d窗口, THNR中位(Proposed/B2/B4/B5)=%.2f/%.2f/%.2f/%.2f\n',...
    c,nF,median(th(:,1),'omitnan'),median(th(:,2),'omitnan'),...
    median(th(:,4),'omitnan'),median(th(:,5),'omitnan'));
 end
 fprintf('  normal: %d窗口, THNR中位(Proposed, inner/outer/ball)=%.2f/%.2f/%.2f\n',...
   nN,median(normalTHNR(:,1,1),'omitnan'),median(normalTHNR(:,1,2),'omitnan'),median(normalTHNR(:,1,3),'omitnan'));
 % 区分度
 fprintf('\n  --- 负载匹配区分度 (%d hp) ---\n',ll);
 fprintf('  %-6s %-22s %8s %8s %8s %8s %8s %8s\n','故障','方法','medF','medN','dTHNR','AUROC','Cliffd','medEf');
 for ti=1:3
  c=cnames{ti}; th=faultTHNR.(c); efv=faultEf.(c); nth=squeeze(normalTHNR(:,:,ti));
  for m=1:nM
   fv=th(:,m); nv=nth(:,m); fv=fv(isfinite(fv)); nv=nv(isfinite(nv));
   if isempty(fv)||isempty(nv), continue; end
   medF=median(fv); medN=median(nv); dT=medF-medN;
   gt=0; eq=0;
   for i=1:numel(fv)
    for j=1:numel(nv)
     if fv(i)>nv(j), gt=gt+1; elseif fv(i)==nv(j), eq=eq+1; end
    end
   end
   auroc=(gt+0.5*eq)/(numel(fv)*numel(nv));
   cd=(gt-(numel(fv)*numel(nv)-gt-eq))/(numel(fv)*numel(nv));
   medEf=median(efv(:,m),'omitnan');
   fprintf('  %-6s %-22s %8.2f %8.2f %8.2f %8.3f %8.3f %8.3f\n',...
     c,methods{m},medF,medN,dT,auroc,cd,medEf);
  end
 end
 audit.(sprintf('L%d',ll))=struct('load',ll,'speed',speed(li),'ff',ff,...
   'normalTHNR',normalTHNR,'faultTHNR',faultTHNR,'faultEf',faultEf);
 clear normalTHNR faultTHNR faultEf;
 save(auditfile,'audit','T','lam','methods','loads','speed','-v7.3');
 fprintf('  [已增量存盘 %d hp]\n',ll);
end
save(auditfile,'audit','T','lam','methods','loads','speed','-v7.3');
fprintf('\n已存 cwru_audit.mat\n');
% 跨负载漂移
fprintf('\n=== Proposed跨负载漂移 ===\n');
fprintf('%-8s %8s %8s %8s %8s\n','故障','1hp','2hp','3hp','漂移');
for ti=1:3
 c=cnames{ti}; vals=[]; efs=[];
 for li=1:3
  th=audit.(sprintf('L%d',li)).faultTHNR.(c);
  vals(li)=median(th(:,1),'omitnan');
  efs(li)=median(audit.(sprintf('L%d',li)).faultEf.(c)(:,1),'omitnan');
 end
 fprintf('%-8s %8.2f %8.2f %8.2f %8.2f (ef: %.3f/%.3f/%.3f%%)\n',...
   c,vals(1),vals(2),vals(3),max(vals)-min(vals),efs(1),efs(2),efs(3));
end
end

function fp=getfile(root,c,ll)
switch c
 case 'inner', fp=fullfile(root,'12k Drive End Bearing Fault Data','Inner Race','0007',sprintf('IR007_%d.mat',ll));
 case 'ball',  fp=fullfile(root,'12k Drive End Bearing Fault Data','Ball','0007',sprintf('B007_%d.mat',ll));
 case 'outer', fp=fullfile(root,'12k Drive End Bearing Fault Data','Outer Race','Centered','0007',sprintf('OR007@6_%d.mat',ll));
end
end
function W=loadcw(fp,fs,win)
 if ~exist(fp,'file'), error('缺文件 %s',fp); end
 ld=load(fp); vn=fieldnames(ld); di=find(contains(vn,'_DE_time'),1);
 sig=ld.(vn{di}); sig=sig(:)'; n=floor(length(sig)/win);
 W=zeros(n,win);
 for k=1:n, W(k,:)=sig((k-1)*win+1:k*win); end
end
