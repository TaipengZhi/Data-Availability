function T = fz_calibrate_threshold(thnrNormal, opts)
% FZ_CALIBRATE_THRESHOLD 方法×目标类型阈值（冻结书 §9）。
% 取该方法在 0hp 正常样本、某目标位置 THNR 的 95% 分位（经验 Pfa=5%）。
% 手写百分位（线性插值），不依赖统计工具箱。
if nargin<2, opts=fz_defaults(); end
v=thnrNormal(isfinite(thnrNormal)); v=sort(v(:));
if isempty(v), T=NaN; return; end
q=opts.pfa_quantile;
pos=q*(numel(v)-1)+1;
lo=floor(pos); hi=ceil(pos);
if lo==hi, T=v(lo); else, T=v(lo)+(pos-lo)*(v(hi)-v(lo)); end
end
