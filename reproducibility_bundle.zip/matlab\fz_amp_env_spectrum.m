function [A, f, df, Nfft] = fz_amp_env_spectrum(x, fs)
% FZ_AMP_ENV_SPECTRUM 幅值包络谱 A(f)=|FFT(|H[x]|)|（冻结书 §6.2 统一口径）。
% 全方法统一：去均值 -> Hann 窗 -> Hilbert 解析信号 -> 幅值包络 -> 去均值 FFT（补零到 2^k）。
% 返回单边幅值谱 A、频率轴 f、频点间距 df（bin spacing，补零不等于物理分辨率）、Nfft。
x = x(:).';
N = length(x);
Nfft = 2^nextpow2(N);
w = 0.5*(1 - cos(2*pi*(0:N-1)'/(N-1)));   % Hann
w = w(:).';
xw = (x - mean(x)).*w;
analytic = hilbert(xw);
env = abs(analytic);
env = env - mean(env);
A = abs(fft(env, Nfft));
A = A(1:Nfft/2+1);
f = linspace(0, fs/2, Nfft/2+1);
df = fs/Nfft;
end
