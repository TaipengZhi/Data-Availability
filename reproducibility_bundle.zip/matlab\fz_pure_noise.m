function x = fz_pure_noise(noise_type, N, fs, opts, seed)
% FZ_PURE_NOISE  纯噪声标定/验证信号（无故障分量）。
%   与 fz_sim_signal 中噪声基底功率水平一致，用于 THNR 阈值标定。
%   noise_type: 'white' | 'pink' | 'impulse'
if nargin>=5 && ~isempty(seed), rng(seed); end
switch lower(noise_type)
    case 'white'
        x=randn(1,N);
    case 'pink'
        w=randn(1,N); W=fft(w);
        nf=ceil((N+1)/2); sc=ones(1,nf); k=2:nf; sc(k)=1./sqrt(k-1);
        if mod(N,2)==0, sc=[sc, sc(end-1:-1:2)];
        else, sc=[sc, sc(end:-1:2)]; end
        x=real(ifft(W.*sc));
    case 'impulse'
        % -10 dB 白噪基底（与 fz_sim_signal impulse 一致）
        x=randn(1,N);
        ximp=random_impulses_pure(N,fs,opts);
        x=x+ximp;
    otherwise
        error('未知噪声类型 %s',noise_type);
end
end

function xi=random_impulses_pure(N,fs,opts)
xi=zeros(1,N);
rate=opts.impulse_rate; T=N/fs;
M=poisson_count(rate*T);
flo=opts.freq_low; fhi=opts.freq_high_ratio*fs;
for k=1:M
    pos=randi(N);
    fcI=flo+(fhi-flo)*rand;
    b=opts.damping_ratio*2*pi*fcI;
    med=opts.impulse_R_med;
    amp=med*exp(normrnd_safe(0,0.5));
    i0=pos; tt=(0:N-i0)/fs;
    w=amp*exp(-b*tt).*cos(2*pi*fcI*tt);
    xi(i0:N)=xi(i0:N)+w;
end
% 与 fz_sim_signal 一致：INR 归一化到故障功率。纯噪声无故障，用 1 单位参考功率。
targetPow=10^(opts.impulse_INR_dB/10);
if mean(xi.^2)>eps
    xi=xi*sqrt(targetPow/mean(xi.^2));
end
end

function m=poisson_count(mu)
L=exp(-mu); k=0; p=1;
while p>L, k=k+1; p=p*rand; end
m=k-1; m=max(m,1);
end

function z=normrnd_safe(mu,sig)
u1=max(rand,eps); u2=rand;
Z=sqrt(-2*log(u1))*cos(2*pi*u2);
z=mu+sig*Z;
end
