function A = fz_level_audit()
% FZ_LEVEL_AUDIT 200 Hz 最小带宽门槛与前三阶边带完整性核查（冻结书 §16.1）。
% 输出：各层带宽、被 Bmin 过滤的层级、top-5 候选、入选带宽、能否容纳前三阶调制边带。
opts=fz_defaults(); fs=opts.sim_fs;
fprintf('\n########## 200Hz 层级与边带核查 ##########\n');
fprintf('理论层级带宽(fs=%.0f): %s Hz\n',fs,mat2str(fs./2.^(1:7),6));
fprintf('Bmin=%.0f Hz => bw<Bmin 的层级被过滤\n',opts.min_bandwidth);

% 单样本 1200 rpm / -10 dB 白噪
s=fz_sim_signal(opts,1200,-10,'white',777);
ff=s.ff; fres=s.fres;
[cand,audit]=fz_gini_recall(s.x,fs,opts);
fprintf('\n有效层级: %s ; 被Bmin过滤层级: %s ; 可行带总数=%d\n',...
    mat2str(audit.effective_levels),mat2str(audit.filtered_levels),audit.all_band_count);
fprintf('\ntop-%d Gini 候选带:\n',size(cand,1));
fprintf('  排名 中心Hz   带宽Hz   下限     上限     Gini    层级\n');
for i=1:size(cand,1)
    fprintf('  %d  %7.1f %8.1f %8.1f %8.1f  %.4f   %d\n',i,cand(i,1),cand(i,2),cand(i,3),cand(i,4),cand(i,5),cand(i,6));
end

R=fz_pipeline(s.x,fs,ff,opts,opts.lambda_K);
sb=R.selected_band; bw=sb(2);
fprintf('\n入选频带: 中心%.1f Hz, 带宽%.1f Hz [%g,%g], 层级%d\n',sb(1),bw,sb(3),sb(4),sb(6));
fprintf('结构共振载频 fres=%.0f Hz 是否在入选带内: %d\n',fres, fres>=sb(3)&&fres<=sb(4));

% 前三阶调制边带：载频两侧 ±h*ff（h=1..3），检查是否被带通截断
span3=3*ff;
need_lo=fres-span3; need_hi=fres+span3;
inside = need_lo>=sb(3) && need_hi<=sb(4);
fprintf('前三阶调制边带总跨度 6*ff=%.1f Hz, 需覆盖 [%g,%g]\n',6*ff,need_lo,need_hi);
fprintf('入选带宽 %.1f Hz（半宽 %.1f Hz）能否完整容纳前三阶边带: %d\n',bw,bw/2,inside);
% 包络谱前三阶谐波邻域是否都在分析范围内且有非空点数
td=R.thnr_detail;
fprintf('包络谱各阶谐波邻域点数: %s, 被边界裁剪阶: %s\n',mat2str(td.orderPts(:)'),mat2str(find(td.orderClipped(:)')));

if numel(audit.effective_levels)<=4
    fprintf('\n[结论] 有效搜索层级仅 1-%d，正文应如实写"有效搜索层级为1-%d级"，不得声称完整使用1-7级。\n',...
        max(audit.effective_levels),max(audit.effective_levels));
end
if ~inside
    fprintf('[警示] 前三阶边带被 %.0f Hz 窄带截断，需评估是否调整 Bmin（仅允许改此常数并记录v2.1参数附录）。\n',opts.min_bandwidth);
end

A=struct('audit',audit,'candidates',cand,'selected_band',sb,'span3',span3,...
    'sideband_inside',logical(inside),'thnr',R.thnr,'fhat',R.fhat,'ef_pct',R.ef_pct,...
    'Kstar',R.Kstar,'alphaStar',R.alphaStar,'keep_modes',R.keep_modes);
fprintf('单样本: THNR=%.2f dB, fhat=%.2f Hz (ff=%.2f, ef=%.2f%%), K=%d alpha=%.0f keep=[%s]\n',...
    R.thnr,R.fhat,ff,R.ef_pct,R.Kstar,R.alphaStar,num2str(R.keep_modes));
fprintf('##########################################\n');
end
