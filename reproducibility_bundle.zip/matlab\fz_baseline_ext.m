function R = fz_baseline_ext(method, x, fs, ff, opts)
% FZ_BASELINE_EXT  B1 Fast Kurtogram / B6 Original two-stage VMD[5] 的冻结包装。
%   公平性：选带/选模仍按各方法【原文】逻辑；但统一用 frozen 的幅值包络谱
%   (fz_amp_env_spectrum)、THNR、抛物线插值重算 THNR/ef，保证与 Proposed 同口径。
%   B1: 纯峭度选带，不接收 ff（验证选带不随 ff 变）。
%   B6: 原文用功率谱主峰数据驱动共振频率，ff 仅为接口占位、内部不使用。
% 输出统一字段：thnr, ef_pct, A, f, fhat, Kstar, alphaStar, selected_band,
%              convlog, n_unconverged, final_converged, best_band_raw。
if nargin<5||isempty(opts), opts=fz_defaults(); end
x=x(:).'; N=length(x);

% --- 旧函数依赖目录 ---
oldroot='D:\two_stage_vmd_fggi_project\functions';
addpath(oldroot,fullfile(oldroot,'baseline_methods'),...
    fullfile(oldroot,'common_utils'),fullfile(oldroot,'core_algorithm'));
% --- 旧 params 映射（与 frozen 一致）---
p.algorithm.se_gini_gram.decomp_level_min=opts.gini_level_min;
p.algorithm.se_gini_gram.decomp_level_max=opts.gini_level_max;
p.algorithm.se_gini_gram.freq_range_low=opts.freq_low;
p.algorithm.se_gini_gram.freq_range_high_ratio=0.4;
p.algorithm.vmd_bound.vmd_tol=opts.vmd_tol;
p.algorithm.vmd_bound.vmd_max_iter=opts.vmd_max_iter;

switch upper(method)
    case 'B1'
        res=fast_kurtogram(x,fs,ff,p);
        best=res.best_mode;
        selband=[res.best_band(1),res.best_band(2),res.best_band(3),res.best_band(4),NaN,NaN];
        Kstar=NaN; alphaStar=NaN; convlog={}; nUnc=0; finalConv=NaN; % B1 无 VMD
    case 'B6'
        res=ref8_two_stage_vmd(x,fs,'sim',ff,p);   % ff 内部不使用
        best=res.best_mode;
        if ~isempty(res.best_band), selband=res.best_band; else, selband=[NaN NaN NaN NaN NaN NaN]; end
        Kstar=res.K_opt; alphaStar=res.alpha_opt;
        convlog={}; nUnc=0; finalConv=NaN;  % 旧 VMD 不报告收敛，诚实标 NaN
    otherwise
        error('未知外部基线 %s',method);
end

% --- 统一 frozen 口径重算 ---
[A,fq]=fz_amp_env_spectrum(best,fs);
rr=fz_thnr(A,fq,ff,opts);
[fhat,~]=fz_parabolic_peak(A,fq,ff,rr.delta);
ef=abs(fhat-ff)/ff*100;

R=struct('thnr',rr.thnr,'ef_pct',ef,'A',A,'f',fq,'fhat',fhat,...
    'Kstar',Kstar,'alphaStar',alphaStar,'selected_band',selband,...
    'convlog',{convlog},'n_unconverged',nUnc,'final_converged',finalConv,...
    'best_band_raw',res.best_band,'xrec',best(:).');
end
