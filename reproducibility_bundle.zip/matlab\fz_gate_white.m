function fz_gate_white(outdir)
% 白噪主实验预注册中期门控汇总
if nargin<1||isempty(outdir)
    outdir=fullfile(fileparts(mfilename('fullpath')),'results_white_full');
end
methods={'Proposed','B2','B3','B4','B5','B1','B6'}; nM=numel(methods);
speeds=[600 1200 1800]; snrs=[-15 -10 -5 0 5];
C=load(fullfile(outdir,'config_white.mat'));
fprintf('==== 配置哈希 ====\n%s\n',C.cfg.config_hash);
fprintf('f_res=%g oracle=[%g,%g] Bmin=%g lambda_K=%g K_list=%s alpha[%.3g,%.3g]x%d nRep=%d nCal=%d nVal=%d\n',...
    C.cfg.f_res,C.cfg.oracle_band(1),C.cfg.oracle_band(2),C.cfg.Bmin,C.cfg.lambda_K,...
    mat2str(C.cfg.K_list),C.cfg.alpha_range(1),C.cfg.alpha_range(2),C.cfg.alpha_num,...
    C.cfg.nRep,C.cfg.nCal,C.cfg.nVal);

fprintf('\n==== Pfa (验证集 n=%d, 目标5%%) 与 Wilson 95%% CI ====\n',C.cfg.nVal);
for sp=1:numel(speeds)
    L=load(fullfile(outdir,sprintf('calib_%grpm.mat',speeds(sp))));
    fprintf('speed=%g:\n',speeds(sp));
    for m=1:nM
        fprintf('  %-9s Pfa=%.3f  CI[%.3f,%.3f]\n',methods{m},L.Pfa(m),L.PfaCI(m,1),L.PfaCI(m,2));
    end
end

fprintf('\n==== Pd (固定阈值, n=%d) ====\n',C.cfg.nRep);
hdr='SNR '; for m=1:nM, hdr=[hdr,sprintf('%8s',methods{m})]; end
for sp=1:numel(speeds)
    fprintf('--- %g rpm ---\n%s\n',speeds(sp),hdr);
    for sri=1:numel(snrs)
        D=load(fullfile(outdir,sprintf('white_%grpm_%gdB.mat',speeds(sp),snrs(sri))));
        line=sprintf('%4g ',snrs(sri));
        for m=1:nM, line=[line,sprintf('%8.2f',D.Pd(m))]; end
        fprintf('%s\n',line);
    end
end

fprintf('\n==== ef 频率相对误差中位数 %%%% ====\n');
for sp=1:numel(speeds)
    fprintf('--- %g rpm ---\n%s\n',speeds(sp),hdr);
    for sri=1:numel(snrs)
        D=load(fullfile(outdir,sprintf('white_%grpm_%gdB.mat',speeds(sp),snrs(sri))));
        line=sprintf('%4g ',snrs(sri));
        for m=1:nM, line=[line,sprintf('%8.3f',median(D.ef(:,m),'omitnan'))]; end
        fprintf('%s\n',line);
    end
end

fprintf('\n==== NRMSE_env 中位数（越小越好）====\n');
for sp=1:numel(speeds)
    fprintf('--- %g rpm ---\n%s\n',speeds(sp),hdr);
    for sri=1:numel(snrs)
        D=load(fullfile(outdir,sprintf('white_%grpm_%gdB.mat',speeds(sp),snrs(sri))));
        line=sprintf('%4g ',snrs(sri));
        for m=1:nM, line=[line,sprintf('%8.3f',median(D.nrm(:,m),'omitnan'))]; end
        fprintf('%s\n',line);
    end
end

fprintf('\n==== 最终解未收敛率（fc==0，应接近0；NaN=该方法无VMD/旧VMD不报）====\n');
for sp=1:numel(speeds)
    for sri=1:numel(snrs)
        D=load(fullfile(outdir,sprintf('white_%grpm_%gdB.mat',speeds(sp),snrs(sri))));
        if ~isfield(D,'fc')
            fprintf('%grpm/%gg: [旧chunk无fc字段，需重跑]\n',speeds(sp),snrs(sri)); continue;
        end
        line=sprintf('%grpm/%gg: ',speeds(sp),snrs(sri));
        for m=1:nM
            col=D.fc(:,m);
            if all(isnan(col)), line=[line,sprintf('%s=NA ',methods{m})];
            else, line=[line,sprintf('%s=%.0f%% ',methods{m},100*mean(col==0,'omitnan'))]; end
        end
        fprintf('%s\n',line);
    end
end

fprintf('\n==== 候选VMD未收敛（nunc，搜索过程统计，非最终失败）====\n');
for sp=1:numel(speeds)
    for sri=1:numel(snrs)
        D=load(fullfile(outdir,sprintf('white_%grpm_%gdB.mat',speeds(sp),snrs(sri))));
        line=sprintf('%grpm/%gg: ',speeds(sp),snrs(sri));
        for m=1:nM
            col=D.nunc(:,m);
            if all(isnan(col)), line=[line,sprintf('%s=NA ',methods{m})];
            else, line=[line,sprintf('%s=%.0f%%(m%.1f) ',methods{m},100*mean(col>0,'omitnan'),mean(col,'omitnan'))]; end
        end
        fprintf('%s\n',line);
    end
end
fprintf('\n==== 门控汇总结束 ====\n');
end
