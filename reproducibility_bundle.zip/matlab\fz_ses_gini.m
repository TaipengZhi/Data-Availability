function g = fz_ses_gini(x, fs) %#ok<INUSD>
% FZ_SES_GINI 平方包络谱(SES)的 Gini 指数——全盲指标，不使用 ff。
% 前处理与 fz_amp_env_spectrum 一致（去均值+Hann），Gini 定义在 SES(去直流) 上。
x = x(:).'; N=length(x);
w = 0.5*(1-cos(2*pi*(0:N-1)'/(N-1))).';
xw=(x-mean(x)).*w;
env = abs(hilbert(xw));
se = env.^2;
Nfft=2^nextpow2(N);
S=abs(fft(se-mean(se),Nfft)); S=S(1:Nfft/2+1);
S=S(2:end);   % 去直流 bin
ss=sort(S(:),'ascend');
n=numel(ss); tot=sum(ss);
if tot<eps
    g=0; return;
end
wt=(n-(1:n)'+0.5)/n;
g=1-2*sum((ss/tot).*wt);
end
