function c = fz_cwru_calib(outdir)
% FZ_CWRU_CALIB  CWRU 0hp 标定：T_{m,c}（方法×目标类型阈值）+ lambdaK（Pd->ef->平均K->较大lambda）。
if nargin<1, outdir=fullfile(fileparts(mfilename('fullpath')),'results_cwru'); end
opts=fz_defaults(); fs=12000; win=12000; root='D:\two_stage_vmd_fggi_project\dataset\CRWU';
methods={'Proposed','B2_gini_only','B3_gini_thnr_no_vmd','B4_fixed_vmd','B5_fixed_vmd_thnr','B1','B6'};
% 0hp 转速与目标频率（1797 rpm）
fr0=1797/60; Z=9; d=7.94e-3; D=39.04e-3;
ffC.inner=Z*fr0/2*(1+d/D); ffC.outer=Z*fr0/2*(1-d/D); ffC.ball=D/(2*d)*(1-(d/D)^2)*fr0;
cnames={'inner','outer','ball'};
% --- 加载 0hp ---
winN=loadcw(fullfile(root,'Normal Baseline','normal_0.mat'),fs,win);
winF.inner=loadcw(fullfile(root,'12k Drive End Bearing Fault Data','Inner Race','0007','IR007_0.mat'),fs,win);
winF.outer=loadcw(fullfile(root,'12k Drive End Bearing Fault Data','Outer Race','Centered','0007','OR007@6_0.mat'),fs,win);
winF.ball =loadcw(fullfile(root,'12k Drive End Bearing Fault Data','Ball','0007','B007_0.mat'),fs,win);
fprintf('标定窗口: normal=%d inner=%d outer=%d ball=%d\n',size(winN,1),size(winF.inner,1),size(winF.outer,1),size(winF.ball,1));

% --- 1) T_{m,c}: normal_0 20窗口 x 7方法 x 3目标 ---
nN=size(winN,1); nM=numel(methods); T=nan(nM,3);
calibfile=fullfile(outdir,'cwru_calib.mat');
if ~exist(outdir,'dir'), mkdir(outdir); end
if exist(calibfile,'file')
  S0=load(calibfile); T=S0.T; fprintf('载入已存 T\n');
else
 for ci=1:3
  c=cnames{ci}; th=nan(nN,nM);
  for k=1:nN
   th(k,:)=fz_run_thnr_row(methods,winN(k,:),fs,ffC.(c),opts);
  end
  T(:,ci)=quantile_rank(th).';
 end
 save(calibfile,'T','ffC','methods','win','fs','Z','d','D');
end
fprintf('T_{m,c} (行=方法 列=inner/outer/ball):\n'); disp(array2table(T,'RowNames',methods,'VariableNames',{'inner','outer','ball'}));

% --- 2) lambdaK 标定（仅 Proposed，增量存盘+断点续跑）---
lgrid=[0 .1 .25 .5 1 2];
rec=nan(numel(lgrid),3);
recfile=fullfile(outdir,'cwru_lambda_rec.mat');
if exist(recfile,'file'), S1=load(recfile); rec=S1.rec; fprintf('载入已存 rec (%d/%d 完成)\n',sum(~isnan(rec(:,1))),numel(lgrid)); end
for li=1:numel(lgrid)
 if ~isnan(rec(li,1)), fprintf('跳过 lambda=%g (已存)\n',lgrid(li)); continue; end
 opt=opts; opt.lambda_K=lgrid(li);
 pd=[]; ef=[]; kk=[];
 for ci=1:3
  c=cnames{ci}; W=winF.(c);
  for k=1:size(W,1)
   try
    R=fz_pipeline(W(k,:),fs,ffC.(c),opt,lgrid(li));
    pd=[pd; R.thnr>T(1,ci)]; ef=[ef; R.ef_pct]; kk=[kk; R.Kstar];
   catch ME
    fprintf('  lambda=%g %s k=%d 错误: %s\n',lgrid(li),c,k,ME.message);
   end
   clear R;
  end
 end
 rec(li,:)=[mean(pd), median(ef), mean(kk)];
 fprintf('lambda=%g: Pd=%.3f medEf=%.4f meanK=%.2f\n',lgrid(li),rec(li,1),rec(li,2),rec(li,3));
 save(recfile,'rec','lgrid');
end
% 选择: Pd最高 -> ef最小 -> 平均K最小 -> 较大lambda（显式，无歧义）
bestPd=max(rec(:,1)); cand=find(rec(:,1)>=bestPd-eps);
[~,ord]=sortrows([rec(cand,2), rec(cand,3), -lgrid(cand)']);
bi=cand(ord(1)); lam=lgrid(bi);
fprintf('选定 lambdaK=%.3g (Pd=%.3f medEf=%.4f meanK=%.2f)\n',lam,rec(bi,1),rec(bi,2),rec(bi,3));
save(calibfile,'-append','lam');
fprintf('已存 cwru_calib.mat\n');
end

function W=loadcw(fp,fs,win)
 if ~exist(fp,'file'), error('缺文件 %s',fp); end
 ld=load(fp); vn=fieldnames(ld); di=find(contains(vn,'_DE_time'),1);
 sig=ld.(vn{di}); sig=sig(:)'; n=floor(length(sig)/win);
 W=zeros(n,win);
 for k=1:n, W(k,:)=sig((k-1)*win+1:k*win); end
end
function [mi,bi]=minlex(S), [~,bi]=sortrows(S); mi=bi(1); end
function T=quantile_rank(X)
[n,nm]=size(X); k=ceil(0.95*n); T=nan(1,nm);
for j=1:nm, s=sort(X(:,j)); T(j)=s(k); end
end
