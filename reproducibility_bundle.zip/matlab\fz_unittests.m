function results = fz_unittests()
% FZ_UNITTESTS v2.1 冻结算法七项单元测试（冻结书 §16.3）。
% 全部通过方可进入层级核查与冒烟。输出 results 并打印 PASS/FAIL 汇总。
opts=fz_defaults();
results=struct('name',{},'pass',{},'detail',{});
pass_all=true;

try
%% ---- 测试1：Gini 盲筛不变性（改变转速/目标，候选带必须完全不变）----
fs=12000; N=12000; rng(1);
s1=fz_sim_signal(opts,1200,-10,'white',101);
[candA,~]=fz_gini_recall(s1.x,fs,opts);
% 再以不同目标/转速“假定”的 ff 调用——gini_recall 签名不含 ff，结果必须逐位一致
[candB,~]=fz_gini_recall(s1.x,fs,opts);
t1 = isequal(candA,candB);
% 额外：确认函数签名确实不接收 ff（nargin<=3）
t1b = nargin('fz_gini_recall')<=3;
record('T1 盲筛无ff残留/不变性', t1&&t1b, sprintf('cand逐位一致=%d, 签名无ff=%d',t1,t1b));

%% ---- 测试2：THNR 解析值 + 超出[fmin,fmax]邻域裁剪 ----
df=1; f=(0:600)'; A=0.5*ones(size(f));   % 背景常值
ff=150; delta=max(3*df,0.02*ff);
for h=1:3, idx=abs(f-h*ff)<=delta; A(idx)=4; end
R=fz_thnr(A,f,ff,opts);
% 独立期望
hm=false(size(f)); rng_=f>=opts.fmin_env&f<=opts.fmax_env;
for h=1:3, hm=hm|(rng_&abs(f-h*ff)<=delta); end
bg=rng_&~hm; bg(1:opts.dc_bin_exclude)=false; bg(f<0.5*df)=false;
expT=10*log10(mean(A(hm).^2)/mean(A(bg).^2));
t2a=abs(R.thnr-expT)<1e-9;
% 裁剪：ff=180 => 3阶540 > fmax500
ff2=180; R2=fz_thnr(A,f,ff2,opts);
t2b=R2.orderClipped(3)==true && R2.orderPts(3)==0 && isfinite(R2.thnr);
record('T2 THNR解析值与边界裁剪', t2a&&t2b, sprintf('thnr=%.4f vs期望%.4f; 3阶裁剪=%d',R.thnr,expT,t2b));

%% ---- 测试3：模态子集穷举 == 独立暴力枚举 ----
rng(3); K=5; Ns=4096; imfs=0.3*randn(K,Ns);
% 注入：模态2+4 含故障谐波（BPFO@1200）
[ffx,~]=fz_kinematic_ff(opts.bearing,1200,'BPFO'); tt=(0:Ns-1)/fs;
for m=[2 4]
    env=1+0.6*cos(2*pi*ffx*tt); %#ok<AGROW>
    carrier=cos(2*pi*3000*tt);
    imfs(m,:)=imfs(m,:)+0.8*env.*carrier;
end
sel=fz_mode_subset_select(imfs,fs,ffx,opts);
% 独立暴力枚举
best=-inf; bm=[];
for code=1:(2^K-1)
    mask=false(1,K); tmp=code;
    for b=1:K, mask(b)=bitand(tmp,1)==1; tmp=bitshift(tmp,-1); end
    rec=sum(imfs(mask,:),1); [Aa,ffq]=fz_amp_env_spectrum(rec,fs);
    v=fz_thnr(Aa,ffq,ffx,opts).thnr;
    if v>best, best=v; bm=find(mask); end
end
t3=abs(sel.thnr-best)<1e-9 && isequal(sort(sel.keep),sort(bm));
record('T3 子集穷举=暴力枚举', t3, sprintf('keep=[%s], thnr=%.3f vs %.3f',num2str(sel.keep),sel.thnr,best));

%% ---- 测试4：所有K/alpha候选统一收敛标准，未收敛被记录 ----
s4=fz_sim_signal(opts,1200,-10,'white',202);
R4=fz_pipeline(s4.x,fs,s4.ff,opts,opts.lambda_K);
cl=R4.convlog;
unif=all(cellfun(@(c)c.max_iter==500 && abs(c.tol-1e-7)<1e-12,cl));
hasFlag=all(cellfun(@(c)isfield(c,'converged')&&islogical(c.converged),cl));
% 未收敛候选不得参与：检查最终分解收敛（若存在未收敛搜索候选，字段已记录即合规）
t4=unif&&hasFlag;
record('T4 统一收敛标准与未收敛记录', t4, sprintf('VMD调用%d次, 未收敛%d次, 最终收敛=%d',numel(cl),R4.n_unconverged,R4.final_converged));

%% ---- 测试5：抛物线插值 整数/半频点/边界 无越界NaN ----
fs5=12000; Nfft=2^nextpow2(4096); f=linspace(0,fs5/2,Nfft/2+1); df=f(2)-f(1);
ok5=true; msg5='';
% (a)峰在整数频点
for ftarget=[100 107.36]
    A=0.01*rand(size(f)); [~,ic]=min(abs(f-ftarget)); A(ic)=10;
    [fh,inf5]=fz_parabolic_peak(A,f,ftarget,max(3*df,0.02*ftarget));
    ok5=ok5&&isfinite(fh)&&~isnan(fh)&&abs(fh-ftarget)<=df;
end
% (b)峰在两bin之间
ft=120.3; A=zeros(size(f)); [~,ic]=min(abs(f-ft)); A(ic-1:ic+1)=[7 10 7];
[fh,~]=fz_parabolic_peak(A,f,ft,max(3*df,0.02*ft)); ok5=ok5&&isfinite(fh);
% (c)邻域贴谱边界（ff极小，邻域从0开始）
A=zeros(size(f)); A(1)=5; A(2)=8;
[fh,~]=fz_parabolic_peak(A,f,0.5,max(3*df,0.02*0.5)); ok5=ok5&&isfinite(fh)&&~isnan(fh);
record('T5 抛物线插值边界安全',ok5,'整数/半频点/边界均有限无NaN');

%% ---- 测试6：确定性可复现（同配置两次，频带/K/alpha/子集完全一致）----
s6=fz_sim_signal(opts,1200,-10,'white',303);
a6=fz_pipeline(s6.x,fs,s6.ff,opts,opts.lambda_K);
b6=fz_pipeline(s6.x,fs,s6.ff,opts,opts.lambda_K);
t6=isequal(a6.selected_band,b6.selected_band)&&a6.Kstar==b6.Kstar ...
   &&abs(a6.alphaStar-b6.alphaStar)<eps&&isequal(a6.keep_modes,b6.keep_modes);
record('T6 确定性可复现',t6,sprintf('band/K=%d/alpha=%.1f/keep=[%s]',a6.selected_band(6),a6.Kstar,num2str(a6.keep_modes)));

%% ---- 测试7：阈值分位数定义 + 方法特异阈值经验Pfa（轻量闭环）----
% (a)分位数数学正确性
v=(1:100)'; Tq=fz_calibrate_threshold(v,opts);
t7a=abs(Tq-quantile_ref(v,0.95))<1e-9;
% (b)B2(无VMD,快) 在纯噪声上：0hp标定->独立正常集验Pfa
N7=4096; nCal=60; nTest=60;
cal=nan(nCal,1); tst=nan(nTest,1);
for i=1:nCal
    x=randn(1,N7); r=fz_baseline('B2_gini_only',x,fs,107.36,opts); cal(i)=r.thnr;
end
Tb=fz_calibrate_threshold(cal,opts);
for i=1:nTest
    x=randn(1,N7); r=fz_baseline('B2_gini_only',x,fs,107.36,opts); tst(i)=r.thnr;
end
pfa=mean(tst>Tb);
t7b=isfinite(Tb)&&pfa>=0&&pfa<=0.20;  % 有限样本宽松边界，主要验证机制
record('T7 阈值分位数与Pfa机制',t7a&&t7b,sprintf('95分位=%.3f(正确=%d); 独立正常集经验Pfa=%.1f%%',Tq,t7a,100*pfa));

catch ME
    record(['异常: ',ME.identifier],false,ME.message);
    disp(getReport(ME));
end

pass_all=all([results.pass]);
fprintf('\n===== 单元测试汇总 =====\n');
for i=1:numel(results)
    if results(i).pass, s='PASS'; else, s='FAIL'; pass_all=false; end
    fprintf('[%s] %s | %s\n',s,results(i).name,results(i).detail);
end
if pass_all, fprintf('\n>>> 七项单元测试全部通过 <<<\n'); else, fprintf('\n>>> 存在失败项，停止进入全量 <<<\n'); end
if ~nargout, clear results; end

    function record(name,pass,detail)
        results(end+1)=struct('name',name,'pass',logical(pass),'detail',detail);
    end
end

function q=quantile_ref(v,p)
v=sort(v(:)); pos=p*(numel(v)-1)+1; lo=floor(pos); hi=ceil(pos);
if lo==hi, q=v(lo); else, q=v(lo)+(pos-lo)*(v(hi)-v(lo)); end
end
