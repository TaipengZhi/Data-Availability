function [cand, audit] = fz_gini_recall(x, fs, opts)
% FZ_GINI_RECALL 第一级【全盲】Gini 召回（冻结书 §3 步骤②）。
% 严格不接收 ff：可行性过滤只依赖 fs、固定载频范围、gram 层级与固定最小带宽(200 Hz)。
% 1–7 级二叉等宽带，每带算平方包络谱 Gini，按 Gini 降序返回 top-Kc 候选。
%
% cand  : Kc×6，每行 [fc, bw, fl, fh, gini, level]
% audit : 各层带宽/是否被 Bmin 过滤/可行带数等（200 Hz 门槛核查，冻结书 §16.1）。
if nargin<3, opts=fz_defaults(); end
x=x(:).'; N=length(x);
Xfft=fft(x-mean(x),N);
flo=opts.freq_low; fhi=opts.freq_high_ratio*fs; Bmin=opts.min_bandwidth;

allBands=[];
levels=[];
for lv=opts.gini_level_min:opts.gini_level_max
    bw=fs/2^lv;
    filtered = bw < Bmin;
    nFeas=0;
    if ~filtered
        nb=2^lv;
        for b=1:nb
            fl=(b-1)*bw; fh=b*bw; fc=(fl+fh)/2;
            if fc<flo || fc>fhi, continue; end
            xb=fz_bandpass_mask(Xfft,N,fl,fh,fs);
            g=fz_ses_gini(xb,fs);
            if ~isfinite(g), continue; end
            allBands=[allBands; fc,bw,fl,fh,g,lv]; %#ok<AGROW>
            nFeas=nFeas+1;
        end
    end
    levels=[levels; struct('level',lv,'bandwidth',bw,'filtered_by_Bmin',filtered,'n_feasible',nFeas)]; %#ok<AGROW>
end
[~,ord]=sort(allBands(:,5),'descend');
Kc=opts.band_candidate_num;
take=min(Kc,size(allBands,1));
cand=allBands(ord(1:take),:);

audit=struct();
audit.levels=levels;
audit.all_band_count=size(allBands,1);
audit.effective_levels=[levels([levels.filtered_by_Bmin]==0).level];
audit.filtered_levels=[levels([levels.filtered_by_Bmin]==1).level];
audit.freq_low=flo; audit.freq_high=fhi; audit.Bmin=Bmin;
end
