﻿%% fz_run_pressure_manual.m
%  鎵嬪姩鐗堝帇鍔涙祴璇曪細绮夊櫔 + 闅忔満鍐插嚮锛?200rpm, -10dB
%  鍦?MATLAB 鍛戒护绐楀彛杩愯锛?%    >> cd D:\two_stage_vmd_fggi_project\frozen_v21
%    >> fz_run_pressure_manual
%  涓茶鎵ц锛屾瘡鏍锋湰鎵撳嵃杩涘害锛涙柇鐐圭画璺戯紙宸插畬鎴愮殑 .mat 鑷姩璺宠繃锛?%  鏍囧畾/楠岃瘉鍚?50锛屾晠闅?50锛涢璁℃瘡鍣０绫诲瀷绾?50-70 鍒嗛挓

clear; clc;
addpath('D:\two_stage_vmd_fggi_project\frozen_v21');
cd('D:\two_stage_vmd_fggi_project\frozen_v21');

opts = fz_defaults();
N  = round(fs * opts.sim_duration);
speed = 1200; snr = -10;
nRep = 50; nCal = 50; nVal = 50;  % 鍘嬪姏娴嬭瘯绮剧畝鏍锋湰閲?
outdir = fullfile(pwd, 'results_pressure');
if ~exist(outdir,'dir'), mkdir(outdir); end

methods = {'Proposed','B2_gini_only','B3_gini_thnr_no_vmd', ...
           'B4_fixed_vmd','B5_fixed_vmd_thnr','B1','B6'};
nM = numel(methods);

[ff, ~] = fz_kinematic_ff(opts.bearing, speed, 'BPFO');
orb_fl = opts.f_res - 750;
orb_fh = opts.f_res + 750;

fprintf('==================================================\n');
fprintf(' 鍘嬪姏娴嬭瘯: speed=%g rpm, ff(BPFO)=%.2f Hz, snr=%g dB\n', speed, ff, snr);
fprintf(' nCal=%d  nVal=%d  nRep=%d  vmd_max_iter=%d\n', nCal, nVal, nRep, opts.vmd_max_iter);
fprintf('==================================================\n');

noise_types = {'pink', 'impulse'};

for ni = 1:numel(noise_types)
    ntype = noise_types{ni};
    fprintf('\n========== [%d/%d] 鍣０绫诲瀷: %s ==========\n', ni, numel(noise_types), ntype);

    %% ---- 鏍囧畾锛歯Cal 涓函鍣０鏍锋湰 ----
    calfile = fullfile(outdir, sprintf('calib_%s.mat', ntype));
    if exist(calfile, 'file')
        S = load(calfile);
        Tm = S.Tm; Pfa = S.Pfa; PfaCI = S.PfaCI;
        fprintf(' [璺宠繃] 宸插瓨鍦ㄦ爣瀹? %s (Pfa=%s)\n', calfile, mat2str(round(Pfa,3)));
    else
        calTh = nan(nCal, nM);
        for i = 1:nCal
            t0 = tic;
            seed = 80000 + ni*100000 + i;
            x = fz_pure_noise(ntype, N, fs, opts, seed);
            calTh(i,:) = fz_run_thnr_row(methods, x, fs, ff, opts);
            fprintf('  鏍囧畾 %d/%d (%.1fs)\n', i, nCal, toc(t0));
        end
        Tm = quantile_rank(calTh);

        %% ---- 楠岃瘉锛歯Val 涓函鍣０鏍锋湰 ----
        valTh = nan(nVal, nM);
        for i = 1:nVal
            t0 = tic;
            seed = 90000 + ni*100000 + i;
            x = fz_pure_noise(ntype, N, fs, opts, seed);
            valTh(i,:) = fz_run_thnr_row(methods, x, fs, ff, opts);
            fprintf('  楠岃瘉 %d/%d (%.1fs)\n', i, nVal, toc(t0));
        end
        Pfa = mean(bsxfun(@gt, valTh, Tm), 1);
        PfaCI = nan(nM, 2);
        for m = 1:nM
            PfaCI(m,:) = wilson(sum(valTh(:,m) > Tm(m)), nVal);
        end
        save(calfile, 'ntype','ff','Tm','Pfa','PfaCI','calTh','valTh','methods');
        fprintf('  鏍囧畾瀹屾垚骞跺瓨鐩? Pfa=%s\n', mat2str(round(Pfa,3)));
    end

    %% ---- 鏁呴殰闆嗭細nRep 涓晠闅滄牱鏈?----
    chk = fullfile(outdir, sprintf('pressure_%s_%grpm_%gdB.mat', ntype, speed, snr));
    if exist(chk, 'file')
        fprintf(' [璺宠繃] 宸插瓨鍦ㄧ粨鏋? %s\n', chk);
        continue;
    end
    ef = nan(nRep,nM); thnr = nan(nRep,nM);
    nrm = nan(nRep,nM); fc = nan(nRep,nM);
    for r = 1:nRep
        t0 = tic;
        seed = 100000 + ni*100000 + r;
        s = fz_sim_signal(opts, speed, snr, ntype, seed);
        [Atrue, ~] = fz_oracle_true(s.fault, fs, orb_fl, orb_fh, opts.fmax_env);
        vals = fz_run_metrics_cell(methods, s.x, fs, ff, opts, Atrue, orb_fl, orb_fh);
        for m = 1:nM
            thnr(r,m) = vals{m}.thnr;
            ef(r,m)   = vals{m}.ef;
            nrm(r,m)  = vals{m}.nrm;
            fc(r,m)   = vals{m}.fc;
        end
        fprintf('  鏁呴殰 %d/%d (%.1fs)\n', r, nRep, toc(t0));
    end
    Pd = mean(bsxfun(@gt, thnr, Tm), 1);
    save(chk, 'speed','snr','ff','Tm','Pfa','PfaCI','thnr','ef','nrm','fc','Pd','methods','ntype');
    fprintf('  %s 瀹屾垚: Pd=%s  efMed=%s  nrmMed=%s\n', ntype, ...
        mat2str(round(Pd,2)), mat2str(round(median(ef,1),3)), mat2str(round(median(nrm,1),3)));
end

%% ---- 姹囨€?----
fprintf('\n==================================================\n');
fprintf(' 鍏ㄩ儴鍘嬪姏娴嬭瘯瀹屾垚銆傜粨鏋滅洰褰? %s\n', outdir);
fprintf('==================================================\n');
for ni = 1:numel(noise_types)
    ntype = noise_types{ni};
    chk = fullfile(outdir, sprintf('pressure_%s_%grpm_%gdB.mat', ntype, speed, snr));
    if ~exist(chk,'file'), continue; end
    S = load(chk);
    fprintf('\n[%s] Pd: %s\n', ntype, mat2str(round(S.Pd,2)));
    fprintf('     efMed: %s\n', mat2str(round(median(S.ef,1),3)));
    fprintf('     nrmMed: %s\n', mat2str(round(median(S.nrm,1),3)));
end

%% ===== 灞€閮ㄥ嚱鏁?=====
function T = quantile_rank(X)
    [n, nm] = size(X);
    k = ceil(0.95*n);
    T = nan(1, nm);
    for j = 1:nm
        s = sort(X(:,j));
        T(j) = s(k);
    end
end

function ci = wilson(k, n)
    z = 1.96; p_hat = k/n; den = 1 + z^2/n;
    ctr = (p_hat + z^2/(2*n))/den;
    hw  = z*sqrt(p_hat*(1-p_hat)/n + z^2/(4*n^2))/den;
    ci  = [ctr-hw, ctr+hw];
end

