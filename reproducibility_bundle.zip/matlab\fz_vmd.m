function [u, u_hat, omega, info] = fz_vmd(signal, alpha, tau, K, DC, init, tol, max_iter)
% FZ_VMD  冻结版 VMD（Dragomiretskiy & Zosso 2014 标准实现）
% 与项目根 functions/core_algorithm/VMD.m 数值一致，额外返回收敛审计信息，
% 以满足 v2.1 单元测试 #4（未收敛候选必须记录 K/alpha/迭代次数/原因，不得静默排除）。
%
% 输出 info.iter : 实际迭代次数
%      info.converged : 是否在 max_iter 前达到 tol（true/false）
%      info.uDiff : 最终收敛残差
%
% 所有候选（K 搜索、alpha 搜索、最终分解）在冻结流程中统一调用本函数，
% 且统一使用 tol=1e-7、max_iter=500，保证候选间收敛标准一致。

if nargin < 8 || isempty(max_iter), max_iter = 500; end

%% 1. 信号准备与镜像延拓
signal = signal(:).';
orig_T = length(signal);
if mod(orig_T,2) ~= 0
    signal = [signal, 0];
end
save_T = length(signal);
f = [signal(save_T/2:-1:1), signal, signal(save_T:-1:save_T/2+1)];
T = length(f);
t = (1:T)/T;
freqs = t - 0.5 - 1/T;
f = f - mean(f);

%% 2. 频域初始化
f_hat = fftshift(fft(f));
f_hat_plus = f_hat;
f_hat_plus(1:T/2) = 0;
omega_plus = zeros(K,1);
switch init
    case 1
        for k=1:K, omega_plus(k) = (0.5/K)*(k-1); end
    case 2
        omega_plus = sort(0.5*rand(K,1));
    otherwise
        omega_plus = zeros(K,1);
end
if DC, omega_plus(1)=0; end
lambda_hat = zeros(1,T);
u_hat_plus = zeros(K,T);
uDiff = tol + eps;
n = 0;

%% 3. ADMM 主循环
while uDiff > tol && n < max_iter
    u_hat_plus_old = u_hat_plus;
    for k=1:K
        other_idx = [1:k-1, k+1:K];
        sum_others = sum(u_hat_plus(other_idx,:),1);
        u_hat_plus(k,:) = (f_hat_plus - sum_others - lambda_hat/2) ...
            ./ (1 + alpha*(freqs - omega_plus(k)).^2);
        if ~DC || k > 1
            u_hat_k = u_hat_plus(k,T/2+1:T);
            power_k = abs(u_hat_k).^2;
            denom = sum(power_k);
            if denom > eps
                omega_plus(k) = (freqs(T/2+1:T)*power_k.')/denom;
            end
        end
    end
    lambda_hat = lambda_hat + tau*(sum(u_hat_plus,1) - f_hat_plus);
    n = n + 1;
    uDiff = 0;
    for k=1:K
        diff_k = u_hat_plus(k,:) - u_hat_plus_old(k,:);
        uDiff = uDiff + (1/T)*(diff_k*diff_k');
    end
    uDiff = abs(uDiff);
end

%% 4. 重构
N2 = T/2;
u_hat_full = zeros(K,T);
u_hat_full(:,N2+1:T) = u_hat_plus(:,N2+1:T);
u_hat_full(:,N2+1:-1:2) = conj(u_hat_plus(:,N2+1:T));
u_hat_full(:,1)=0;
u_mirror = zeros(K,T);
for k=1:K
    u_mirror(k,:) = real(ifft(ifftshift(u_hat_full(k,:))));
end
u_mirror = u_mirror(:,T/4+1:3*T/4);
if size(u_mirror,2) > orig_T
    u_mirror = u_mirror(:,1:orig_T);
end
out_T = size(u_mirror,2);
u_hat = zeros(K,out_T);
for k=1:K
    u_hat(k,:) = fftshift(fft(u_mirror(k,:)));
end
u = u_mirror.';
omega = omega_plus;

info = struct('iter',n,'converged',(uDiff<=tol),'uDiff',uDiff,'max_iter',max_iter,'tol',tol);
end
