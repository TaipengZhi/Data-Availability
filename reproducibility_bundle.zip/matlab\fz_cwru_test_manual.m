%% fz_cwru_test_manual.m
%  CWRU 三负载文件级验证 — 手动版
%  在 MATLAB 命令窗口运行：
%    >> cd D:\two_stage_vmd_fggi_project\frozen_v21
%    >> fz_cwru_test_manual
%
%  复用 0hp 标定（lambdaK=0, T 7x3），1/2/3hp 只作测试。
%  默认只跑 Proposed（约 30-40 分钟）；如需全 7 方法，取消注释 methods 行。
%  跑完自动与已有 cwru_test.mat 对比 medThnr。

clear; clc;
addpath('D:\two_stage_vmd_fggi_project\frozen_v21');
cd('D:\two_stage_vmd_fggi_project\frozen_v21');

opts = fz_defaults();
fs = 12000; win = 12000;
root = 'D:\two_stage_vmd_fggi_project\dataset\CRWU';

%% 方法选择（默认只跑 Proposed 快速验证）
methods = {'Proposed'};
% methods = {'Proposed','B2_gini_only','B3_gini_thnr_no_vmd','B4_fixed_vmd','B5_fixed_vmd_thnr','B1','B6'};

cnames = {'inner','outer','ball'};

%% 载入标定
calibfile = fullfile('results_cwru','cwru_calib.mat');
S = load(calibfile);
T = S.T; lam = S.lam;
opts.lambda_K = lam;
fprintf('==================================================\n');
fprintf(' CWRU 三负载验证（手动版）\n');
fprintf(' lambdaK=%.3g  vmd_max_iter=%d  win=%d\n', lam, opts.vmd_max_iter, win);
fprintf(' 方法: %s\n', strjoin(methods,', '));
fprintf('==================================================\n');

%% 负载与转速
loads = [1 2 3]; speed = [1772 1750 1730];
Z = 9; d = 7.94e-3; D = 39.04e-3;
nM = numel(methods);

res = struct();
for li = 1:numel(loads)
    ll = loads(li); fr = speed(li)/60;
    ff.inner = Z*fr/2*(1+d/D);
    ff.outer = Z*fr/2*(1-d/D);
    ff.ball  = D/(2*d)*(1-(d/D)^2)*fr;
    fprintf('\n=== %d hp (%d rpm) BPFI=%.2f BPFO=%.2f BSF=%.2f ===\n', ...
        ll, speed(li), ff.inner, ff.outer, ff.ball);

    for ti = 1:3
        c = cnames{ti};
        fp = getfile(root, c, ll);
        W = loadcw(fp, fs, win);
        nWin = size(W,1);
        fprintf('\n  [%s] %s  (%d 窗口)\n', c, fp, nWin);

        thnrAll = nan(nWin, nM);
        efAll   = nan(nWin, nM);
        fhatAll = nan(nWin, nM);
        fcAll   = nan(nWin, nM);

        for k = 1:nWin
            t0 = tic;
            for m = 1:nM
                try
                    Rm = fz_callone(methods{m}, W(k,:), fs, ff.(c), opts);
                    thnrAll(k,m) = Rm.thnr;
                    efAll(k,m)   = Rm.ef_pct;
                    fhatAll(k,m) = Rm.fhat;
                    if isfield(Rm,'final_converged') && ~isempty(Rm.final_converged)
                        fcAll(k,m) = Rm.final_converged;
                    end
                catch ME
                    fprintf('    [%s k=%d] ERR: %s\n', methods{m}, k, ME.message);
                end
            end
            fprintf('    k=%2d/%d: THNR=%s  fhat=%.2f  (%.1fs)\n', ...
                k, nWin, mat2str(round(thnrAll(k,:),2)), fhatAll(k,1), toc(t0));
        end

        for m = 1:nM
            key = sprintf('L%d_%s_%s', ll, c, methods{m});
            res.(key) = struct('load',ll,'type',c,'method',methods{m}, ...
                'file',fp,'nWin',nWin,'ff',ff.(c), ...
                'medThnr', median(thnrAll(:,m),'omitnan'), ...
                'medEf',   median(efAll(:,m),'omitnan'), ...
                'medFhat', median(fhatAll(:,m),'omitnan'), ...
                'detectRate', mean(thnrAll(:,m) > T(m,ti),'omitnan'), ...
                'failRate',  mean(fcAll(:,m)==0,'omitnan'));
        end
        fprintf('  -> %s medThnr=%.2f  medEf=%.3f%%  det=%.0f%%\n', ...
            c, median(thnrAll(:,1),'omitnan'), median(efAll(:,1),'omitnan'), ...
            100*mean(thnrAll(:,1) > T(1,ti),'omitnan'));
    end

    %% 正常文件 Pfa（只跑 Proposed，3 目标 max THNR > 阈值）
    fpN = fullfile(root,'Normal Baseline',sprintf('normal_%d.mat',ll));
    if exist(fpN,'file') && nM >= 1
        WN = loadcw(fpN, fs, win);
        nN = size(WN,1);
        fprintf('\n  [normal_%d] %d 窗口，跑 3 目标...\n', ll, nN);
        pfaThr = max(T(1,:));   % Proposed 跨目标最大阈值
        nPfa = 0;
        for k = 1:nN
            thmax = -inf;
            for ci = 1:3
                Rm = fz_callone('Proposed', WN(k,:), fs, ff.(cnames{ci}), opts);
                thmax = max(thmax, Rm.thnr);
            end
            if thmax > pfaThr, nPfa = nPfa + 1; end
            if mod(k,10)==0, fprintf('    normal k=%d/%d  Pfa=%.0f%%\n', k, nN, 100*nPfa/k); end
        end
        fprintf('  -> normal_%d 描述性Pfa=%.0f%% (%d/%d)\n', ll, 100*nPfa/nN, nPfa, nN);
    end
end

%% 汇总
fprintf('\n==================================================\n');
fprintf(' 手动验证汇总（Proposed）\n');
fprintf('==================================================\n');
fprintf('%-12s %-8s %-10s %-10s %-8s\n','负载','故障','medThnr','medEf(%)','检出');
for li = 1:3
    for ti = 1:3
        c = cnames{ti};
        key = sprintf('L%d_%s_Proposed', loads(li), c);
        r = res.(key);
        fprintf('L%d hp        %-8s %-10.2f %-10.3f %-8.0f%%\n', ...
            loads(li), c, r.medThnr, r.medEf, 100*r.detectRate);
    end
end

%% 与已有结果对比
oldFile = fullfile('results_cwru','cwru_test.mat');
if exist(oldFile,'file')
    fprintf('\n--- 与已有 cwru_test.mat 对比 ---\n');
    O = load(oldFile);
    fprintf('%-16s %-12s %-12s %-8s\n','条目','旧medThnr','新medThnr','差');
    fns = fieldnames(res);
    for i = 1:numel(fns)
        key = fns{i};
        if isfield(O.res, key)
            oldV = O.res.(key).medThnr;
            newV = res.(key).medThnr;
            fprintf('%-16s %-12.2f %-12.2f %-8.2f\n', key, oldV, newV, newV-oldV);
        end
    end
    fprintf('\n  差异 <0.5 dB 视为一致；0.5-2 dB 为随机波动；>2 dB 需排查。\n');
end

save(fullfile('results_cwru','cwru_test_verify.mat'),'res','methods','loads','speed','T','lam','-v7.3');
fprintf('\n结果已保存: results_cwru\\cwru_test_verify.mat\n');

%% ===== 局部函数 =====
function fp = getfile(root, c, ll)
    switch c
        case 'inner', fp = fullfile(root,'12k Drive End Bearing Fault Data','Inner Race','0007',sprintf('IR007_%d.mat',ll));
        case 'ball',  fp = fullfile(root,'12k Drive End Bearing Fault Data','Ball','0007',sprintf('B007_%d.mat',ll));
        case 'outer', fp = fullfile(root,'12k Drive End Bearing Fault Data','Outer Race','Centered','0007',sprintf('OR007@6_%d.mat',ll));
    end
end

function W = loadcw(fp, fs, win)
    if ~exist(fp,'file'), error('缺文件 %s', fp); end
    ld = load(fp); vn = fieldnames(ld);
    di = find(contains(vn,'_DE_time'), 1);
    sig = ld.(vn{di}); sig = sig(:)';
    n = floor(length(sig)/win);
    W = zeros(n, win);
    for k = 1:n, W(k,:) = sig((k-1)*win+1:k*win); end
end
