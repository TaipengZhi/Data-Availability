function fz_baseline_ext_smoke(nFault, nNormCal, nNormVal)
% FZ_BASELINE_EXT_SMOKE  B1/B6 包装联调冒烟（全量前最终联调）。
%   1) 不变性：同 x 传不同 ff，B1 选带、B6 数据驱动 ref_freq 必须不变（证明不偷用 ff）。
%   2) 小样本：20 故障 + 20 标定正常 + 20 验证正常，方法特异阈值 T_{m,BPFO}，报 Pd/Pfa/ef。
if nargin<1||isempty(nFault), nFault=20; end
if nargin<2||isempty(nNormCal), nNormCal=20; end
if nargin<3||isempty(nNormVal), nNormVal=20; end
opts=fz_defaults(); fs=opts.sim_fs; N=round(fs*opts.sim_duration);
speed=1200; snr=-10;
[ff,~]=fz_kinematic_ff(opts.bearing,speed,'BPFO');
s0=fz_sim_signal(opts,speed,snr,'white',2); noiseRms=rms(s0.noise);
methods={'B1','B6'}; nM=2;

if isempty(gcp('nocreate')), try, parpool('processes',4); catch, end; end

%% 1) 不变性测试
fprintf('\n===== ff 不变性测试（同 x，传 ff=%.1f vs ff=200）=====\n',ff);
for m=1:nM
    r1=fz_baseline_ext(methods{m},s0.x,fs,ff,opts);
    r2=fz_baseline_ext(methods{m},s0.x,fs,200,opts);
    sameBand=isequal(r1.selected_band(1:4),r2.selected_band(1:4));
    sameThnr=abs(r1.thnr-r2.thnr)<1e-6;
    fprintf('  %s: 选带相同=%d, THNR相同=%d (带=[%.0f,%.0f])\n',...
        methods{m},sameBand,sameThnr,r1.selected_band(3),r1.selected_band(4));
end

%% 2) 标定正常
fprintf('\n===== 标定正常 %d =====\n',nNormCal);
cal=nan(nNormCal,nM);
parfor i=1:nNormCal
    rng(1000+i); x=noiseRms*randn(1,N);
    tmp=nan(1,nM);
    for m=1:nM, tmp(m)=fz_baseline_ext(methods{m},x,fs,ff,opts).thnr; end
    cal(i,:)=tmp;
end
T=nan(1,nM);
for m=1:nM, T(m)=fz_calibrate_threshold(cal(:,m),opts); end

%% 3) 验证正常（Pfa）
fprintf('\n===== 验证正常 %d =====\n',nNormVal);
nt=nan(nNormVal,nM);
parfor i=1:nNormVal
    rng(2000+i); x=noiseRms*randn(1,N);
    tmp=nan(1,nM);
    for m=1:nM, tmp(m)=fz_baseline_ext(methods{m},x,fs,ff,opts).thnr; end
    nt(i,:)=tmp;
end
Pfa=mean(bsxfun(@gt,nt,T),1);

%% 4) 故障（Pd/ef）
fprintf('\n===== 故障 %d =====\n',nFault);
ft=nan(nFault,nM); ef=nan(nFault,nM);
parfor i=1:nFault
    s=fz_sim_signal(opts,speed,snr,'white',3000+i);
    tmp=nan(1,nM); tef=nan(1,nM);
    for m=1:nM
        R=fz_baseline_ext(methods{m},s.x,fs,ff,opts);
        tmp(m)=R.thnr; tef(m)=R.ef_pct;
    end
    ft(i,:)=tmp; ef(i,:)=tef;
end

fprintf('\n===== B1/B6 冒烟 (1200rpm,-10dB,f_res=%g) =====\n',opts.f_res);
fprintf('%-6s %8s %9s %9s %8s %8s\n','方法','阈值T','THNR均','ef中位%','Pd%','Pfa%');
for m=1:nM
    fprintf('%-6s %8.2f %9.2f %9.2f %8.1f %8.1f\n',methods{m},T(m),...
        mean(ft(:,m),'omitnan'),median(ef(:,m),'omitnan'),...
        100*mean(ft(:,m)>T(m),1),100*Pfa(m));
end
fprintf('=======================================================\n');
save(fullfile(fileparts(mfilename('fullpath')),'fz_baseline_ext_smoke.mat'),...
    'T','cal','nt','ft','ef','Pfa','ff');
end
