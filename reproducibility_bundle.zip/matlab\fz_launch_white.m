% 全量白噪独立启动脚本（由 Start-Process 调用，脱离工具 shell 生命周期）
here=fileparts(mfilename('fullpath'));
addpath(here);
cd(here);
diary(fullfile(here,'fz_run_white_full_log_resume3.txt'));
fz_run_white([600 1200 1800],[-15 -10 -5 0 5],50,100,100,fullfile(here,'results_white_full'));
diary off;
exit;
