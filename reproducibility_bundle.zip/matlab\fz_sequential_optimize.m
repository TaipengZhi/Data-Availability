function out = fz_sequential_optimize(xb, bw, ff, fs, opts, lambdaK)
% FZ_SEQUENTIAL_OPTIMIZE 序列化 K-alpha 寻优（冻结书 §3/§5，v2.1 邻域复核修正）。
%   目标 J(K,alpha)=bestSubsetTHNR(K,alpha) - lambda_K*K
%   1) 双锚点(alpha0, alpha_g)选 K；2) 固定 K 的 12 点对数 alpha 搜索；
%   3) v2.1 邻域复核：在【同一 alpha*】下比较 J_ref(K)=Q(K,alpha*)-lambdaK*K，
%      若邻域 K' 胜出则更新 K* 并【对新 K* 重跑一次 12 点 alpha 搜索】，至多一轮。
% 所有 VMD 候选统一 tol=1e-7、max_iter=500；未收敛候选记录并排除出排名。
if nargin<6, lambdaK=opts.lambda_K; end
x=x_b_ensure(xb);
alpha0=opts.alpha_scale*fs/bw;
alpha_g=sqrt(opts.alpha_min_ratio*opts.alpha_max_ratio)*alpha0;
aSearch=logspace(log10(opts.alpha_min_ratio*alpha0),log10(opts.alpha_max_ratio*alpha0),opts.alpha_num);
Klist=opts.K_list;
convlog={};

    function [Q,imfs,info] = bestSubset(K,a,stageTag)
        [u,~,~,info]=fz_vmd(x,a,opts.vmd_tau,K,opts.vmd_DC,opts.vmd_init,opts.vmd_tol,opts.vmd_max_iter);
        imfs=u.';  % K×N
        convlog{end+1}=struct('stage',stageTag,'K',K,'alpha',a,'iter',info.iter,...
            'converged',info.converged,'uDiff',info.uDiff,...
            'max_iter',info.max_iter,'tol',info.tol); %#ok<AGROW>
        if ~info.converged
            Q=NaN; return;   % 未收敛不参与排名（已记录，不静默排除）
        end
        res=fz_mode_subset_select(imfs,fs,ff,opts);
        Q=res.thnr;
    end

%% 1) 双锚点选 K
JK=nan(size(Klist)); JKdetail=nan(numel(Klist),2);
for i=1:numel(Klist)
    for ai=1:2
        a=alpha0; if ai==2, a=alpha_g; end
        [q,~,~]=bestSubset(Klist(i),a,'K_anchor');
        JKdetail(i,ai)=q;
    end
    qv=JKdetail(i,:); qv=qv(isfinite(qv));
    if ~isempty(qv), JK(i)=max(qv)-lambdaK*Klist(i); end
end
[ki,~]=pick_max_tie(JK,Klist,true);
Kstar=Klist(ki);

%% 2) 固定 K* 的 12 点 alpha 搜索（封装为可重入，供邻域复核后重跑一次）
[alphaStar,Qalpha,imfsAlpha] = alpha_search(Kstar);

%% 3) v2.1 邻域复核：同一 alpha* 基准
neigh=Klist(Klist>=Kstar-1 & Klist<=Kstar+1);
Jref=nan(size(neigh));
for i=1:numel(neigh)
    [q,~,~]=bestSubset(neigh(i),alphaStar,'K_neighbor');
    if isfinite(q), Jref(i)=q-lambdaK*neigh(i); end
end
[ni,~]=pick_max_tie(Jref,neigh,true);
Kbest=neigh(ni);
if Kbest~=Kstar
    Kstar=Kbest;
    [alphaStar,Qalpha,imfsAlpha]=alpha_search(Kstar);  % 对新 K* 重跑一次，至多一轮
end

out=struct('Kstar',Kstar,'alphaStar',alphaStar,'alpha0',alpha0,'alpha_g',alpha_g,...
    'aSearch',aSearch,'JK',JK,'JKdetail',JKdetail,'Qalpha',Qalpha,...
    'convlog',{convlog});

    function [aStar,Qa,imfsA]=alpha_search(K)
        Qa=nan(size(aSearch)); imfsA=cell(size(aSearch));
        for j=1:numel(aSearch)
            [q,imfsA{j},~]=bestSubset(K,aSearch(j),'alpha_search');
            Qa(j)=q;
        end
        % alpha 并列：THNR 差<tie 取离 alpha0 近者
        jj=pick_alpha_tie(Qa,aSearch,alpha0,opts.tie_db);
        aStar=aSearch(jj);
    end
end

function x=x_b_ensure(x)
x=x(:).';
end

function [idx,val]=pick_max_tie(vals, keys, smallerKey)
% 最大值；|差|<=tie(0.01) 视为并列，取 key 较小者（K 并列取小 K）
[val,~]=max(vals);
tie=find(abs(vals-val)<=0.01 & isfinite(vals));
if isempty(tie), [~,idx]=max(vals); return; end
if smallerKey
    [~,k]=min(keys(tie));
else
    [~,k]=max(keys(tie));
end
idx=tie(k);
end

function idx=pick_alpha_tie(Qa,aSet,a0,tieDb)
[val,~]=max(Qa);
tie=find(abs(Qa-val)<=tieDb & isfinite(Qa));
if isempty(tie), [~,idx]=max(Qa); return; end
[~,k]=min(abs(aSet(tie)-a0));
idx=tie(k);
end
