function fz_single_sample()
% FZ_SINGLE_SAMPLE 单样本综合核查（阶段二报告要求）：
% THNR / 频率误差 ef / 重构 NRMSE / K* / alpha* / 模态子集 / 选带 / 未收敛。
% NRMSE 口径：对【干净故障分量】施加与入选带完全相同的带通得 clean_narrow，
% 再与 VMD 子集重构 xrec 比较（同口径，避免全带/窄带量纲不一致）：
%   NRMSE = rms(xrec-clean_narrow)/rms(clean_narrow)*100%
% 另报包络波形相关系数（反映谐波时域恢复）。
opts=fz_defaults(); fs=opts.sim_fs; N=round(fs*opts.sim_duration);
speed=1200; snr=-10; seed=2;
s=fz_sim_signal(opts,speed,snr,'white',seed);
R=fz_pipeline(s.x,fs,s.ff,opts,opts.lambda_K);

% 同口径干净参考
fl=R.selected_band(3); fh=R.selected_band(4);
Xc=fft(s.fault-mean(s.fault),N);
clean_nb=fz_bandpass_mask(Xc,N,fl,fh,fs);
nrmse=rms(R.xrec-clean_nb)/rms(clean_nb)*100;

% 包络波形相关（去趋势、归一化）
[Ac,~]=fz_amp_env_spectrum(clean_nb,fs);
env_rec=R.A(:); env_cln=Ac(:);
env_corr=corr(env_rec,env_cln,'type','Pearson');

fprintf('\n===== 单样本综合核查 (1200rpm,-10dB,seed%d,N=%d) =====\n',seed,N);
fprintf('真值 ff=%.3f Hz ; 估计 fhat=%.3f Hz ; ef=%.3f%%\n',s.ff,R.fhat,R.ef_pct);
fprintf('THNR=%.2f dB\n',R.thnr);
fprintf('选带 [%.0f,%.0f] Hz (bw%.0f, 层级%d)\n',fl,fh,R.selected_band(2),R.selected_band(6));
fprintf('K*=%d  alpha*=%.1f (alpha0=%.1f, 范围[%.0f,%.0f])  keep=[%s]\n',...
    R.Kstar,R.alphaStar,R.alpha0,0.05*R.alpha0,16*R.alpha0,num2str(R.keep_modes));
fprintf('重构 NRMSE=%.2f%% ; 包络谱波形相关 r=%.3f\n',nrmse,env_corr);
fprintf('VMD 调用 %d 次, 未收敛 %d 次, 最终分解收敛=%d\n',...
    numel(R.convlog),R.n_unconverged,R.final_converged);
fprintf('=======================================================\n');
end
