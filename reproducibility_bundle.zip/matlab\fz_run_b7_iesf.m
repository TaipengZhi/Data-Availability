function res = fz_run_b7_iesf(speeds, snrs, nRep, nCal, nVal, outdir)
% Standalone runner for the same-prior baseline B7_iesf (IESFOgram/CFFOgram-style).
% Uses the SAME calibration/validation/fault seeds as fz_run_white, but only evaluates
% B7_iesf so the frozen 7-method result files are untouched.
if nargin<1||isempty(speeds), speeds=[600 1200 1800]; end
if nargin<2||isempty(snrs), snrs=[-15 -10 -5 0 5]; end
if nargin<3||isempty(nRep), nRep=50; end
if nargin<4||isempty(nCal), nCal=100; end
if nargin<5||isempty(nVal), nVal=100; end
if nargin<6||isempty(outdir)
    outdir=fullfile(fileparts(mfilename('fullpath')),'results_white_iesf');
end
if ~exist(outdir,'dir'), mkdir(outdir); end
opts=fz_defaults; fs=opts.sim_fs; N=round(fs*opts.sim_duration);
orb_fl=opts.f_res-750; orb_fh=opts.f_res+750; fmax=opts.fmax_env;
if isempty(gcp('nocreate')), try, parpool('processes',4); catch, end; end

res=struct();
for sp=1:numel(speeds)
    speed=speeds(sp);
    [ff,~]=fz_kinematic_ff(opts.bearing,speed,'BPFO');
    fprintf('\n###### B7-IESF speed=%g rpm, ff=%.2f Hz ######\n',speed,ff);

    calibfile=fullfile(outdir,sprintf('calib_%grpm.mat',speed));
    if exist(calibfile,'file')
        S=load(calibfile); Tm=S.Tm; Pfa=S.Pfa; PfaCI=S.PfaCI;
        fprintf('  load calib: %s (Pfa=%.3f)\n',calibfile,Pfa);
    else
        calTh=zeros(nCal,1);
        parfor i=1:nCal
            rng(50000+sp*100000+i); x=randn(1,N);
            R=fz_callone('B7_iesf',x,fs,ff,opts); calTh(i)=R.thnr;
        end
        Tm=quantile_rank(calTh);
        valTh=zeros(nVal,1);
        parfor i=1:nVal
            rng(60000+sp*100000+i); x=randn(1,N);
            R=fz_callone('B7_iesf',x,fs,ff,opts); valTh(i)=R.thnr;
        end
        Pfa=mean(valTh>Tm); PfaCI=wilson(sum(valTh>Tm),nVal);
        save(calibfile,'speed','ff','Tm','Pfa','PfaCI','calTh','valTh');
        fprintf('  calib done Pfa=%.3f\n',Pfa);
    end

    for sri=1:numel(snrs)
        snr=snrs(sri);
        chunk=fullfile(outdir,sprintf('b7_%grpm_%gdB.mat',speed,snr));
        if exist(chunk,'file')
            fprintf('  skip %s\n',chunk); continue;
        end
        thnr=zeros(nRep,1); ef=zeros(nRep,1); nrm=zeros(nRep,1); fc_est=zeros(nRep,1);
        parfor r=1:nRep
            seed=70000+sp*100000+sri*10000+r;
            s=fz_sim_signal(opts,speed,snr,'white',seed);
            R=fz_callone('B7_iesf',s.x,fs,ff,opts);
            thnr(r)=R.thnr; ef(r)=R.ef_pct; fc_est(r)=R.fhat;
            [Atrue,~]=fz_oracle_true(s.fault,fs,orb_fl,orb_fh,fmax);
            [Are,~]=fz_amp_env_spectrum(R.xrec,fs);
            [Ar,~]=fz_norm_env_half(Are,fs,fmax);
            L=min(numel(Ar),numel(Atrue));
            nrm(r)=norm(Ar(1:L)-Atrue(1:L),2)/max(norm(Atrue(1:L),2),eps);
        end
        Pd=mean(thnr>Tm);
        save(chunk,'speed','snr','ff','Tm','Pfa','PfaCI','thnr','ef','nrm','fc_est','Pd');
        fprintf('  %g dB: Pd=%.2f efMed=%.3f done\n',snr,Pd,median(ef));
    end
    res(sp).speed=speed; res(sp).ff=ff; res(sp).Tm=Tm; res(sp).Pfa=Pfa; res(sp).PfaCI=PfaCI;
end
save(fullfile(outdir,'b7_summary.mat'),'res');
fprintf('\n=== B7-IESF done: %s ===\n',outdir);

function T=quantile_rank(X)
n=numel(X); k=ceil(0.95*n); s=sort(X(:)); T=s(k); end
function ci=wilson(k,n)
z=1.96; p_hat=k/n; den=1+z^2/n;
ctr=(p_hat+z^2/(2*n))/den;
hw=z*sqrt(p_hat*(1-p_hat)/n+z^2/(4*n^2))/den;
ci=[ctr-hw,ctr+hw];
end
end
