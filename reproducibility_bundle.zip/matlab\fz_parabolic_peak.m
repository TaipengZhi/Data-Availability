function [fhat, info] = fz_parabolic_peak(A, f, ff, delta)
% FZ_PARABOLIC_PEAK 在 ff±delta 内找最大 bin，并用三点抛物线插值求亚-bin 峰位。
% 全方法统一使用（冻结书 §6.2）。对整数频点、半频点、频带边界均安全（不越界、不返回 NaN）。
A = A(:); f = f(:);
df = f(2)-f(1);
band = (f>=ff-delta)&(f<=ff+delta);
idx = find(band);
if isempty(idx)
    % 邻域整体越界（理论上不应发生）：退化为全谱最大并标记无效
    [~,i0] = max(A); fhat=f(i0); info=struct('i0',i0,'offset',0,'valid',false,'reason','empty_window');
    return;
end
[~,rel] = max(A(idx));
i0 = idx(rel);
% 边界：邻域端点或谱端点，无法三点插值
if i0<=1 || i0>=numel(A)
    fhat = f(i0); info=struct('i0',i0,'offset',0,'valid',false,'reason','edge');
    return;
end
ym = A(i0-1); y0 = A(i0); yp = A(i0+1);
den = (ym - 2*y0 + yp);
if ~isfinite(den) || abs(den) < eps
    fhat = f(i0); info=struct('i0',i0,'offset',0,'valid',false,'reason','flat');
    return;
end
p = 0.5*(ym - yp)/den;
p = max(-1,min(1,p));   % 抛物线顶点限制在 ±1 bin 内，防止异常外推
fhat = f(i0) + p*df;
if ~isfinite(fhat)
    fhat = f(i0); info=struct('i0',i0,'offset',0,'valid',false,'reason','nan');
    return;
end
info = struct('i0',i0,'offset',p,'valid',true,'reason','ok');
end
