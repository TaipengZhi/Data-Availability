function [An,fq_out] = fz_norm_env_half(A, fs, fmax)
% 幅值包络谱按 0-fmax 截断并按谱向量 2-范数归一化（所有方法同口径）
N=numel(A); fq=(0:N-1)*fs/N;
m=fq<=fmax; A=A(m); fq_out=fq(m);
n=norm(A,2);
if n>0, An=A/n; else, An=A; end
end
