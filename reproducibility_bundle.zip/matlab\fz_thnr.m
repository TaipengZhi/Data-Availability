function R = fz_thnr(A, f, ff, opts)
% FZ_THNR 目标谐波邻域比（冻结书 §6.1），基于幅值包络谱 A(f)。
%   THNR = 10 log10( mean_{f in Ωh} A^2 / mean_{f in Ωn} A^2 )
% 规则：
%   - 谐波邻域 Ωh = ∪_{h=1..H}[h ff-δ, h ff+δ]，δ=max(3Δf,0.02ff)，超出 [fmin,fmax] 部分裁剪；
%   - 背景 Ωn = [fmin,fmax] \ (直流 ∪ Ωh)；转频 f_rot 及其谐波【保留】在背景中，不剔除；
%     若某转频谐波 bin 落入 Ωh，则该 bin 自然计入分子（Ωh 优先），不做个案处理；
%   - 直流：前 dc_bin_exclude 个 bin 及 f<0.5Δf 剔除；
%   - [fmin,fmax] 为数据集级固定范围，对所有方法/样本一致，不随 ff 改变。
%
% 返回 R.thnr(dB)、掩膜、δ、每阶点数与是否被边界裁剪（供单元测试 #2 与审计）。

if nargin<4, opts = fz_defaults(); end
df = f(2)-f(1);
H = opts.harmonic_order;
delta = max(opts.delta_bin_coef*df, opts.delta_ff_coef*ff);

inRange = (f>=opts.fmin_env)&(f<=opts.fmax_env);
dcMask  = false(size(f));
dcMask(1:min(opts.dc_bin_exclude,numel(f))) = true;
dcMask  = dcMask | (f < 0.5*df);

harmMask = false(size(f));
orderPts = zeros(H,1); orderClipped = false(H,1);
for h=1:H
    hc = h*ff;
    lo = hc-delta; hi = hc+delta;
    m = inRange & (f>=lo & f<=hi);
    % 若理论邻域边界超出分析范围，标记裁剪
    if lo < opts.fmin_env || hi > opts.fmax_env
        orderClipped(h) = true;
    end
    harmMask = harmMask | m;
    orderPts(h) = nnz(m);
end

bgMask = inRange & ~dcMask & ~harmMask;
P = A.^2;
numPts = nnz(harmMask); denPts = nnz(bgMask);
if numPts<1 || denPts<1
    thnr = NaN;
else
    num = mean(P(harmMask));
    den = mean(P(bgMask));
    if den <= eps || num <= eps
        thnr = NaN;
    else
        thnr = 10*log10(num/den);
    end
end

R = struct('thnr',thnr,'delta',delta,'harmMask',harmMask,'bgMask',bgMask,...
    'inRange',inRange,'dcMask',dcMask,'orderPts',orderPts,'orderClipped',orderClipped,...
    'numPts',numPts,'denPts',denPts);
end
