﻿# -*- coding: utf-8 -*-
"""Generate paper_MST_v4.docx directly from frozen result files / audited CSVs.
ZERO hardcoded experimental results: every numeric table cell is read at runtime.
Fixed algorithm configuration is sourced from fz_defaults.m / white_summary.mat.
"""
import os, csv, math
import numpy as np
from scipy.io import loadmat
import h5py
from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

BASE=r"C:\Users\Zhi\Doubao\chats\2026-09-13\new-chat-1"
ST=os.path.join(BASE,"v4_stats")
ROOT=r"D:\two_stage_vmd_fggi_project\frozen_v21"
FIG=os.path.join(BASE,"figures")
OUTDOC=os.path.join(BASE,"paper_MST_v4.docx")
SPEEDS=[600,1200,1800]; SNRS=[-15,-10,-5,0,5]
def csvrows(n): return list(csv.DictReader(open(os.path.join(ST,n),encoding="utf-8-sig")))
master=csvrows("white_master.csv"); paired=csvrows("paired_nrmse.csv")
precision=csvrows("precision_proposed.csv"); cross=csvrows("cwru_crossload.csv")
def M(sp,sr,midx,field):
    r=[x for x in master if int(x["speed"])==sp and int(x["snr"])==sr and int(x["method_idx"])==midx][0]
    return r[field]

def wilson(k,n,z=1.96):
    ph=k/n; den=1+z*z/n
    c=(ph+z*z/(2*n))/den
    h=z*math.sqrt(ph*(1-ph)/n+z*z/(4*n*n))/den
    return c-h,c+h
def pcell(pd,n=50):
    k=int(round(float(pd)*n)); lo,hi=wilson(k,n)
    return "%d/%d [%.2f,%.2f]"%(k,n,lo,hi)

# pressure
pink=loadmat(os.path.join(ROOT,"results_pressure","pressure_pink_1200rpm_-10dB.mat"),squeeze_me=True)
imp =loadmat(os.path.join(ROOT,"results_pressure","pressure_impulse_1200rpm_-10dB.mat"),squeeze_me=True)
cpink=loadmat(os.path.join(ROOT,"results_pressure","calib_pink.mat"),squeeze_me=True)
cimp =loadmat(os.path.join(ROOT,"results_pressure","calib_impulse.mat"),squeeze_me=True)
# uncertainty
unc=loadmat(os.path.join(ROOT,"results_uncertainty","uncertainty.mat"),squeeze_me=True)
# B7: same-prior IESFOgram/CFFOgram-style optimized band (results_white_iesf)
B7={}; B7Pfa={}
for sp in SPEEDS:
    cb=loadmat(os.path.join(ROOT,"results_white_iesf",f"calib_{sp}rpm.mat"),squeeze_me=True)
    Tm7=float(cb['Tm']); B7Pfa[sp]=dict(Pfa=float(cb['Pfa']),
        PfaCI=[float(cb['PfaCI'][0]),float(cb['PfaCI'][1])])
    for sr in SNRS:
        d=loadmat(os.path.join(ROOT,"results_white_iesf",f"b7_{sp}rpm_{sr}dB.mat"),squeeze_me=True)
        th=d['thnr'].ravel(); ef=d['ef'].ravel(); nr=d['nrm'].ravel()
        q75=lambda a:np.percentile(a,75); q25=lambda a:np.percentile(a,25)
        B7[(sp,sr)]=dict(Pd=float(np.mean(th>Tm7)),
            ef_med=float(np.median(ef)),ef_iqr=float(q75(ef)-q25(ef)),
            nrm_med=float(np.median(nr)),nrm_iqr=float(q75(nr)-q25(nr)))
# B8: independent IESFOgram-style implementation (Mauricio et al. 2020), CSCoh + 1/3-octave tree
B8={}; B8Pfa={}
for sp in SPEEDS:
    cb8=loadmat(os.path.join(ROOT,"results_white_iesfog",f"b8_calib_{sp}rpm.mat"),squeeze_me=True)
    Tm8=float(cb8['Tm']); B8Pfa[sp]=dict(Pfa=float(cb8['Pfa']),
        PfaCI=[float(cb8['PfaCI'][0]),float(cb8['PfaCI'][1])])
    for sr in SNRS:
        d=loadmat(os.path.join(ROOT,"results_white_iesfog",f"b8_{sp}rpm_{sr}dB.mat"),squeeze_me=True)
        th=d['thnr'].ravel(); ef=d['ef'].ravel(); nr=d['nrm'].ravel()
        B8[(sp,sr)]=dict(Pd=float(np.mean(th>Tm8)),
            ef_med=float(np.median(ef)),nrm_med=float(np.median(nr)))
def ucond(name):
    r=unc["res"][name].item()
    def g(f):
        if f not in r.dtype.names: return None
        return np.atleast_1d(r[f].item())
    return dict(ef=g("ef"),thnr=g("thnr"),det=g("det"),fc=g("fc"),fhat=g("fhat"),
                ff_in=float(np.atleast_1d(r["ff_in"])[0]))
# CWRU 3hp AUROC
def hstr(h,ref):
    return "".join(chr(int(x)) for x in np.atleast_1d(h[ref][:]).flatten())
h3=h5py.File(os.path.join(ROOT,"results_cwru","cwru_audit_3hp.mat"),"r")
cwm=[hstr(h3,r) for r in h3["methods"][:].flatten()]
normal3=h3["audit3hp/normalTHNR"][:]
def auroc(pos,neg):
    return float(((pos[:,None]>neg[None,:]).mean()+0.5*(pos[:,None]==neg[None,:]).mean()))
au3={}
nmed3={}; fmed3={}
for t in ["inner","outer","ball"]:
    fth=h3[f"audit3hp/faultTHNR/{t}"][:]
    ti=["inner","outer","ball"].index(t)
    for mi,m in enumerate(cwm):
        au3[(t,m)]=auroc(fth[mi,:],normal3[ti,mi,:])
        nmed3[(t,m)]=float(np.median(normal3[ti,mi,:]))
        fmed3[(t,m)]=float(np.median(fth[mi,:]))
h3.close()
# XJTU-SY, correct LDK UER204 geometry (Z=8,d=7.92,D=34.55); cage record 1_4 excluded
hx = h5py.File(os.path.join(ROOT, "results_xjtu", "xjtu_trend_corrected_final.mat"), "r")
_xjplan = [("Bearing1_1", ["outer"], [0]), ("Bearing1_2", ["outer"], [0]),
           ("Bearing1_3", ["outer"], [0]), ("Bearing1_5", ["inner", "outer"], [0, 1])]
xj = []
for bn, tl, ridx in _xjplan:
    pr = hx[f"results/{bn}/Proposed"]
    rho = np.asarray(pr["rho"]).ravel(); de = np.asarray(pr["diffEL"]).ravel()
    fr = float(np.asarray(pr["failRate"]).squeeze())
    for ti, tname in zip(ridx, tl):
        xj.append(dict(bearing=bn, target=tname, rho=float(rho[ti]), diff=float(de[ti]), fail=fr))
hx.close()

# ---------------- document ----------------
doc=Document()
st0=doc.styles["Normal"]; st0.font.name="Times New Roman"; st0.font.size=Pt(11)
st0.element.rPr.rFonts.set(qn("w:eastAsia"),"Times New Roman")
def H(txt,lvl=1):
    p=doc.add_heading(level=lvl); r=p.add_run(txt); r.font.name="Times New Roman"
    r.font.color.rgb=RGBColor(0,0,0); return p
def body(txt,just=True):
    p=doc.add_paragraph(); p.paragraph_format.space_after=Pt(6)
    p.paragraph_format.line_spacing=1.15
    if just: p.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY
    r=p.add_run(txt); r.font.name="Times New Roman"; r.font.size=Pt(11); return p
def cap(txt):
    p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.LEFT
    p.paragraph_format.space_before=Pt(4)
    r=p.add_run(txt); r.italic=True; r.font.size=Pt(9); r.font.name="Times New Roman"
def eq(txt,num):
    p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    r=p.add_run(txt); r.font.name="Cambria Math"; r.font.size=Pt(11)
    r2=p.add_run("\t("+str(num)+")"); r2.font.size=Pt(10)
def fig(path,w=6.2):
    doc.add_picture(path,width=Inches(w)); doc.paragraphs[-1].alignment=WD_ALIGN_PARAGRAPH.CENTER
def shade(cell,hexc):
    tcPr=cell._tc.get_or_add_tcPr(); sh=OxmlElement("w:shd")
    sh.set(qn("w:val"),"clear"); sh.set(qn("w:fill"),hexc); tcPr.append(sh)
def table(headers,data,caption=None,widths=None,fs=9):
    if caption: cap(caption)
    t=doc.add_table(rows=1,cols=len(headers)); t.style="Light Grid Accent 1"
    t.alignment=WD_TABLE_ALIGNMENT.CENTER
    hc=t.rows[0].cells
    for i,h in enumerate(headers):
        hc[i].text=""; r=hc[i].paragraphs[0].add_run(h); r.bold=True; r.font.size=Pt(fs)
        r.font.name="Times New Roman"; shade(hc[i],"DCE6F1")
    for row in data:
        c=t.add_row().cells
        for i,v in enumerate(row):
            c[i].text=""; rr=c[i].paragraphs[0].add_run(str(v)); rr.font.size=Pt(fs)
            rr.font.name="Times New Roman"
    return t

# ===== Title =====
p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=p.add_run("Target-guided resonance-band selection for bearing fault-harmonic measurement under strong noise")
r.bold=True; r.font.size=Pt(15); r.font.name="Times New Roman"
p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=p.add_run("Author names and affiliations withheld for double-anonymous review"); r.italic=True; r.font.size=Pt(10)

# ===== Abstract =====
H("Abstract",1)
body("Bearing characteristic frequencies are often known approximately from geometry and shaft speed, "
"but their harmonics can be obscured by broadband, coloured, or impulsive interference. This work treats "
"the task as targeted harmonic measurement rather than general fault classification. A frequency-blind "
"multiresolution filterbank first enumerates the feasible resonance bands, which a squared-envelope Gini index "
"orders without using the target; at the chosen sampling rate all five feasible bands are retained. A target "
"harmonic-to-noise ratio (THNR) then adjudicates "
"the band; in the full procedure it also selects the variational-mode-decomposition (VMD) parameters and the "
"retained mode subset. The harmonic frequency is estimated by parabolic interpolation, while method-specific "
"thresholds are calibrated at a nominal false-alarm probability of 5%. In simulations over three shaft speeds, "
"five white-noise levels, and 50 repetitions per condition, the full method reached a mean detection probability "
f"of {np.mean([float(M(s,-15,0,'Pd')) for s in SPEEDS]):.2f} at -15 dB and unit detection from -10 dB upward; "
"at -10 dB it retained unit detection under both pink noise and random impacts. The central finding is "
"architectural: separating frequency-blind candidate construction from target-aware THNR adjudication, rather than the VMD "
"stage itself, supplied most of the detection gain on average at -15 dB and under random-impact interference. VMD did not raise detection probability and did not "
"consistently reduce frequency error; its reproducible benefit was a relative reduction of the normalised "
"envelope-spectrum shape error at -15 and -10 dB in the simulation study, confirmed by paired 10 000-bootstrap "
"intervals that did not include zero, whereas simpler target "
"adjudication was equal or better at high SNR. Input perturbations of +/-1% in speed and +/-0.5% in rolling-element "
"diameter did not change detection decisions. A within-file CWRU case study showed complete descriptive separation "
"for inner- and outer-race faults, but the full method did not improve ball-fault separation relative to simple "
"target adjudication; the simpler target-adjudication stage (B3) is therefore recommended as the primary detector, with the VMD refinement enabled only when a cleaner low-SNR envelope spectrum is required. The evidence "
"supports targeted detection and frequency measurement within a known-frequency setting, not universal fault "
"classification or remaining-life assessment.")
body("Keywords: bearing fault harmonics; targeted measurement; target-guided band selection; variational mode "
"decomposition; strong noise; input-parameter sensitivity",just=False)

# ===== 1 Introduction =====
H("1. Introduction",1)
body("Envelope analysis remains a standard tool for rolling-bearing diagnosis because repetitive fault impacts "
"modulate structural resonances at the kinematic fault frequencies. In strong noise, however, the principal "
"difficulty is not merely to display an envelope spectrum. It is to choose a resonance band without using the "
"target frequency prematurely, to recover measurable target harmonics, and to state how reproducibly the resulting "
"frequency and detection decision can be obtained. Envelope analysis of resonance-band bearing impulses and second-order cyclostationary indicators are well established condition-monitoring tools [22, 23]. Fast Kurtogram and Gini-based spectral selectors address "
"impulsiveness-based band selection, but impulsive interference can itself dominate these criteria [2-6, 19]. "
"Maximum-correlated-kurtosis deconvolution instead enhances repetitive impulses, but its result depends on the "
"assumed period and on the filter settings [7, 18]. Targeted estimators such as the IESFOgram and the candidate-fault-"
"frequency optimization gram show that prior kinematic information can be used more directly when the measurement "
"objective is known [8, 9, 17, 20].")
body("Variational mode decomposition can separate narrow-band components, but its result depends on the mode count "
"and the bandwidth penalty [1]. Existing bearing applications use fixed settings, global optimisation, or coarse-to-"
"fine parameter searches [10-14, 21]. These approaches do not by themselves resolve three related problems. First, a "
"target-aware score can leak into the initial band search if that search is allowed to read the fault frequency. "
"Second, the same score can be used both to optimise a method and to validate it, which is circular. Third, "
"apparently independent signal windows cut from one recording can be mistaken for independent mechanical "
"experiments, which inflates the apparent evidence.")
body("This study narrows the claim to measurement of known bearing-fault harmonics. The proposed procedure builds the "
"candidate bands in a frequency-blind multiresolution stage, which the squared-envelope Gini index only orders "
"without using the target, and uses THNR for target-aware adjudication; the full procedure additionally searches "
"the VMD configuration. The first contribution is therefore the explicit separation of frequency-blind candidate "
"construction from target adjudication. The second is a controlled study of where the subsequent VMD stage does and "
"does not add value, reported through frequency error, detection probability, spectral-shape error, false-alarm "
"behaviour, numerical convergence, and input sensitivity under one common protocol. The study does not claim blind "
"discovery of an unknown fault type.")
body("The measurement framing matters because it changes what counts as evidence. In a classification study the "
"central quantity is the proportion of correctly labelled independent cases, and the denominator must consist of "
"independent machines or independent test runs. In a harmonic-measurement study the central quantities are instead "
"whether a target peak is detected at a declared false-alarm level, how accurately and reproducibly its frequency is "
"estimated, and how faithfully the harmonic spectrum is reconstructed. The experiments below report negative results "
"as plainly as positive ones: the VMD stage did not improve detection or frequency estimation, the ball-fault case "
"was not improved by the full method. "
"Reporting these boundaries is intended to make the positive claims, which concern targeted detection and low-SNR relative reduction of envelope-spectrum shape error, more defensible rather than to broaden them.")
fig(os.path.join(FIG,"fig1_flowchart.png"),5.8)
cap("Figure 1. Frozen processing procedure. The initial multiresolution enumeration does not read the target fault "
"frequency; the squared-envelope Gini index only orders the bands, and target information enters only after the "
"feasible candidate bands have been retained.")

# ===== 2 Method =====
H("2. Measurement principle and frozen method",1)
H("2.1 Target frequencies and stated prior information",2)
body("For a bearing with Z rolling elements, rolling-element diameter d, pitch diameter D, zero contact angle, and "
"shaft-rotation frequency f_rot, the inner-race, outer-race, and ball-spin targets are calculated as")
eq("f_BPFI = (Z/2) f_rot (1 + d/D);   f_BPFO = (Z/2) f_rot (1 - d/D);   f_BSF = (D/2d) f_rot (1 - (d/D)\u00b2)",1)
body("The selected target is denoted f_f. Geometry and speed are inputs, not outputs. The method is appropriate when "
"a target family is known approximately in advance and the task is to measure whether its harmonics are present and "
"where the spectral peak lies.")
H("2.2 Frequency-blind multiresolution candidate enumeration",2)
body("A binary filterbank is built over the full spectrum at levels l = 1..7, each band having bandwidth "
"B_l = f_s / 2^l. For a non-negative squared-envelope sequence a_i with sorted values a_(i), the Gini index is")
eq("G = [ 2 \u03a3_i i a_(i) - (n + 1) \u03a3_i a_(i) ] / [ n \u03a3_i a_(i) ]",2)
body("A fixed minimum bandwidth B_min = 1000 Hz excludes levels whose bands are narrower than this value; at "
"f_s = 12 kHz this retains levels l = 1, 2 and 3 (bandwidths 6000, 3000 and 1500 Hz), with candidate centres "
"restricted to 1000-0.4 f_s Hz. After these restrictions exactly five feasible bands exist: one at l = 1 (centre "
"3000 Hz), two at l = 2 (1500 and 4500 Hz) and two at l = 3 (2250 and 3750 Hz). The procedure retains the five "
"bands with the largest Gini indices, so at this sampling rate it keeps every feasible band; the Gini index here "
"orders the candidates rather than eliminating them. Genuine Gini selection occurs only in the B2 baseline, which "
"takes the single top-ranked band. The B_min value was fixed before the reported experiments to cover the declared "
"resonance and sideband span and is unchanged across fault types; the blind stage never reads f_f at run time.")
body("The Gini index is still computed because it measures the concentration of the squared-envelope distribution "
"while remaining a property of that band alone; unlike a target-conditioned score it cannot favour a band merely "
"because energy happens to lie near the assumed fault frequency. Keeping all feasible bands preserves alternatives "
"for the subsequent target adjudication, whereas committing to a single blind band can be wrong under impulsive "
"interference, as the B2 results demonstrate. The two stages are therefore assigned different responsibilities: "
"candidate construction is frequency-blind and must not discard a band that could contain a resonance, and the "
"target stage chooses among those alternatives using the measurement objective. This separation is what allows the "
"use of f_f later without contaminating the initial search.")
H("2.3 THNR target measurement",2)
body("For the amplitude envelope spectrum A(f), harmonic neighbourhoods are centred on h f_f for h = 1, 2, 3. Their "
"half-width is delta = max(3 Delta f, 0.02 f_f). The background set is the 0-500 Hz range after removing the first "
"three bins and the harmonic neighbourhoods. THNR is")
eq("THNR = 10 log10 [ mean_{f \u2208 \u03a9_h} A(f)\u00b2 / mean_{f \u2208 \u03a9_n} A(f)\u00b2 ]",3)
body("Overlapping harmonic bins are counted once. Shaft-frequency components are retained in the background; if such "
"a bin falls inside a harmonic neighbourhood it is counted in the numerator. THNR is a target-conditioned output and "
"an internal selection criterion; it is not presented as an objective-independent validation metric.")
H("2.4 Sequential VMD search and mode selection",2)
body("Each retained band is demodulated and evaluated by THNR without VMD. The highest-scoring band enters a "
"sequential VMD search over K in {2,3,4,5}. For the selected-band width B, the reference bandwidth penalty is")
eq("\u03b1_0 = 200 f_s / B",4)
body("Twelve logarithmically spaced alpha values from 0.05 alpha_0 to 16 alpha_0 are tested. The search is "
"deliberately sequential rather than a full K-by-alpha grid. Two anchor penalties (alpha_0 and the geometric mean "
"alpha_g = sqrt(0.05\u00b716) alpha_0) are first evaluated for every K, giving eight decompositions; the provisional "
"K is chosen by the anchor objective. A 12-point alpha search is then run at that K, followed by a neighbour re-check "
"at the same alpha over K-1, K and K+1. If a neighbour wins, K is updated and one further 12-point alpha search is "
"run, at most once. Every candidate uses the same tolerance 10^-7 and the same 500-iteration budget. For every "
"converged decomposition, all non-empty mode subsets are enumerated, at most 31 for K = 5. The objective is")
eq("J(K,\u03b1) = max_{S} THNR(S; K,\u03b1) - \u03bb_K K",5)
body("The simulation study used the frozen pilot value lambda_K = 0.5. For CWRU, lambda_K was selected only from the "
"0 hp calibration data over {0, 0.1, 0.25, 0.5, 1, 2}; the selection rule (highest detection probability, then "
"smallest frequency error, then smallest mean K, then the larger penalty on a tie) selected lambda_K = 0 because it "
"gave the smallest median frequency error among settings tied on detection. These are study-specific settings, not "
"evidence for a universal penalty, and over the tested grid the settings were practically indistinguishable. "
"Non-converged candidates are excluded from ranking and logged.")
body("VMD solves a constrained variational problem in which the modes are jointly band-limited around their centre "
"frequencies and reconstruct the input; the penalty alpha controls bandwidth, so a fixed alpha cannot be appropriate "
"for both narrow and wide candidate bands. Defining alpha_0 relative to the selected-band width, rather than as an "
"absolute number, keeps the effective bandwidth comparable across filterbank levels. The sequential search avoids "
"the cost and the ranking instability of evaluating every K-alpha pair, while the anchor, alpha and neighbour stages "
"still revisit both dimensions. The mode-subset enumeration then decides which decomposed components carry the "
"target harmonics, instead of assuming that all modes or a single kurtosis-maximising mode should be retained. "
"Because subset selection itself uses THNR, its benefit is judged in the results by the independent NRMSE endpoint, "
"not by the THNR values it maximises.")
# pseudocode box
cap("Algorithm 1. Target-guided resonance-band selection (full procedure).")
algo=["Input: signal x, sampling rate f_s, target frequency f_f, fixed options",
"1. Build binary filterbank B_l = f_s/2^l, l = 1..7; discard bands with B_l < B_min.",
"2. Compute the squared-envelope Gini index for every feasible band (f_f not used).",
"3. Order feasible bands by Gini; at f_s = 12 kHz all five feasible bands are retained (Gini selects only the top band in B2).",
"4. For each retained band, band-pass, form the envelope spectrum and compute THNR.",
"5. Select the band with the largest THNR (Gini rank breaks a tie).",
"6. [Full] Sequential K-alpha VMD search on that band (anchors \u2192 12-point alpha \u2192 neighbour re-check).",
"7. [Full] Enumerate mode subsets; retain the subset maximising J; reconstruct.",
"8. Locate the fundamental peak in the target neighbourhood; refine parabolically.",
"9. Declare detection when THNR exceeds the method-specific calibrated threshold T_m.",
"Output: detection decision, estimated frequency f\u0302_f, reconstructed envelope spectrum."]
t=doc.add_table(rows=len(algo),cols=1); t.style="Table Grid"; t.alignment=WD_TABLE_ALIGNMENT.CENTER
for i,a in enumerate(algo):
    c=t.rows[i].cells[0]; c.text=""; rr=c.paragraphs[0].add_run(a)
    rr.font.name="Consolas"; rr.font.size=Pt(8.5)
H("2.5 Frequency estimate and detection rule",2)
body("The fundamental peak is located inside the prescribed target neighbourhood and refined by three-point "
"parabolic interpolation. Zero padding is used only to sample the discrete spectrum more densely and is not "
"interpreted as improved physical resolution. A method- and target-specific threshold T_m is the rank-based 95th "
"percentile of independent calibration THNR values from normal-only signals. Detection is declared when THNR exceeds "
"that threshold. Thresholds are calibrated once per speed on normal-only interference records (and once at 0 hp "
"for CWRU) and are then applied unchanged across fault SNR levels; they are not re-tuned from fault data. "
"Calibration and validation normal records are unit-variance Gaussian white noise with no fault component; because "
"THNR is invariant to a global amplitude scaling, their absolute RMS need not be matched to any fault SNR, and the "
"thresholds apply unchanged across SNR levels. The declared SNR is defined only for the fault realisations, where "
"the additive interference RMS is set relative to the fault-component RMS. Because the fundamental peak is searched only within the declared target "
"neighbourhood (half-width max(3 Delta f, 0.02 f_f)), the reported e_f is conditional on this known-frequency prior "
"window and should not be read as a blind frequency-identification accuracy. Achieved false-alarm proportions and "
"Wilson intervals are reported separately rather than assumed equal to the nominal 5%.")
H("2.6 Comparison methods",2)
body("The comparisons are B1 Fast Kurtogram [2]; B2 Gini-only band selection (the top Gini band, no target); B3 Gini "
"retains the five feasible bands followed by THNR band selection without VMD; B4 fixed-parameter VMD (K = 4, alpha = 2000) with "
"a kurtosis-selected single mode; B5 fixed VMD with THNR mode-subset selection; and B6 a data-driven adaptation of "
"two-stage VMD [13]. B7 is an authors' own supplementary same-prior control added after the main experiment (not part "
"of the pre-specified protocol and not a reproduction of the published IESFOgram/CFFOgram, which build on spectral-coherence "
"feature maps): using f_f it simply selects the (centre, bandwidth) "
"pair that maximises THNR over a fine paving (bandwidths 1000-4000 Hz, 200 Hz centre steps, fully inside the Nyquist band) "
"and then demodulates, with no VMD stage. B8 is an independent implementation following the main principles of the published "
"IESFOgram [8]: it estimates a bi-variable cyclic spectral coherence CSCoh(alpha,f) from segmented FFTs and frequency-shift "
"cross-correlation, paves a 1/3-octave band tree, and selects the band maximising a background-subtracted feature integrated "
"over the fault harmonic orders k f_f (k=1..5, background offset by f_f/3), using the same known f_f prior; demodulation and "
"the downstream envelope/peak extraction are shared. Because this implementation was not validated against the authors' code or "
"public reference examples (estimator, normalisation, tree boundaries and final IES construction may differ), B8 is reported "
"as an exploratory same-prior comparison, not as a benchmark of IESFOgram itself. B8 runs on the 1.0 s record with about 28 "
"averaged cyclic-coherence segments. "
"B1 and B6 do not use f_f for band selection; the local B6 implementation estimates a resonance "
"reference from the high-frequency power spectrum instead of using a dataset lookup. All methods use the same "
"downstream envelope spectrum, peak interpolation and metric definitions. B2-B5 and the full method receive the same "
"target-frequency prior where required.")
# parameter table
cap("Table 1. Frozen configuration. Algorithm settings are fixed across all reported conditions; study-specific "
"calibrated values are flagged. Source: fz_defaults.m and the run configuration.")
prows=[["Sampling rate / duration","12 000 Hz / 1.0 s"],
["Shaft speeds","600, 1200, 1800 r/min"],
["White-noise SNR levels","-15, -10, -5, 0, 5 dB"],
["Fault repetitions per condition","50"],
["Resonance carrier (main / boundary stress)","3600 Hz / 3000 Hz"],
["Damping ratio r","0.05"],
["Decay rate \u03b2 = 2\u03c0 f_res r","2\u03c0\u00b73600\u00b70.05 \u2248 1131 s\u207b\u00b9"],
["Gini levels / retained bands","l = 1..7 / all feasible (5 at 12 kHz)"],
["Minimum bandwidth B_min","1000 Hz"],
["Candidate centre range","1000 - 0.4 f_s Hz"],
["Harmonic orders H / neighbourhood half-width","3 / max(3 \u0394f, 0.02 f_f)"],
["Envelope analysis range","0 - 500 Hz"],
["VMD K list / alpha points","{2,3,4,5} / 12 log points"],
["alpha_0 / alpha span","200 f_s / B; 0.05 alpha_0 to 16 alpha_0"],
["VMD tolerance / iteration budget","10^-7 / 500"],
["Mode-subset enumeration","all non-empty (\u2264 31 at K = 5)"],
["lambda_K (simulation / CWRU)","0.5 / 0 (study-specific)"],
["Nominal false-alarm quantile","0.95 (P_fa = 5%)"],
["Random-impact rate / median amplitude / INR","5 s^-1 / 1.0 / 0 dB"]]
table(["Item","Frozen value"],prows,fs=8.5)

# ===== 3 Design =====
H("3. Experimental design and statistical protocol",1)
H("3.1 Simulation model",2)
body("The simulated outer-race signal is a train of exponentially decaying impacts recurring at the characteristic "
"period T_f, which excite a structural resonance, plus an interference term:")
eq("x(t) = A \u03a3_i exp[-\u03b2(t - i T_f)] cos[2\u03c0 f_res (t - i T_f)] u(t - i T_f) + n(t) + x_imp(t),   i T_f \u2264 t,  T_f = 1/f_f",6)
body("The fault period T_f is computed from the 6205 geometry and the actual shaft speed (no fixed 13 Hz shortcut); "
"f_res = 3600 Hz and beta = 2 pi f_res times the damping ratio 0.05. The interference n(t) is Gaussian white noise "
"for the main study and 1/f-shaped pink noise for the colour test, each normalised so that its RMS equals the fault "
"RMS divided by 10^(SNR/20). For random-impact stress, a -10 dB white floor is added and isolated interferers arrive "
"as a Poisson count with a nominal rate of 5 s^-1 (each record contains at least one interferer); each has a carrier drawn uniformly within 1000-0.4 f_s Hz, a log-normal "
"amplitude (median equal to the fault-impact peak, log-sigma 0.5), and the same exponential decay; the interferer "
"waveform is scaled to an interference-to-noise power ratio INR = 0 dB. White-noise levels are -15 to 5 dB at 600, "
"1200 and 1800 r/min with 50 independent fault realisations per condition. Pink and random-impact stress tests use "
"50 fault, 50 calibration-normal and 50 validation-normal realisations at 1200 r/min and -10 dB. A 3000 Hz carrier "
"is treated only as a filterbank-boundary stress case because it lies on a binary-band boundary.")
body("All stochastic generators are deterministic under explicit seeds. Each fault condition uses the seed "
"70000 + 100000 times the speed index + 10000 times the SNR index + the repetition index, so every realisation can "
"be regenerated exactly and the same noise realisation can be presented to several methods, which is what makes the "
"paired comparisons valid. Normalisation is performed against the fault-component RMS before the interference is "
"added, so the declared SNR refers to fault power versus interference power rather than to an arbitrary post-mixing "
"scale. The Poisson arrival process and the Gaussian and log-normal variates used for the random-impact stress are "
"implemented directly rather than through a statistics toolbox, both to remove toolbox dependence and to keep the "
"draws reproducible. No threshold, parameter or metric is tuned on the fault realisations used for reporting.")
proto=[["White noise, per speed (cal/val shared across SNR levels)","100","100","-"],
["White noise, per speed-SNR condition","-","-","50"],
["Pink-noise stress (1200 r/min, -10 dB)","50","50","50"],
["Random-impact stress (1200 r/min, -10 dB)","50","50","50"]]
table(["Study","Calibration normal","Validation normal","Fault realisations"],proto,
  "Table 2. Normal-signal and fault sample counts. The 100 calibration and 100 validation normal records are "
  "generated once per speed and reused unchanged across the five white-noise SNR levels; fault realisations are "
  "50 per speed-SNR cell.",fs=8.5)
H("3.2 Independent endpoints",2)
body("Relative frequency error and the normalised envelope-spectrum shape error are")
eq("e_f = | f\u0302_f - f_f | / f_f \u00d7 100%",7)
eq("NRMSE_env = || A_rec - A_true ||_2 / || A_true ||_2",8)
body("The reference spectrum A_true is the envelope spectrum of the clean fault component after a fixed, method-"
"independent oracle band centred on 3600 Hz with a 1500 Hz width ([2850, 4350] Hz), truncated to 0-500 Hz and "
"L2-normalised; each method's reconstructed envelope spectrum is truncated and normalised in the same way. Detection "
"probability is a thresholded-THNR endpoint and is therefore not fully independent of the internal objective, whereas "
"e_f and NRMSE_env do not reuse the THNR formula. Both are computed over all 50 fault realisations, including "
"those not detected: the fundamental peak is always located within the prescribed target neighbourhood, and "
"convergence for the non-VMD methods is flagged by convention. Results are summarised by proportions, medians, "
"interquartile ranges and Wilson intervals rather than window-level p values.")
H("3.3 Input-parameter sensitivity",2)
body("At 1200 r/min and -10 dB this is a 3x3 factorial grid of speed error (-1%, 0, +1%) and rolling-element-"
"diameter error (-0.5%, 0, +0.5%), with the pitch diameter D held fixed throughout. The diameter effect is "
"evaluated within each speed setting; the nine cells use the same 20 noise realisations, giving 180 paired "
"evaluations. This is an input-sensitivity study, not a metrologically traceable uncertainty budget, because "
"probability distributions and calibration traceability for speed and geometry are not supplied.")

# ===== 4 Simulation results =====
H("4. Simulation results",1)
fig(os.path.join(FIG,"fig2_representative.png"),6.2)
cap("Figure 2. Representative 1200 r/min, -10 dB white-noise realisation. The selected resonance band is "
"3.0-4.5 kHz and the reconstructed envelope spectrum resolves the BPFO harmonics.")
H("4.1 White-noise performance",2)
fig(os.path.join(ST,"fig_pd_heatmap.png"),5.6)
cap("Figure 3. Detection probability across the 15 speed-SNR conditions for the full method, B3, B1 and B6. Each "
"cell contains 50 fault realisations; the final panel adds the independent IESFOgram-style implementation (B8, exploratory).")
# Table 2: Pd for P/B3/B2 across 15
d2=[]
for sp in SPEEDS:
    for sr in SNRS:
        d2.append([sp,sr,pcell(M(sp,sr,0,'Pd')),pcell(M(sp,sr,2,'Pd')),
                   pcell(B7[(sp,sr)]['Pd']),pcell(B8[(sp,sr)]['Pd'])])
table(["Speed (r/min)","SNR (dB)","Full: det. (Wilson 95% CI)","B3: det. (Wilson 95% CI)","B7 (own fine-grid): det.","B8 (IESFOgram): det."],d2,
      "Table 3. Detection by condition for the full method, B3, the authors' own same-prior fine-grid THNR band "
      "search (B7, supplementary control), and the independent IESFOgram-style implementation (B8, exploratory, "
      "band selection). Cells show detected/total realisations and the Wilson 95% binomial interval; n = 50 per cell. "
      "Even unit detection carries a lower bound near 0.93, so 50/50 is not evidence that the true rate is exactly 1.",fs=8.0)
body(f"At -15 dB the full method reached {float(M(600,-15,0,'Pd')):.2f}, {float(M(1200,-15,0,'Pd')):.2f} and "
f"{float(M(1800,-15,0,'Pd')):.2f} at the three speeds (mean "
f"{np.mean([float(M(s,-15,0,'Pd')) for s in SPEEDS]):.2f}), and from -10 dB upward it detected all realisations. "
f"Critically, the full method's detection probability never exceeded B3 across the 15 conditions (12 ties and three "
f"conditions in which B3 was higher). The average -15 dB improvement over B2, especially at higher speeds, supports target-aware adjudication after "
f"frequency-blind multiresolution candidate enumeration, whereas the absence of a gap between B3 and the full method shows that VMD did not supply additional "
f"detectability.")
# B7 same-prior comparison paragraph
b7m=np.mean([B7[(s,-15)]['Pd'] for s in SPEEDS])
body(f"B7 is an authors' own supplementary control added after the main white-noise experiment, not part of the "
f"pre-specified protocol and not a reproduction of the published IESFOgram/CFFOgram. It reads f_f and simply maximises "
f"paving without any VMD stage. At -15 dB its detection probabilities were "
f"{B7[(600,-15)]['Pd']:.2f}, {B7[(1200,-15)]['Pd']:.2f} and {B7[(1800,-15)]['Pd']:.2f} "
f"(mean {b7m:.2f}), i.e. numerically at or above B3 and above the full method at all three speeds. The Wilson intervals overlap, "
f"however, and this run was not designed as an equivalence or superiority test. Its median frequency error "
f"at -15 dB ({B7[(600,-15)]['ef_med']:.3f}, {B7[(1200,-15)]['ef_med']:.3f}, "
f"{B7[(1800,-15)]['ef_med']:.3f} %) was no better than B3 and was often worse, because at low SNR the optimiser can "
f"commit to a band whose noise peak lies near f_f. Its median NRMSE_env lay between B3 and the full method, which "
f"again places the small low-SNR shape contribution with VMD rather than with band search alone. B7's achieved "
f"validation false-alarm proportions were {B7Pfa[600]['Pfa']:.2f}, {B7Pfa[1200]['Pfa']:.2f} and "
f"{B7Pfa[1800]['Pfa']:.2f} across speeds (Wilson intervals "
f"[{B7Pfa[600]['PfaCI'][0]:.2f},{B7Pfa[600]['PfaCI'][1]:.2f}], "
f"[{B7Pfa[1200]['PfaCI'][0]:.2f},{B7Pfa[1200]['PfaCI'][1]:.2f}], "
f"[{B7Pfa[1800]['PfaCI'][0]:.2f},{B7Pfa[1800]['PfaCI'][1]:.2f}]). At 600 rpm B7's 0.11 operating point is looser than the full method's ~0.07, so part of its higher detection there may reflect a more relaxed working point rather than a stronger method. On the coarse 100-sample validation set its achieved false-alarm rate is reported as measured rather than forced to the nominal 5%.")
body(f"B8, our independent IESFOgram-style implementation, shows a strongly SNR-dependent behaviour: at -15 dB its "
f"detection was {B8[(600,-15)]['Pd']:.2f}, {B8[(1200,-15)]['Pd']:.2f} and {B8[(1800,-15)]['Pd']:.2f} (mean "
f"{np.mean([B8[(s,-15)]['Pd'] for s in SPEEDS]):.2f}), and it reached unit detection only at +5 dB. Its median frequency "
f"error at -15 dB was {B8[(600,-15)]['ef_med']:.2f}, {B8[(1200,-15)]['ef_med']:.2f} and {B8[(1800,-15)]['ef_med']:.2f} %, "
f"an order of magnitude larger than B3 or the full method on the same records; its validation false-alarm proportions were "
f"{B8Pfa[600]['Pfa']:.2f}, {B8Pfa[1200]['Pfa']:.2f} and {B8Pfa[1800]['Pfa']:.2f}. On this implementation, these parameters "
f"and the 1 s stationary records, the direct target-frequency envelope adjudication outperformed this cyclic-coherence band "
f"selection at low SNR. We make no general claim about IESFOgram itself: without validation against the authors' implementation, "
f"the short-record weakness observed here may reflect this specific reconstruction rather than the published method.")
# Table 3: ef & nrm medians/IQR for Proposed
d3=[]
for sp in SPEEDS:
    for sr in SNRS:
        d3.append([sp,sr,
            f"{float(M(sp,sr,0,'ef_med')):.3f} ({float(M(sp,sr,0,'ef_iqr')):.3f})",
            f"{float(M(sp,sr,0,'nrm_med')):.3f} ({float(M(sp,sr,0,'nrm_iqr')):.3f})"])
table(["Speed","SNR","Full e_f med (IQR), %","Full NRMSE med (IQR)"],d3,
      "Table 4. Full-method frequency error and envelope-shape error by condition (median; IQR in parentheses).",fs=8.5)
fig(os.path.join(ST,"fig_ef_nrm_curves.png"),6.4)
cap("Figure 4. Median frequency error (left) and NRMSE_env (right) versus SNR at the three speeds; bands show the IQR.")
body("Frequency errors were small for several methods once the target was detected, and the full method did not show a "
"consistent frequency-error advantage over B3 (it was lower in seven conditions and higher in eight). The absolute "
"frequency-error magnitude at -15 dB remained below about 0.14 Hz. The main low-SNR advantage of the full method was "
"therefore spectral-shape fidelity rather than peak interpolation or detection: at -15 and -10 dB its NRMSE was the "
"lowest, whereas at higher SNR B2 and B3 often preserved the complete envelope shape at least as well. Optimising for "
"THNR does not guarantee preservation of the entire envelope-spectrum shape.")
fig(os.path.join(ST,"fig_paired_nrmse.png"),6.0)
cap("Figure 5. Paired NRMSE_env difference (full method minus B3) versus SNR. Negative values favour the full method; "
"bars are 10 000-bootstrap 95% intervals on the median over identical noise realisations. Points for the three "
"speeds are horizontally offset for visibility.")
body("Because the same noise realisation is processed by both methods, the appropriate comparison is the paired "
"difference within each realisation. The largest and most consistent shape benefit occurred at -15 and -10 dB, "
"where the median paired difference was negative at all three speeds, the bootstrap intervals did not include "
"zero, and 92-100% of realisations favoured the full method. Smaller negative differences with intervals that "
"also did not include zero extended to -5 dB at 1200 and 1800 r/min and to 0 dB at 1800 r/min. At higher SNR the "
"paired difference was positive, most clearly at 600 r/min, where simple band selection was better. The VMD "
"benefit is therefore concentrated in the difficult low-SNR regime, with its exact boundary depending on speed. "
"The 15 per-condition intervals are reported as descriptive effect-size summaries rather than as 15 independent "
"hypothesis tests, and no multiplicity correction is applied.")
H("4.2 Coloured-noise and random-impact stress tests",2)
# Table 4 stress
def srow(name,d,cal,m):
    return [name,["Pd","e_f (%)","NRMSE","P_fa"][0] ]
stress=[]
for m,lab in [(0,"Full"),(1,"B2"),(2,"B3"),(3,"B4"),(4,"B5"),(5,"B1"),(6,"B6")]:
    stress.append(["Pink",lab,f"{float(np.atleast_1d(pink['Pd'])[m]):.2f}",
        f"{float(np.median(pink['ef'][:,m])):.3f}",f"{float(np.median(pink['nrm'][:,m])):.3f}",
        f"{float(np.atleast_1d(cpink['Pfa'])[m]):.2f}"])
for m,lab in [(0,"Full"),(1,"B2"),(2,"B3"),(3,"B4"),(4,"B5"),(5,"B1"),(6,"B6")]:
    stress.append(["Impulse",lab,f"{float(np.atleast_1d(imp['Pd'])[m]):.2f}",
        f"{float(np.median(imp['ef'][:,m])):.3f}",f"{float(np.median(imp['nrm'][:,m])):.3f}",
        f"{float(np.atleast_1d(cimp['Pfa'])[m]):.2f}"])
table(["Noise","Method","Pd","e_f med (%)","NRMSE med","P_fa"],stress,
      "Table 5. Stress-test results at 1200 r/min and -10 dB (medians over 50 fault realisations); all VMD methods use the fixed 500-iteration budget and the same 50-calibration / 50-validation / 50-fault protocol as the main study. "
      "",fs=8.5)
body("Under pink noise, six methods reached unit detection and several achieved comparably small frequency errors "
"(a ceiling effect), while the full method gave the lowest NRMSE; B6 was clearly weaker. Under random impacts, both "
"the full method and B3 reached unit detection, whereas blind Gini selection (B2) fell to 0.64; the full method's "
"frequency error was not lower than B3's but its NRMSE was. This ablation indicates that target adjudication supplies "
"most of the detection gain under impulsive interference, whereas the VMD stage mainly yields a relative "
"reduction of envelope-spectrum shape error under low-SNR simulation. These finite-sample false-alarm deviations must be considered when interpreting detection: the full "
f"method's achieved P_fa was {float(np.atleast_1d(cimp['Pfa'])[0]):.2f} with Wilson interval "
f"[{float(cimp['PfaCI'][0][0]):.2f}, {float(cimp['PfaCI'][0][1]):.2f}], while B3 reached "
f"{float(np.atleast_1d(cimp['Pfa'])[2]):.2f}.")
body("The achieved false-alarm operating points should be read alongside detection. Table 6 lists, for every method "
"and speed, the achieved validation P_fa on 100 independent normal records together with its Wilson interval. The "
"nominal target is 5%, and several methods remained near it, but the spread was not negligible: B6 at 1200 r/min "
"reached 0.19, and a few other points lay outside the 0.05 reference. Accordingly, the Pd values in Table 3 are "
"reported as operating points produced by the nominal-5% calibration rule, not as detection probabilities at a "
"strictly controlled 5% false-alarm rate. This matters for the B3 comparison: in the -15 dB conditions B3's "
"achieved P_fa was no higher than the full method's and was often lower, while its detection was no lower, so the "
"conclusion that B3 is at least as effective cannot be explained away by a more permissive operating point.")

MTH=["Full","B2","B3","B4","B5","B1","B6"]
def pfa_lk(sp,mi):
    r=[x for x in master if int(x["speed"])==sp and int(x["method_idx"])==mi][0]
    return float(r["Pfa"]),float(r["PfaCI_lo"]),float(r["PfaCI_hi"])
dp=[]
for sp in SPEEDS:
    for mi in range(7):
        p,lo,hi=pfa_lk(sp,mi)
        dp.append([sp,MTH[mi],"%.2f [%.2f, %.2f]"%(p,lo,hi)])
table(["Speed (r/min)","Method","Achieved P_fa (Wilson 95% CI)"],dp,
      "Table 6. Achieved validation false-alarm proportion by method and speed (100 independent normal records; "
      "nominal target 5%). Brackets are Wilson 95% CIs. Pd must be read as a nominal-5%-rule operating point rather "
      "than as detection at a controlled 5% P_fa.",fs=8.0)

# --- ROC / AUROC and Pd at a common empirical P_fa=5% (no algorithm rerun) ---
import csv as _csv, collections as _col
_rocp=os.path.join(ST,"roc_summary.csv")
if os.path.exists(_rocp):
    _bys=_col.defaultdict(dict)
    
    with open(_rocp,encoding="utf-8-sig") as _fh:
        for _r in _csv.DictReader(_fh):
            _bys[_r["method"]][(int(_r["speed"]),int(_r["snr"]))]=(float(_r["auroc"]),float(_r["Pd_commonPfa5"]))
            
    dt=[]
    for _m in ["Full","B2","B3","B4","B5","B1","B6"]:
        a15=np.mean([_bys[_m][(s,-15)][0] for s in SPEEDS])
        a10=np.mean([_bys[_m][(s,-10)][0] for s in SPEEDS])
        amix=np.mean([_bys[_m][(s,n)][0] for s in SPEEDS for n in [-15,-10,-5,0,5]])
        pmix=np.mean([_bys[_m][(s,n)][1] for s in SPEEDS for n in [-15,-10,-5,0,5]])
        dt.append([_m,"%.3f"%a15,"%.3f"%a10,"%.3f"%amix,"%.2f"%pmix])
    table(["Method","AUROC -15 dB","AUROC -10 dB","Mixed AUROC (5 SNR)","Post-hoc Pd@P_fa=5%"],dt,
          "Table 7. Mixed ROC/AUROC obtained by pooling fault records across the five equally weighted SNR levels (negative class = 100 validation normal records, "
          "positive class = 50 fault records per SNR, 250 in total), and detection probability at a post-hoc matched empirical operating point "
          "(P_fa = 5%, threshold = 95th percentile of the validation normal THNR), so methods are compared at one matched post-hoc "
          "point rather than at their individually calibrated nominal thresholds. Because easy high-SNR records dominate the pooled positives, the mixed AUROC smooths over the hard -15 and -10 dB conditions, for which a per-SNR breakdown is given in the supplementary material. This is descriptive discrimination at a matched post-hoc point, not a prospective calibrated operating point and not a "
          "paired superiority test.",fs=8.0)
    body("To avoid treating individually calibrated nominal thresholds as a fair 5% working point, Table 7 reports threshold-free "
         "mixed AUROC and the detection probability re-estimated at one post-hoc matched empirical P_fa of 5%. At that matched point the full method "
         "and B3 remain very close (AUROC about 0.99), whereas B6, whose nominal validation P_fa drifted well above 5%, loses most of "
         "its apparent detection advantage. The mixed AUROC weights each of the five SNR levels equally but is dominated by easy high-SNR records and should not be read as a hard-condition figure; the low-SNR per-condition values are reported separately. Wilson interval overlap is used only as a descriptive statement of uncertainty; it is not "
         "treated as evidence of equivalence or non-inferiority between methods.")

H("4.3 Input-parameter sensitivity",2)
order=[("sp2_ge2","0","0 (nominal)"),
       ("sp1_ge2","-1%","0 (speed only)"),("sp3_ge2","+1%","0 (speed only)"),
       ("spm1_gem05","-1%","-0.5%"),("spm1_gep05","-1%","+0.5%"),
       ("spz_gem05","0","-0.5%"),("spz_gep05","0","+0.5%"),
       ("spp1_gem05","+1%","-0.5%"),("spp1_gep05","+1%","+0.5%")]
def iqr(x):
    q=np.percentile(x,[25,75]); return q[1]-q[0]
d5=[]
for nm,se,ge in order:
    c=ucond(nm)
    d5.append([se,ge,f"{c['ff_in']:.2f}",
               f"{np.median(c['ef']):.3f} ({iqr(c['ef']):.3f})",
               f"{np.median(c['thnr']):.2f} ({iqr(c['thnr']):.2f})",
               f"{int(np.sum(c['det']))}/20"])
table(["Speed error","d error","Input f_f (Hz)","e_f med (IQR), %","THNR med (IQR), dB","Detected (/20)"],d5,
      "Table 8. 3x3 factorial sensitivity to entered speed and rolling-element diameter d, with D held fixed; "
      "each cell uses the same 20 paired realisations.",fs=8.5)
body("All 180 paired evaluations remained detected and no final VMD solution failed. Median e_f ranged from "
f"{min(np.median(ucond(n)['ef']) for n,_,_ in order)*1:.3f}% to "
f"{max(np.median(ucond(n)['ef']) for n,_,_ in order)*1:.3f}%, and median THNR from "
f"{min(np.median(ucond(n)['thnr']) for n,_,_ in order):.2f} to "
f"{max(np.median(ucond(n)['thnr']) for n,_,_ in order):.2f} dB. The d-perturbed cells now differ slightly as "
"expected, confirming that the corrected perturbation acts on d alone. These data support local robustness within "
"the tested perturbation box only; they do not establish robustness to larger speed errors, contact-angle error, "
"slip, or uncertain bearing geometry.")

# ===== 5 Case studies =====
H("5. Experimental case studies",1)
H("5.1 CWRU cross-load case study",2)
body("The Case Western Reserve University data were analysed with 0 hp used for parameter and threshold calibration "
"and 1-3 hp reserved for testing [15]. At each test load, one 0.007-inch file was used for each of inner-race, "
"centred outer-race and ball faults, together with one normal file. Four 0 hp files (one normal and one each of "
"inner, centred outer and ball faults) were used for calibration, and twelve files at 1-3 hp were used for evaluation, "
"i.e. twelve independent raw test files rather than 120 independent mechanical experiments. Ten windows were extracted from each fault file and 40 from each "
"normal file; windows are used only for descriptive within-file separation, with no window-level p values.")
fig(os.path.join(ST,"fig_cwru_crossload.png"),6.4)
cap("Figure 6. CWRU cross-load fault-window median THNR for the full method, B3, B1 and B6 (descriptive).")
# Table 8: 3hp normal/fault medians, delta, descriptive AUROC
lab2name={"Full":"Proposed","B3":"B3_gini_thnr_no_vmd","B1":"B1","B6":"B6"}
d6=[]
for t in ["inner","outer","ball"]:
    for lab in ["Full","B3","B1","B6"]:
        nm=lab2name[lab]
        n=nmed3[(t,nm)]; f=fmed3[(t,nm)]; au=au3[(t,nm)]
        d6.append([t,lab,f"{n:.1f}",f"{f:.1f}",f"{f-n:+.1f}",f"{au:.2f}"])
table(["Fault (3 hp)","Method","Normal med. THNR","Fault med. THNR","Delta THNR","Desc. AUROC"],d6,
      "Table 9. Within-file separation at the 3 hp file pair: median THNR on normal (40 windows) and fault "
      "(10 windows) windows, their difference, and the descriptive AUROC. Windows within a file are correlated; "
      "this is a within-file summary, not an independent mechanical comparison. Cross-load fault medians are shown "
      "in Figure 6.",fs=8.0)
fig(os.path.join(ST,"fig_cwru_3hp_boxplots.png"),6.4)
cap("Figure 7. CWRU 3 hp window-level THNR distributions (N = normal, F = fault) for the full method, B3, B1 and B6; "
"windows within a file are correlated.")
body("Inner- and outer-race windows were completely separated from their load-matched normal windows for the full "
f"method and B3 (3 hp descriptive AUROC 1.00; the full method's inner/outer AUROC was "
f"{au3[('inner','Proposed')]:.2f}/{au3[('outer','Proposed')]:.2f}). The full method did not, however, improve ball-"
f"fault separation. At the 3 hp file pair, B3 achieved a descriptive AUROC of {au3[('ball','B3_gini_thnr_no_vmd')]:.2f}, "
f"whereas the full method achieved {au3[('ball','Proposed')]:.2f}, indicating that VMD-based reconstruction can "
"suppress or distort the weak ball-fault evidence in this file pair. Because per-window data were retained only for "
"the 3 hp pair, this comparison is stated for that file pair and is not generalised across loads. Thresholds "
"calibrated at 0 hp did not maintain a 5% false-alarm rate across loads, so cross-load detection is not used as the "
"principal experimental claim.")
H("5.2 XJTU-SY degradation-trend case study", 2)
body("Four XJTU-SY LDK UER204 run-to-failure records at 35 Hz and 12 kN were analysed retrospectively "
"with the correct bearing geometry (eight rolling elements, ball diameter 7.92 mm, pitch diameter 34.55 mm) "
"and their documented final fault location [16]. The fifth record, Bearing1_4, developed a cage fault and is "
"excluded because the procedure defines inner-, outer- and ball-spin targets but not a cage frequency. Bearing1_5 "
"was a composite fault and its inner and outer components are reported separately. The horizontal accelerometer "
"channel (the first CSV column) sampled at 25.6 kHz was used; the first 12000 samples (0.469 s) of each record were "
"analysed, matching the cut length used in simulation and giving a narrowband envelope resolution of about 2.1 Hz near "
"the outer-race frequency. Up to 50 records were uniformly spaced over each life cycle. THNR was computed per record; "
"Spearman correlation between THNR and record order and the late-minus-early median difference are reported descriptively.")
d7 = [[x["bearing"], x["target"], f"{x['rho']:+.2f}", f"{x['diff']:+.1f}", f"{x['fail']*100:.0f}%"] for x in xj]
table(["Bearing", "Target", "Spearman rho", "Late-early THNR (dB)", "Final-solution failure"], d7,
      "Table 10. XJTU-SY per-record THNR trend for the full method (correct UER204 geometry; cage record excluded).", fs=8.5)
body("For the three outer-race records THNR showed a positive association with record order (Spearman rho 0.65-0.72, "
"late-minus-early median +7.9 to +10.7 dB), and the outer component of the composite record showed the same positive "
"association (rho 0.63, +5.3 dB). The inner component of the composite record did not (rho -0.19, -0.5 dB). Record order "
"is only a proxy for degradation rather than a calibrated damage measure, so within these correctly geared records the "
"result supports a positive association with record order in the evaluated outer-race series but does not establish "
"quantitative damage tracking or a universal remaining-life indicator: the inner component of a composite fault was not "
"associated with record order, and the cage record is outside the defined target set.")

# ===== 6 Discussion =====
H("6. Discussion",1)
H("6.1 What the ablation supports",2)
body("The comparisons do not justify attributing the gains to the VMD stage. B3 matched the full method in detection "
"across the white-noise conditions and under random impacts and showed no consistent difference in frequency error, which "
"indicates that target-aware THNR adjudication after a frequency-blind candidate stage is the main source of detectability. ""Accordingly, the procedure is best read as two layers: a mandatory core (frequency-blind multiresolution enumeration followed by target-aware THNR band adjudication, i.e. B3) that supplies detection and frequency estimation, and an optional refinement layer (the sequential VMD reconstruction, i.e. the full method) switched on only when a cleaner normalised envelope spectrum is wanted at low SNR; B3 is therefore the recommended primary measurement procedure, not merely an ablation baseline. "
"The supplementary same-prior B7 search reinforces this: it reads f_f and optimises THNR over a fine paving, but at -15 dB "
"was numerically at or above B3 and above the full method on detection, with overlapping Wilson intervals and a looser "
"600-rpm validation operating point; it showed no frequency-error advantage and placed envelope shape between B3 and the full method. "
"The independent IESFOgram-style implementation (B8) was markedly less robust on this 1 s stationary record (unit detection only at "
"+5 dB, an order-of-magnitude larger low-SNR frequency error). Because B8 was not validated against the authors' code, this is reported "
"as a bounded, implementation-specific observation rather than a benchmark of IESFOgram; the distinction between cyclic spectral correlation and coherence in short records is discussed elsewhere [17]; it does not establish that cyclic-coherence band "
"selection is inferior in general, and a direct comparison with the published implementation remains future work. The VMD stage added reproducible value chiefly through lower envelope-spectrum shape error at -15 and -10 dB; at "
"high SNR simpler methods preserved the complete envelope shape at least as well. The proper claim is improved "
"targeted harmonic measurability under difficult noise, not uniform superiority on every endpoint. Because all feasible bands were retained here, the Gini ranking did not affect inclusion and is not the principal source of gain.")
H("6.2 When the full method is and is not warranted",2)
body("For clarity: the Core procedure (B3) is the recommended primary measurement procedure; the Optional refinement (full VMD) is enabled only for a cleaner low-SNR envelope spectrum. A direct consequence is that the full procedure and the simpler B3 are appropriate for different tasks. If the "
"application requires only a detection decision and an estimate of the fault frequency, B3 is the more cost-effective "
"choice: it obtained detection no lower than the full method, comparable frequency error, and a false-alarm operating "
"point at least as close to the nominal 5%, while avoiding the VMD search entirely. The full method has a clear and "
"specific justification only when a relative reduction of the normalised envelope-spectrum shape error under low-SNR "
"simulation is required. The paired intervals support such an improvement at -15 and -10 dB, but this endpoint is "
"only meaningful where a clean reference spectrum exists, i.e. in simulation, and the absolute NRMSE at -15 dB remains "
"of order unity; it is not claimed to demonstrate more accurate reconstruction on measured data. Because both spectra entering NRMSE_env "
"are L2-normalised, this endpoint quantifies relative spectral shape rather than absolute harmonic amplitude, energy "
"or fault severity, and no claim of absolute amplitude accuracy is made. Presenting the full method as a universal "
"upgrade would not be supported by these data.")
body("This also clarifies how the reported metrics should be read in practice. Detection probability and the "
"false-alarm interval describe a binary operating point; the frequency error describes peak localisation; and "
"NRMSE_env describes the agreement of the whole reconstructed harmonic spectrum with a method-independent "
"reference. A method can be best on one of these without being best on the others, and the results show exactly that "
"pattern. A deployment that logs an alarm should therefore use the simpler target adjudication, while a deployment "
"that stores a reconstructed spectrum for relative harmonic-pattern interpretation in a noisy environment is the case "
"in which the additional VMD search is justified. Treating the metrics as interchangeable, or optimising a single "
"internal score and reporting it as external validation, would obscure these distinctions.")
H("6.3 Numerical convergence and computational budget",2)
body("The 500-iteration budget was fixed for all principal VMD candidates. Final selected solutions converged in all "
"reported white-noise, stress, CWRU and sensitivity cases. Candidate-level non-convergence was, however, common: the "
"proportion of samples containing at least one non-converged candidate ranged from about 26% to 100% across the conditions (up to about six non-converged candidates per sample at the median), even "
"though the final solution always converged. In a rescue audit, 74 non-converged candidates drawn from 30 samples "
"were rerun for 2000 iterations; all converged, two changed the selected configuration (objective change up to "
"0.18 dB), and recalculation of those two cases did not change any detection decision. The deterministic search "
"attempts 23 or 24 decompositions when the neighbour re-check does not change K and 35 or 36 when it does (the extra "
"call is the final decomposition). Thus the fixed budget introduces a small, audited selection sensitivity but did "
"not alter the examined binary outcomes; it should not be described as numerical equivalence to an unlimited "
"optimisation.")
H("6.4 Scope and limitations",2)
body("Four boundaries are material. First, the target frequency must be known approximately; the method is not a blind "
"classifier. Second, the fixed 1000 Hz minimum bandwidth retains only three filterbank levels at 12 kHz, so transfer "
"to other sampling rates and resonance widths requires a declared scaling rule. Third, the CWRU study has only one "
"raw file per load-fault pair and cannot support population-level inferential claims; in particular the ball-fault "
"comparison is restricted to the 3 hp file pair. Fourth, the sensitivity analysis perturbs inputs deterministically "
"and is not a complete uncertainty budget. A supplementary authors' own same-prior fine-grid THNR search (B7) was "
"nevertheless included: it was numerically at or above B3 and the full method on detection at -15 dB, but with overlapping "
"intervals and a looser operating point, gave no frequency-error advantage, and lay between them on envelope shape, so "
"no claim of superiority over such targeted searches is made beyond this protocol. Multiple independent machines, probabilistic speed and geometry models, and explicit slip variation "
"remain to be studied.")

# ===== 7 Conclusion =====
H("7. Conclusion",1)
body("A target-guided resonance-band selection procedure was developed for measuring known bearing-fault harmonics "
"under strong noise. Frequency-blind candidate construction prevents the target frequency from influencing the "
"initial search, with the squared-envelope Gini index only ordering the bands, while THNR adjudicates the band and, "
"in the full procedure, the VMD configuration. The evidence shows that the separation of frequency-blind candidate "
"construction from target adjudication, rather than VMD, supplied most of the detection gain on average at -15 dB and under random-impact interference; VMD "
"did not raise detection or consistently reduce frequency error, but it reproducibly reduced the normalised "
"envelope-spectrum shape error at -15 and -10 dB in simulation, while simpler adjudication was equal or better at high SNR. The CWRU case study supports "
"strong inner- and centred outer-race separation but not a ball-fault advantage for the full method. In the XJTU-SY records THNR was positively associated with record order in outer-race series but not for the inner component of a composite fault. The method is "
"best interpreted as a targeted harmonic-"
"measurement procedure with explicit prior information and stated operating limits, rather than as a universal "
"bearing-fault diagnostic system.")

# ===== Declarations =====
H("Acknowledgements",1)
body("Acknowledgement and funding details are withheld for double-anonymous review and will be restored in the "
"accepted manuscript. The authors declare no competing interests.")

H("Data availability",1)
body("The CWRU bearing data used in this study are publicly available from the original Case Western Reserve University "
"bearing data center. The simulated signals were generated by the authors. The frozen simulation configurations, "
"analysis and plotting code, random seeds, and the derived result tables (CSV/MAT files) that reproduce every "
"figure and table in this paper will be deposited in a public repository on acceptance. During peer review, an "
"anonymous read-only copy of the code, configurations and derived results is available to the editors and reviewers "
"on request; the repository link will be inserted here at acceptance.")

H("Generative AI statement",1)
body("During manuscript preparation the authors used the following tools: Doubao (ByteDance; Doubao model, accessed "
"September 2026) and OpenAI Codex (model GPT-5). Both tools were used only for language polishing, Word document "
"formatting, MATLAB/Python code inspection and plotting-script generation. No tool was used to acquire, generate, "
"alter or fabricate any experimental observation, signal or numerical result. The authors independently checked all "
"text, equations, references, figures and reported values against the frozen source files and derived result tables, "
"and take full responsibility for the submitted work.")

# ===== References =====
H("References",1)
refs=["[1] Dragomiretskiy K and Zosso D 2014 Variational mode decomposition IEEE Trans. Signal Process. 62 531-544, doi:10.1109/TSP.2013.2288675",
"[2] Antoni J 2007 Fast computation of the kurtogram for the detection of transient faults Mech. Syst. Signal Process. 21 108-124, doi:10.1016/j.ymssp.2006.07.004",
"[3] Wang D, Tse P W and Tsui K L 2013 An enhanced kurtogram method for fault diagnosis of rolling element bearings Mech. Syst. Signal Process. 35 176-199, doi:10.1016/j.ymssp.2012.09.010",
"[4] Miao Y, Zhao M and Lin J 2017 Improvement of kurtosis-guided-grams via Gini index for bearing fault feature identification Meas. Sci. Technol. 28 125001, doi:10.1088/1361-6501/aa8c8c",
"[5] Miao Y, Wang J, Zhang B and Li H 2022 A practical framework of the Gini index in the application of machinery fault feature extraction Mech. Syst. Signal Process. 165 108333, doi:10.1016/j.ymssp.2021.108333",
"[6] Wang Y, Huang J, Liu H, Liu S, Fan Z and Niu Y 2026 A novel narrowband filtering demodulation method based on adaptive multi-level spectra segmentation strategy and its application in bearing fault diagnosis Machines 14 934, doi:10.3390/machines14080934",
"[7] McDonald G L, Zhao Q and Zuo M J 2012 Maximum correlated kurtosis deconvolution and its application to rolling element bearing fault diagnosis Mech. Syst. Signal Process. 33 237-255, doi:10.1016/j.ymssp.2011.09.015",
"[8] Mauricio A, Smith W A, Randall R B, Antoni J and Gryllias K 2020 Improved envelope spectrum via feature optimisation-gram (IESFOgram): a novel tool for rolling element bearing diagnostics under non-stationary operating conditions Mech. Syst. Signal Process. 144 106891, doi:10.1016/j.ymssp.2020.106891",
"[9] Cheng Y, Wang S-H, Chen B, Mei G, Zhang W, Peng H and Tian G 2022 An improved envelope spectrum via candidate fault frequency optimisation-gram for bearing fault diagnosis J. Sound Vib. 523 116746, doi:10.1016/j.jsv.2022.116746",
"[10] Zhang M, Jiang Z and Feng K 2017 Research on variational mode decomposition in rolling bearings fault diagnosis of the multistage centrifugal pump Mech. Syst. Signal Process. 93 460-493, doi:10.1016/j.ymssp.2017.02.019",
"[11] Jiang X, Wang J, Shi J, Shen C, Huang W and Zhu Z 2019 A coarse-to-fine decomposing strategy of VMD for extraction of weak repetitive transients in fault diagnosis of rotating machines Mech. Syst. Signal Process. 116 668-692, doi:10.1016/j.ymssp.2018.07.014",
"[12] Wang X and Hu J 2021 A novel parameter-adaptive VMD method based on grey wolf optimisation with minimum average mutual information for incipient fault detection Shock Vib. 2021 6640387, doi:10.1155/2021/6640387",
"[13] Siripokharattana J, Akahane R and Henmi N 2025 Two-stage variational mode decomposition for bearing fault diagnosis under low rotational speed and high mechanical noise conditions J. Adv. Mech. Des. Syst. Manuf. 19 JAMDSM0047, doi:10.1299/jamdsm.2025jamdsm0047",
"[14] Ye M, Yan X and Jia M 2021 Rolling bearing fault diagnosis based on VMD-MPE and PSO-SVM Entropy 23 762, doi:10.3390/e23060762",
"[15] Smith W A and Randall R B 2015 Rolling element bearing diagnostics using the Case Western Reserve University data: a benchmark study Mech. Syst. Signal Process. 64-65 100-131, doi:10.1016/j.ymssp.2014.03.012",
"[16] Lei Y, Han T, Wang B, Li N, Yan T and Yang J 2019 XJTU-SY rolling element bearing accelerated life test datasets: a tutorial J. Mech. Eng. 55(16) 1-6, doi:10.3901/JME.2019.16.001",
"[17] Kestel K, Peeters C, Antoni J, Leclere Q, Girardin F, Brijder R and Helsen J 2024 A discussion on the differences between the cyclic spectral correlation and coherence for cyclostationarity-based condition monitoring Mech. Syst. Signal Process. 218 111518, doi:10.1016/j.ymssp.2024.111518",
"[18] Chen P et al. 2024 Markov modeling of signal condition transitions for bearing diagnostics under external interference conditions IEEE Trans. Instrum. Meas. 73, doi:10.1109/TIM.2024.3383497",
"[19] Guo J, Liu Y et al. 2024 Differgram: a convex optimization-based method for extracting the optimal frequency band for fault diagnosis of rotating machinery Expert Syst. Appl. 238 123051, doi:10.1016/j.eswa.2023.123051",
"[20] Shi Y, Wang F et al. 2026 Compound fault diagnosis of rolling bearings based on the PSD-guided cyclostationarity feature mode decomposition IEEE Sensors J., doi:10.1109/JSEN.2026.3628404",
"[21] Feng C et al. 2026 Adaptive resonance demodulation for bearing fault diagnosis via spectral trend reconstruction and weighted logarithmic energy ratio Sensors 26 2066, doi:10.3390/s26072066",
"[22] Randall R B and Antoni J 2011 Rolling element bearing diagnostics-a tutorial Mech. Syst. Signal Process. 25 485-520, doi:10.1016/j.ymssp.2010.07.017",
"[23] Antoni J 2009 The spectral kurtosis: a useful tool for characterising non-stationary signals Mech. Syst. Signal Process. 20 282-307, doi:10.1016/j.ymssp.2005.09.001",
"[24] Liu R, Yang B, Zio E and Chen X 2018 Artificial intelligence for fault diagnosis of rotating machinery: a review Mech. Syst. Signal Process. 108 330-347, doi:10.1016/j.ymssp.2018.03.016",
"[25] Lei Y, Yang B, Jiang X, Jia F, Li N and Nandi A K 2022 Applications of machine learning to machine fault diagnosis: a review and roadmap Mech. Syst. Signal Process. 138 106587, doi:10.1016/j.ymssp.2020.106587"]
for rf in refs:
    p=doc.add_paragraph(); p.paragraph_format.space_after=Pt(2)
    r=p.add_run(rf); r.font.size=Pt(8.5); r.font.name="Times New Roman"

doc.save(OUTDOC)
wc=sum(len(p.text.split()) for p in doc.paragraphs)
print("saved",OUTDOC,"approx body words:",wc)
