﻿function R = fz_b8_iesfog(x, fs, ff, opts)
% B8 IESFOgram - faithful implementation of Mauricio et al., MSSP 144 (2020) 106891.
% (1) bi-variable cyclic spectral coherence CSCoh(alpha,f), cyclic step ~10 Hz;
% (2) 1/3-octave band tree (bandwidth ~0.2316*center);
% (3) integrate CSCoh over band -> IES_band(alpha);
% (4) DF = sum over fault harmonic windows k*ff (+/- ff/2) minus background at ff/3;
% (5) argmax DF -> demodulate with the SAME downstream used for all methods.
if nargin<4, opts=fz_defaults(); end
x=x(:).'; N=length(x);
flo=opts.freq_low; fhi=opts.freq_high_ratio*fs;
Nh=5;

% (1) cyclic spectral coherence
Nf = round(fs/10); hop = max(1, round(Nf/3)); win = hann(Nf).';
idx=1:hop:(N-Nf+1); M=numel(idx);
X=zeros(M,Nf);
for m=1:M
    seg=x(idx(m):idx(m)+Nf-1).*win;
    X(m,:)=fft(seg);
end
Pxx=mean(abs(X).^2,1)+eps;
fbin=fs*(0:Nf-1)/Nf;
posK=find(fbin<=fs/2);
fpos=fbin(posK);

dkMax = round((Nh*ff+ff)*(Nf/fs));
nA=dkMax+1;
CS=zeros(nA,numel(posK));
for idk=1:dkMax
    delta=idk; kk=(delta+1):Nf;
    cross=mean(X(:,kk).*conj(X(:,kk-delta)),1);
    coh=abs(cross).^2 ./ (Pxx(kk).*Pxx(kk-delta)+eps);
    full=zeros(1,Nf); full(kk)=coh;
    CS(idk+1,:)=full(posK);
end
alphaHz = (0:dkMax)*(fs/Nf);

% (2) 1/3-octave band tree
oct3=2^(1/3); bwFactor=2^(1/6)-2^(-1/6);
fc=200; bands=[];
while fc <= fhi
    bw=bwFactor*fc; fl=fc-bw/2; fh=fc+bw/2;
    if fl>=flo && fh<=fs/2
        bands=[bands; fc,bw,fl,fh];
    end
    fc=fc*oct3;
end

% (3)-(4) IES_band and Diagnostic Feature
bestDF=-inf; bestSel=[]; nCand=size(bands,1);
for ib=1:size(bands,1)
    fl=bands(ib,3); fh=bands(ib,4);
    kb=find(fpos>=fl & fpos<=fh);
    if numel(kb)<2, continue; end
    IESb=mean(CS(:,kb),2);
    DFv=0;
    for kh=1:Nh
        lo=(kh-0.5)*ff; hi=(kh+0.5)*ff;
        iaw=find(alphaHz>=lo & alphaHz<=hi);
        if isempty(iaw), continue; end
        faultM=mean(IESb(iaw));
        blo=(kh-0.5)*ff-ff/3; bhi=(kh+0.5)*ff-ff/3;
        ibg=find(alphaHz>=blo & alphaHz<=bhi);
        backM=0;
        if ~isempty(ibg), backM=mean(IESb(ibg)); end
        DFv=DFv+(faultM-backM);
    end
    if DFv>bestDF
        bestDF=DFv; bestSel=bands(ib,:);
    end
end

% (5) demodulate at optimal band
xb=fz_bandpass_mask(fft(x-mean(x),N),N,bestSel(3),bestSel(4),fs);
[A,fq]=fz_amp_env_spectrum(xb,fs);
rr=fz_thnr(A,fq,ff,opts);
[fh_est,pi_]=fz_parabolic_peak(A,fq,ff,rr.delta);
R=struct('method','B8_iesfog','n_candidates',nCand,'selected_band',bestSel,...
    'Kstar',NaN,'alphaStar',NaN,'keep_modes',NaN,...
    'xrec',xb,'A',A,'f',fq,'thnr',rr.thnr,...
    'fhat',fh_est,'pinfo',pi_,'ef_pct',abs(fh_est-ff)/ff*100,...
    'n_unconverged',NaN,'final_converged',NaN,'DF',bestDF);
end
