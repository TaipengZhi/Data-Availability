function o = fz_defaults()
% FZ_DEFAULTS  v2.1 冻结算法的全部固定参数（与冻结书 §8 一一对应）。
% 独立于旧 config_params.m，便于单元测试与复现；测试集不得修改这些值。

o = struct();

% --- 频带盲召回（Gini） ---
o.gini_level_min = 1;
o.gini_level_max = 7;
o.band_candidate_num = 5;          % K_c 取 Gini top-5
o.freq_low = 1000;                 % 载频下限 Hz（与 ff 无关）
o.freq_high_ratio = 0.4;           % 载频上限 = 0.4*fs
o.min_bandwidth = 1000;            % 固定最小带宽 Hz（v2.1 参数附录：由前三阶边带物理跨度 6ff 一次确定，见 fz_param_appendix）；盲筛不使用 ff

% --- THNR / 包络谱 ---
o.harmonic_order = 3;              % H
o.delta_bin_coef = 3;              % δ 至少 3 个 bin
o.delta_ff_coef = 0.02;            % δ 至少 0.02*ff
o.fmin_env = 0;                    % 包络分析下限 Hz（仿真/CWRU）
o.fmax_env = 500;                  % 包络分析上限 Hz（数据集级固定，全方法一致）
o.dc_bin_exclude = 3;              % 直流剔除前 3 个 bin
o.window = 'hann';                 % 分析窗（Hilbert 包络谱对 1s 实信号，主流程矩形；此处保留标识）

% --- VMD ---
o.K_list = [2 3 4 5];
o.alpha_scale = 200;               % α0 = 200*fs/bw
o.alpha_min_ratio = 0.05;
o.alpha_max_ratio = 16;
o.alpha_num = 12;                  % α 对数 12 点
o.vmd_tau = 0;
o.vmd_DC = 0;
o.vmd_init = 1;
o.vmd_tol = 1e-7;
o.vmd_max_iter = 500;              % 所有候选统一 500（取消 K 搜索 50 次的不对齐）

% --- 模态数惩罚 λ_K（标定前占位；正式值由 0hp 标定，网格见下） ---
o.lambda_K = 0.5;                  % 冒烟占位；正式由 fz_calibrate_lambda 在 0hp 选定
o.lambda_grid = [0 0.1 0.25 0.5 1.0 2.0];

% --- 并列规则 ---
o.tie_db = 0.01;                   % THNR 差 <0.01 dB 视为并列

% --- 检出阈值 ---
o.pfa_quantile = 0.95;             % 正常样本 95 分位 => Pfa=5%

% --- 仿真（外圈，物理一致） ---
o.sim_fs = 12000;
o.sim_duration = 1.0;              % N=12000
o.sim_speeds = [600 1200 1800];    % rpm
o.sim_snr_white = [-15 -10 -5 0 5];
o.sim_repeats = 50;
o.f_res = 3600;                    % 主仿真结构共振载频 Hz（落在[3000,4500]带内、非二叉网格边界）；3000 Hz 降为二叉边界压力测试（见 fz_sim_signal 调用时覆盖）
o.f_res_boundary_stress = 3000;   % 二叉边界压力测试用载频（非主仿真）
o.damping_ratio = 0.05;            % β = 2π f_res * damping_ratio
o.impulse_rate = 5;                % 随机冲击出现率 λ_imp 次/秒
o.impulse_R_med = 1.0;             % 干扰/故障冲击中位幅值比
o.impulse_INR_dB = 0;              % 干扰功率比 INR

% --- 6205-2RS 几何（与 CWRU 一致，仿真外圈也采用该几何，统一口径） ---
o.bearing.Z = 9;
o.bearing.d = 7.94e-3;
o.bearing.D = 39.04e-3;
o.bearing.theta = 0;
o.cwru_speeds = [1797 1772 1750 1730];  % 0/1/2/3 hp
end
