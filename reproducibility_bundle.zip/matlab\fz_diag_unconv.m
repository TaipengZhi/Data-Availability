function fz_diag_unconv(outdir)
% Dump Proposed convlog：确认未收敛候选在 (stage,K,alpha) 上的分布
if nargin<1, outdir=fullfile(fileparts(mfilename('fullpath')),'results_white_full'); end
opts=fz_defaults(); fs=opts.sim_fs; N=round(fs*opts.sim_duration);
% 复现 runner 种子：speed=600(sp=1), snr=5dB(sri=5)；取前3个重复
speed=600; snr=5; sp=1; sri=5;
[ff,~]=fz_kinematic_ff(opts.bearing,speed,'BPFO');
fprintf('=== Proposed convlog 未收敛分布诊断 (%g rpm, %g dB, ff=%.2f Hz) ===\n',speed,snr,ff);
aggK=zeros(1,5); nCand=0; nUnc=0;
for r=1:3
    seed=70000+sp*100000+sri*10000+r;
    s=fz_sim_signal(opts,speed,snr,'white',seed);
    R=fz_pipeline(s.x,fs,ff,opts,opts.lambda_K);
    cl=R.convlog;
    fprintf('\n样本%d: K*=%g alpha*=%.1f 最终收敛=%d 总候选=%d 未收敛=%d\n',...
        r,R.Kstar,R.alphaStar,R.final_converged,numel(cl),R.n_unconverged);
    for j=1:numel(cl)
        c=cl{j}; nCand=nCand+1;
        flag=''; if ~c.converged, flag=' <==未收敛'; nUnc=nUnc+1; if c.K>=1&&c.K<=5, aggK(c.K)=aggK(c.K)+1; end; end
        fprintf('   [%s] K=%g alpha=%.1f iter=%g/%g conv=%d%s\n',...
            c.stage,c.K,c.alpha,c.iter,c.max_iter,c.converged,flag);
    end
end
fprintf('\n=== 汇总（3样本）=== 总候选=%d 未收敛=%d r_cand=%.1f%%\n',nCand,nUnc,100*nUnc/nCand);
fprintf('未收敛候选按 K 分布: K=2:%d K=3:%d K=4:%d K=5:%d\n',aggK(2),aggK(3),aggK(4),aggK(5));
fprintf('（若未收敛集中在 K=5 / 极端 alpha，即边缘候选收敛判据过严，非算法失败）\n');
end
