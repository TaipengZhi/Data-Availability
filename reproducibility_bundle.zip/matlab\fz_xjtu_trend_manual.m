%% fz_xjtu_trend_manual.m
%  XJTU-SY 五轴承趋势分析 — 手动验证版
%  在 MATLAB 命令窗口运行：
%    >> cd D:\two_stage_vmd_fggi_project\frozen_v21
%    >> fz_xjtu_trend_manual
%
%  与 fz_xjtu_trend.m 相同参数（500 iter, fs=25600, rpm=2100, CUTN=12000）
%  串行跑、逐样本打印 THNR；跑完后与已有 xjtu_trend.mat 对比一致性
%  预计：Proposed only 约 1-1.5 小时；含 B3 约 1.5-2 小时

clear; clc;
addpath('D:\two_stage_vmd_fggi_project\frozen_v21');
cd('D:\two_stage_vmd_fggi_project\frozen_v21');

opts = fz_defaults();
fs = 25600; rpm = 2100; f_rot = rpm/60;
Z = 9; d = 7.94e-3; D = 39.04e-3;

ff.inner = Z*f_rot/2*(1+d/D);
ff.outer = Z*f_rot/2*(1-d/D);
ff.ball  = D/(2*d)*(1-(d/D)^2)*f_rot;

fprintf('==================================================\n');
fprintf(' XJTU-SY 五轴承趋势分析（手动验证版）\n');
fprintf(' fs=%d  rpm=%d  f_rot=%.2f Hz\n', fs, rpm, f_rot);
fprintf(' BPFI=%.2f  BPFO=%.2f  BSF=%.2f Hz\n', ff.inner, ff.outer, ff.ball);
fprintf(' vmd_max_iter=%d  CUTN=12000  MAXPTS=50\n', opts.vmd_max_iter);
fprintf('==================================================\n');

bearings = {'Bearing1_1','Bearing1_2','Bearing1_3','Bearing1_4','Bearing1_5'};
targets  = {'outer','outer','inner','all','outer'};
methods  = {'Proposed','B3_gini_thnr_no_vmd'};   % 两个都跑；只需 Proposed 可注释第二行
% methods  = {'Proposed'};                          % 快速验证版
nM = numel(methods);
root = 'D:\two_stage_vmd_fggi_project\dataset\xjtu_sy\35Hz12kN';
MAXPTS = 50; CUTN = 12000;

outdir = fullfile(pwd, 'results_xjtu_verify');
if ~exist(outdir,'dir'), mkdir(outdir); end

results = struct();
for bi = 1:numel(bearings)
    bn = bearings{bi}; tgt = targets{bi};
    bdir = fullfile(root, bn);
    files = dir(fullfile(bdir, '*.csv'));
    nums = zeros(numel(files),1);
    for i = 1:numel(files)
        [~,nm] = fileparts(files(i).name);
        nums(i) = str2double(nm);
    end
    [nums,ord] = sort(nums);
    files = files(ord);
    nF = numel(nums);
    fprintf('\n=== %s: %d files, target=%s ===\n', bn, nF, tgt);

    if nF <= MAXPTS, idx = 1:nF;
    else,            idx = unique(round(linspace(1, nF, MAXPTS))); end
    nP = numel(idx);
    fprintf(' 采样 %d 个时间点\n', nP);

    if strcmp(tgt,'all'), tlist = {'inner','outer','ball'};
    else,                 tlist = {tgt}; end

    res = struct();
    res.files = nums(idx); res.targets = tlist; res.nWin = nP;

    for mi = 1:nM
        mname = methods{mi};
        TH = nan(nP, numel(tlist));
        FC = nan(nP,1);
        for pi = 1:nP
            t0 = tic;
            fi = idx(pi);
            fp = fullfile(bdir, files(fi).name);
            try
                sig = fz_xjtu_load_csv(fp, CUTN);
                for ti = 1:numel(tlist)
                    Rm = fz_callone(mname, sig, fs, ff.(tlist{ti}), opts);
                    TH(pi,ti) = Rm.thnr;
                    if isfield(Rm,'final_converged') && ~isempty(Rm.final_converged)
                        FC(pi) = Rm.final_converged;
                    end
                end
                fprintf('  [%s p=%2d/%d] THNR=%s (%.1fs)\n', ...
                    mname, pi, nP, mat2str(round(TH(pi,:),2)), toc(t0));
            catch ME
                fprintf('  [%s p=%2d] ERR: %s\n', mname, pi, ME.message);
            end
        end

        % Spearman rho（时间 vs THNR）
        rho = nan(1, numel(tlist));
        for ti = 1:numel(tlist)
            v = TH(:,ti); ok = isfinite(v);
            if sum(ok) >= 5
                rho(ti) = corr(find(ok), v(ok), 'Type','Spearman');
            end
        end
        nE = max(1, floor(0.2*nP));
        early = median(TH(1:nE,:), 'omitnan');
        late  = median(TH(end-nE+1:end,:), 'omitnan');
        diffEL = late - early;
        failRate = mean(FC == 0, 'omitnan');

        res.(mname) = struct('THNR',TH,'rho',rho,'early',early,'late',late,...
                             'diffEL',diffEL,'failRate',failRate);
        fprintf('  >> %s: rho=[%s]  early=[%s]  late=[%s]  diffEL=[%s]  fail=%.0f%%\n\n', ...
            mname, mat2str(round(rho,3)), mat2str(round(early,2)), ...
            mat2str(round(late,2)), mat2str(round(diffEL,2)), 100*failRate);
    end
    results.(bn) = res;

    % 每个轴承跑完即时存盘
    save(fullfile(outdir, 'xjtu_verify_partial.mat'), 'results','ff','fs','rpm','-v7.3');
end

%% 汇总
fprintf('\n==================================================\n');
fprintf(' 手动验证汇总\n');
fprintf('==================================================\n');
fprintf('%-12s %-8s %-22s %-10s %-10s %-8s\n', ...
    'Bearing','Target','Method','rho','diffEL','fail');
for bi = 1:numel(bearings)
    bn = bearings{bi}; r = results.(bn);
    for mi = 1:nM
        mname = methods{mi}; d = r.(mname);
        fprintf('%-12s %-8s %-22s %-10.3f %-10.2f %-8.0f%%\n', ...
            bn, r.targets{1}, mname, median(d.rho), median(d.diffEL), 100*d.failRate);
    end
end

%% 与已有结果对比
oldFile = fullfile(pwd, 'results_xjtu', 'xjtu_trend.mat');
if exist(oldFile, 'file')
    fprintf('\n--- 与已有 results_xjtu\\xjtu_trend.mat 对比 ---\n');
    O = load(oldFile);
    for bi = 1:numel(bearings)
        bn = bearings{bi};
        if ~isfield(O.results, bn), continue; end
        for mi = 1:nM
            mname = methods{mi};
            if ~isfield(O.results.(bn), mname), continue; end
            oldTH = O.results.(bn).(mname).THNR;
            newTH = results.(bn).(mname).THNR;
            L = min(size(oldTH,1), size(newTH,1));
            if L >= 5
                c = corr(oldTH(1:L), newTH(1:L), 'rows','complete');
                oldRho = O.results.(bn).(mname).rho;
                newRho = results.(bn).(mname).rho;
                fprintf('  %s %-22s: THNR序列相关=%.3f  rho: 旧=%.3f 新=%.3f\n', ...
                    bn, mname, c, median(oldRho), median(newRho));
            end
        end
    end
    fprintf('\n  THNR 序列相关 >0.9 表示结果可复现；0.7-0.9 为随机波动内；<0.7 需检查代码。\n');
end

save(fullfile(outdir, 'xjtu_verify.mat'), 'results','ff','fs','rpm','bearings','targets','methods','-v7.3');
fprintf('\n结果已保存: %s\n', fullfile(outdir, 'xjtu_verify.mat'));
