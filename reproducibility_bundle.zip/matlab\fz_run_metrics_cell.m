function vals = fz_run_metrics_cell(methods, x, fs, ff, opts, Atrue, orb_fl, orb_fh)
% 供 parfor：跑全部方法，返回 cell{thnr,ef,nrm_env,nunc,fc}；Atrue 为方法无关 oracle 真值包络谱
nM=numel(methods); vals=cell(1,nM); fmax=opts.fmax_env;
for m=1:nM
    R=fz_callone(methods{m},x,fs,ff,opts);
    nrm=NaN;
    if ~isempty(R)&&isfield(R,'xrec')&&~isempty(R.xrec)
        [Are,~]=fz_amp_env_spectrum(R.xrec,fs);
        [Ar,~]=fz_norm_env_half(Are,fs,fmax);   % 0-fmax 截断、2-范数归一化，与 oracle 同口径
        L=min(numel(Ar),numel(Atrue));
        nrm=norm(Ar(1:L)-Atrue(1:L),2)/max(norm(Atrue(1:L),2),eps);
    end
    if isstruct(R)&&isfield(R,'n_unconverged'), nu=R.n_unconverged; else, nu=NaN; end
    if isstruct(R)&&isfield(R,'final_converged'), fc=R.final_converged; else, fc=NaN; end
    vals{m}=struct('thnr',R.thnr,'ef',R.ef_pct,'nrm',nrm,'nunc',nu,'fc',fc);
end
end
