%% fz_run_uncertainty_manual.m
%  手动版最小不确定度分析
%  在 MATLAB 命令窗口运行：
%    >> cd D:\two_stage_vmd_fggi_project\frozen_v21
%    >> fz_run_uncertainty_manual
%
%  设计：
%   - 信号固定为 1200rpm / -10dB 白噪，20 个独立样本（与白噪主实验同种子）
%   - Proposed 方法；转速输入误差 -1%/0/+1%；几何参数误差 -0.5%/0/+0.5%
%   - 完整重跑目标引导选择链（不是事后平移评价频率）
%   - 输出：ef（fhat vs 真实 ff_true）、THNR、检测判定（vs 白噪标定 Tm）
%   - 9 组参数 × 20 样本 = 180 次 Proposed；500 iter 下约 2 小时

clear; clc;
addpath('D:\two_stage_vmd_fggi_project\frozen_v21');
cd('D:\two_stage_vmd_fggi_project\frozen_v21');

opts = fz_defaults();
opts.vmd_max_iter = 500;          % 与压力测试一致
fs = opts.sim_fs;

speed = 1200; snr = -10; nRep = 20;
outdir = fullfile(pwd, 'results_uncertainty');
if ~exist(outdir,'dir'), mkdir(outdir); end

%% 真实运动学参数
b = opts.bearing;
[ff_true, ~] = fz_kinematic_ff(b, speed, 'BPFO');
fprintf('==================================================\n');
fprintf(' 最小不确定度分析\n');
fprintf(' speed=%g rpm, snr=%g dB, nRep=%d, vmd_max_iter=%d\n', speed, snr, nRep, opts.vmd_max_iter);
fprintf(' ff_true(BPFO) = %.3f Hz\n', ff_true);
fprintf('==================================================\n');

%% 加载白噪主实验 1200rpm 标定阈值（Proposed = methods{1}）
whiteDir = fullfile(pwd, 'results_white_full');
W = load(fullfile(whiteDir, 'calib_1200rpm.mat'));
Tm_Proposed = W.Tm(1);
fprintf(' 白噪标定 Tm(Proposed) = %.3f dB\n\n', Tm_Proposed);

%% 参数扰动网格
dSpeed = [-0.01, 0, +0.01];
dGeom  = [-0.005, 0, +0.005];
speedLbl = {'-1%', '0', '+1%'};
geomLbl  = {'-0.5%', '0', '+0.5%'};

%% 预生成 20 个固定信号（用与白噪主实验相同的种子）
fprintf('--- 预生成 %d 个固定白噪信号 ---\n', nRep);
SIG = cell(nRep, 1);
for r = 1:nRep
    seed = 70000 + 2*100000 + 2*10000 + r;   % 与白噪主实验 1200rpm/-10dB 同种子
    s = fz_sim_signal(opts, speed, snr, 'white', seed);
    SIG{r} = s.x;
end
fprintf(' 完成。\n\n');

%% 逐参数组合运行
res = struct();
for si = 1:3
    for gi = 1:3
        speed_in = speed * (1 + dSpeed(si));
        b_in = b;
        b_in.d = b.d * (1 + dGeom(gi));
        b_in.D = b.D * (1 + dGeom(gi));
        [ff_in, ~] = fz_kinematic_ff(b_in, speed_in, 'BPFO');
        tag = sprintf('sp%d_ge%d', si, gi);

        fprintf('----- 转速%s 几何%s: ff_in=%.3f Hz (偏差%+.2f%%) -----\n', ...
            speedLbl{si}, geomLbl{gi}, ff_in, 100*(ff_in/ff_true - 1));

        ef    = nan(nRep,1);
        thnr  = nan(nRep,1);
        det   = nan(nRep,1);
        fc    = nan(nRep,1);
        fhat  = nan(nRep,1);

        for r = 1:nRep
            t0 = tic;
            R = fz_callone('Proposed', SIG{r}, fs, ff_in, opts);
            ef(r)   = abs(R.fhat - ff_true) / ff_true * 100;   % vs 真实 ff
            thnr(r) = R.thnr;
            det(r)  = R.thnr > Tm_Proposed;
            fc(r)   = R.final_converged;
            fhat(r) = R.fhat;
            fprintf('  r=%2d: fhat=%6.2f Hz  ef=%6.3f%%  THNR=%6.2f dB  det=%d  (%.1fs)\n', ...
                r, R.fhat, ef(r), R.thnr, det(r), toc(t0));
        end

        res.(tag) = struct( ...
            'speed_in', speed_in, 'ff_in', ff_in, ...
            'dSpeed', dSpeed(si), 'dGeom', dGeom(gi), ...
            'ef', ef, 'thnr', thnr, 'det', det, 'fc', fc, 'fhat', fhat, ...
            'efMed', median(ef), 'thnrMed', median(thnr), ...
            'detRate', mean(det), 'fcFail', mean(fc == 0));

        fprintf('  >> efMed=%.3f%%  thnrMed=%.2f dB  detRate=%.0f%%  fcFail=%.0f%%\n\n', ...
            median(ef), median(thnr), 100*mean(det), 100*mean(fc==0));
    end
end

%% 保存
save(fullfile(outdir, 'uncertainty.mat'), ...
    'res', 'ff_true', 'Tm_Proposed', 'speed', 'snr', 'nRep', ...
    'dSpeed', 'dGeom', 'speedLbl', 'geomLbl');

%% 汇总表
fprintf('\n==================================================\n');
fprintf(' 不确定度分析汇总（Proposed, 1200rpm/-10dB, n=%d）\n', nRep);
fprintf('==================================================\n');
fprintf('%-10s %-10s %-12s %-12s %-10s %-10s\n', ...
    '转速误差', '几何误差', 'ff_in(Hz)', 'efMed(%)', 'THNRMed', 'detRate');
for si = 1:3
    for gi = 1:3
        tag = sprintf('sp%d_ge%d', si, gi);
        d = res.(tag);
        fprintf('%-10s %-10s %-12.2f %-12.3f %-10.2f %-10.0f%%\n', ...
            speedLbl{si}, geomLbl{gi}, d.ff_in, d.efMed, d.thnrMed, 100*d.detRate);
    end
end
fprintf('\n结果已保存: %s\n', fullfile(outdir, 'uncertainty.mat'));
