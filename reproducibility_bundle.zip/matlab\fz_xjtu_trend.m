﻿function fz_xjtu_trend(outdir)
if nargin<1, outdir=fullfile(fileparts(mfilename('fullpath')),'results_xjtu'); end
if ~exist(outdir,'dir'), mkdir(outdir); end
opts=fz_defaults(); opts.lambda_K=0;
fs=25600; rpm=2100; f_rot=rpm/60;
Z=8; d=7.92e-3; D=34.55e-3;  % LDK UER204 (XJTU-SY cond.1), was 6205
ff.inner=Z*f_rot/2*(1+d/D);
ff.outer=Z*f_rot/2*(1-d/D);
ff.ball=D/(2*d)*(1-(d/D)^2)*f_rot;
fprintf('ff: BPFI=%.2f BPFO=%.2f BSF=%.2f Hz\n',ff.inner,ff.outer,ff.ball);
bearings={'Bearing1_1','Bearing1_2','Bearing1_3','Bearing1_4','Bearing1_5'};
targets={'outer','outer','outer','skip','innerouter'};
methods={'Proposed','B3_gini_thnr_no_vmd'};
nM=numel(methods);
root='D:\two_stage_vmd_fggi_project\dataset\xjtu_sy\35Hz12kN';
MAXPTS=50; CUTN=12000;
results=struct();
for bi=1:numel(bearings)
 bn=bearings{bi}; tgt=targets{bi};
 if strcmp(tgt,'skip'); fprintf('%% skip %s (cage fault, no target freq)\n',bn); continue; end
 bdir=fullfile(root,bn);
 files=dir(fullfile(bdir,'*.csv'));
 nums=zeros(numel(files),1);
 for i=1:numel(files), [~,nm]=fileparts(files(i).name); nums(i)=str2double(nm); end
 [nums,ord]=sort(nums); files=files(ord);
 nF=numel(nums);
 fprintf('\n=== %s: %d files, target=%s ===\n',bn,nF,tgt);
 if nF<=MAXPTS, idx=1:nF; else
  idx=unique(round(linspace(1,nF,MAXPTS)));
 end
 nP=numel(idx);
 fprintf('sampled %d time points, cut to %d samples\n',nP,CUTN);
 if strcmp(tgt,'all'), tlist={'inner','outer','ball'};
  elseif strcmp(tgt,'innerouter'), tlist={'inner','outer'};
  else, tlist={tgt}; end
 res=struct();
 res.files=nums(idx); res.targets=tlist; res.nWin=nP;
 for mi=1:nM
  mname=methods{mi};
  TH=nan(nP,numel(tlist)); FC=nan(nP,1); ERR=cell(nP,1);
  parfor pi=1:nP
   rng(10000+pi);
   fi=idx(pi); fp=fullfile(bdir,files(fi).name);
   trow=nan(1,numel(tlist)); fval=NaN; emsg='' ;
   try
    sig=fz_xjtu_load_csv(fp,CUTN);
    for ti=1:numel(tlist)
     try
      Rm=fz_callone(mname,sig,fs,ff.(tlist{ti}),opts);
      trow(ti)=Rm.thnr;
      if isfield(Rm,'final_converged')&&~isempty(Rm.final_converged), fval=Rm.final_converged; end
     catch ME
      emsg=sprintf('%s[ti%d] %s ',emsg,ti,ME.message);
     end
    end
   catch ME
    emsg=sprintf('[load] %s',ME.message);
   end
   TH(pi,:)=trow; FC(pi)=fval; ERR{pi}=emsg;
  end
  for pi=1:nP, if ~isempty(ERR{pi}), fprintf('  [%s p=%d] %s\n',mname,pi,ERR{pi}); end; end
  rho=nan(1,numel(tlist));
  for ti=1:numel(tlist)
   v=TH(:,ti); ok=isfinite(v);
   if sum(ok)>=5, rho(ti)=corr(find(ok),v(ok),'Type','Spearman'); end
  end
  nE=max(1,floor(0.2*nP));
  early=median(TH(1:nE,:),'omitnan');
  late=median(TH(end-nE+1:end,:),'omitnan');
  diffEL=late-early;
  failRate=mean(FC==0,'omitnan');
  res.(mname)=struct('THNR',TH,'rho',rho,'early',early,'late',late,'diffEL',diffEL,'failRate',failRate);
  fprintf('  %s: rho=[%s] diffEL=[%s] fail=%.0f%%\n',mname,...
    num2str(rho,'%.3f '),num2str(diffEL,'%.2f '),100*failRate);
 end
 results.(bn)=res;
 save(fullfile(outdir,'xjtu_trend_partial.mat'),'results','ff','fs','rpm','-v7.3');
end
fprintf('\n\n========== XJTU-SY TREND SUMMARY ==========\n');
fprintf('%-12s %-8s %-22s %-12s %-12s %-8s\n','Bearing','Target','Method','rho(med)','diffEL(med)','fail');
for bi=1:numel(bearings)
 bn=bearings{bi}; if ~isfield(results,bn); fprintf('%-12s (skipped, no target)\n',bn); continue; end
 r=results.(bn);
 for mi=1:nM
  mname=methods{mi}; d=r.(mname);
  fprintf('%-12s %-8s %-22s %-12.3f %-12.2f %.0f%%\n',...
    bn,r.targets{1},mname,median(d.rho),median(d.diffEL),100*d.failRate);
 end
end
save(fullfile(outdir,'xjtu_trend.mat'),'results','ff','fs','rpm','bearings','targets','methods','-v7.3');
fprintf('\nSaved xjtu_trend.mat\n');
end
