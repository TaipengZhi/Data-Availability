﻿function fz_cwru_audit_3hp(outdir)
if nargin<1, outdir=fullfile(fileparts(mfilename('fullpath')),'results_cwru'); end
opts=fz_defaults(); fs=12000; win=12000; root='D:\two_stage_vmd_fggi_project\dataset\CRWU';
methods={'Proposed','B2_gini_only','B3_gini_thnr_no_vmd','B4_fixed_vmd','B5_fixed_vmd_thnr','B1','B6'};
cnames={'inner','outer','ball'};
S=load(fullfile(outdir,'cwru_calib.mat')); T=S.T; lam=S.lam; opts.lambda_K=lam;
fprintf('lambdaK=%g\n',lam);
ll=3; speed=1730; fr=speed/60; Z=9; d=7.94e-3; D=39.04e-3;
ff.inner=Z*fr/2*(1+d/D); ff.outer=Z*fr/2*(1-d/D); ff.ball=D/(2*d)*(1-(d/D)^2)*fr;
nM=numel(methods);
fprintf('=== 3hp (ff: inner=%.2f outer=%.2f ball=%.2f) ===\n',ff.inner,ff.outer,ff.ball);
fpN=fullfile(root,'Normal Baseline',sprintf('normal_%d.mat',ll));
WN=loadcw(fpN,fs,win); nN=size(WN,1);
fprintf('normal_%d: %d windows\n',ll,nN);
normalTHNR=nan(nN,nM,3);
for k=1:nN
 t0=tic;
 for ci=1:3
  for m=1:nM
   try
    Rm=fz_callone(methods{m},WN(k,:),fs,ff.(cnames{ci}),opts);
    normalTHNR(k,m,ci)=Rm.thnr;
   catch ME
    fprintf('  [normal k=%d %s %s] %s\n',k,cnames{ci},methods{m},ME.message);
   end
  end
 end
 fprintf('  normal window %d/%d done (%.1fs)\n',k,nN,toc(t0));
 if mod(k,10)==0, save(fullfile(outdir,'cwru_audit_3hp_partial.mat'),'normalTHNR','-v7.3'); end
end
faultTHNR=struct(); faultEf=struct();
for ti=1:3
 c=cnames{ti}; fp=getfile(root,c,ll);
 W=loadcw(fp,fs,win); nF=size(W,1);
 th=nan(nF,nM); efv=nan(nF,nM);
 fprintf('%s: %d windows\n',c,nF);
 for k=1:nF
  t0=tic;
  for m=1:nM
   try
    Rm=fz_callone(methods{m},W(k,:),fs,ff.(c),opts);
    th(k,m)=Rm.thnr; efv(k,m)=Rm.ef_pct;
   catch ME
    fprintf('  [fault %s k=%d %s] %s\n',c,k,methods{m},ME.message);
   end
  end
  fprintf('  %s window %d/%d done (%.1fs)\n',c,k,nF,toc(t0));
 end
 faultTHNR.(c)=th; faultEf.(c)=efv;
end
fprintf('\n=== 3hp separation ===\n');
fprintf('%-6s %-22s %8s %8s %8s %8s %8s %8s\n','fault','method','medF','medN','dTHNR','AUROC','Cliffd','medEf');
for ti=1:3
 c=cnames{ti}; th=faultTHNR.(c); efv=faultEf.(c);
 for m=1:nM
  fv=th(:,m); nv=squeeze(normalTHNR(:,m,ti)); fv=fv(isfinite(fv)); nv=nv(isfinite(nv));
  if isempty(fv)||isempty(nv), continue; end
  medF=median(fv); medN=median(nv); dT=medF-medN;
  gt=0; eq=0; for i=1:numel(fv), for j=1:numel(nv), if fv(i)>nv(j), gt=gt+1; elseif fv(i)==nv(j), eq=eq+1; end, end, end
  auroc=(gt+0.5*eq)/(numel(fv)*numel(nv));
  cd=(gt-(numel(fv)*numel(nv)-gt-eq))/(numel(fv)*numel(nv));
  fprintf('%-6s %-22s %8.2f %8.2f %8.2f %8.3f %8.3f %8.3f\n',...
    c,methods{m},medF,medN,dT,auroc,cd,median(efv(:,m),'omitnan'));
 end
end
audit3hp=struct('load',ll,'speed',speed,'ff',ff,'normalTHNR',normalTHNR,...
  'faultTHNR',faultTHNR,'faultEf',faultEf);
save(fullfile(outdir,'cwru_audit_3hp.mat'),'audit3hp','T','lam','methods','-v7.3');
fprintf('\nsaved cwru_audit_3hp.mat\n');
end
function fp=getfile(root,c,ll)
switch c
 case 'inner', fp=fullfile(root,'12k Drive End Bearing Fault Data','Inner Race','0007',sprintf('IR007_%d.mat',ll));
 case 'ball',  fp=fullfile(root,'12k Drive End Bearing Fault Data','Ball','0007',sprintf('B007_%d.mat',ll));
 case 'outer', fp=fullfile(root,'12k Drive End Bearing Fault Data','Outer Race','Centered','0007',sprintf('OR007@6_%d.mat',ll));
end
end
function W=loadcw(fp,fs,win)
 if ~exist(fp,'file'), error('missing %s',fp); end
 ld=load(fp); vn=fieldnames(ld); di=find(contains(vn,'_DE_time'),1);
 sig=ld.(vn{di}); sig=sig(:)'; n=floor(length(sig)/win);
 W=zeros(n,win);
 for k=1:n, W(k,:)=sig((k-1)*win+1:k*win); end
end
