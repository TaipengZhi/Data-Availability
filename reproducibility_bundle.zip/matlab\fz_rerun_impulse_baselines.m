%% fz_rerun_impulse_baselines.m
%  用 500 iter 重跑冲击噪声下 B2-B6（Proposed 已用 500 iter 跑完，保留）
%  在 MATLAB 命令窗口运行：
%    >> cd D:\two_stage_vmd_fggi_project\frozen_v21
%    >> fz_rerun_impulse_baselines
%  预计约 45-60 分钟

clear; clc;
addpath('D:\two_stage_vmd_fggi_project\frozen_v21');
cd('D:\two_stage_vmd_fggi_project\frozen_v21');

opts = fz_defaults();            % 默认 500 iter
fs = opts.sim_fs; N = round(fs*opts.sim_duration);
speed = 1200; snr = -10; nRep = 50; nCal = 50; nVal = 50;
[ff, ~] = fz_kinematic_ff(opts.bearing, speed, 'BPFO');
orb_fl = opts.f_res - 750;
orb_fh = opts.f_res + 750;
outdir = fullfile(pwd, 'results_pressure');

fprintf('==================================================\n');
fprintf(' 重跑冲击 B2-B6 (500 iter)，Proposed 保留\n');
fprintf(' speed=%g  ff=%.2f  snr=%g  vmd_max_iter=%d\n', speed, ff, snr, opts.vmd_max_iter);
fprintf('==================================================\n');

methods = {'Proposed','B2_gini_only','B3_gini_thnr_no_vmd','B4_fixed_vmd','B5_fixed_vmd_thnr','B1','B6'};
nM = numel(methods);

%% 加载现有标定（保留 Proposed 的 Tm/Pfa）
calOld = load(fullfile(outdir, 'calib_impulse.mat'));
Tm = calOld.Tm; Pfa = calOld.Pfa; PfaCI = calOld.PfaCI;
calTh = calOld.calTh; valTh = calOld.valTh;

%% 只重跑 B2-B6（index 2-7）
for mi = 2:nM
    mname = methods{mi};
    fprintf('\n--- [%d/7] %s 标定 50 ---\n', mi, mname);
    for i = 1:nCal
        t0 = tic;
        seed = 90000 + 2*100000 + i;
        x = fz_pure_noise('impulse', N, fs, opts, seed);
        R = fz_callone(mname, x, fs, ff, opts);
        calTh(i,mi) = R.thnr;
        fprintf('  标定 %d/50 (%.1fs)\n', i, toc(t0));
    end
    Tm(mi) = quantile_rank_single(calTh(:,mi));

    fprintf('\n--- [%d/7] %s 验证 50 ---\n', mi, mname);
    for i = 1:nVal
        t0 = tic;
        seed = 80000 + 2*100000 + i;
        x = fz_pure_noise('impulse', N, fs, opts, seed);
        R = fz_callone(mname, x, fs, ff, opts);
        valTh(i,mi) = R.thnr;
        fprintf('  验证 %d/50 (%.1fs)\n', i, toc(t0));
    end
    Pfa(mi) = mean(valTh(:,mi) > Tm(mi));
    PfaCI(mi,:) = wilson(sum(valTh(:,mi) > Tm(mi)), nVal);
    fprintf('  -> Tm=%.3f  Pfa=%.2f\n', Tm(mi), Pfa(mi));
end

%% 保存标定
calNew = calOld;
calNew.Tm = Tm; calNew.Pfa = Pfa; calNew.PfaCI = PfaCI;
calNew.calTh = calTh; calNew.valTh = valTh;
calNew.vmd_max_iter = 500;
save(fullfile(outdir, 'calib_impulse.mat'), '-struct', 'calNew');
fprintf('\n已更新 calib_impulse.mat\n');

%% 重跑 B2-B6 故障 50
chkOld = load(fullfile(outdir, 'pressure_impulse_1200rpm_-10dB.mat'));
thnrAll = chkOld.thnr; efAll = chkOld.ef;
nrmAll = chkOld.nrm; fcAll = chkOld.fc;

for mi = 2:nM
    mname = methods{mi};
    fprintf('\n--- [%d/7] %s 故障 50 ---\n', mi, mname);
    for r = 1:nRep
        t0 = tic;
        seed = 100000 + 2*100000 + r;
        s = fz_sim_signal(opts, speed, snr, 'impulse', seed);
        [Atrue,~] = fz_oracle_true(s.fault, fs, orb_fl, orb_fh, opts.fmax_env);
        vals = fz_run_metrics_cell({mname}, s.x, fs, ff, opts, Atrue, orb_fl, orb_fh);
        thnrAll(r,mi) = vals{1}.thnr;
        efAll(r,mi)   = vals{1}.ef;
        nrmAll(r,mi)  = vals{1}.nrm;
        fprintf('  故障 %d/50: THNR=%.2f ef=%.3f%% nrm=%.3f (%.1fs)\n', ...
            r, thnrAll(r,mi), efAll(r,mi), nrmAll(r,mi), toc(t0));
    end
end

%% 保存
Pd_new = mean(thnrAll > Tm, 1);
chkNew = chkOld;
chkNew.thnr = thnrAll; chkNew.ef = efAll; chkNew.nrm = nrmAll;
chkNew.Tm = Tm; chkNew.Pfa = Pfa; chkNew.PfaCI = PfaCI; chkNew.Pd = Pd_new;
chkNew.vmd_max_iter_all = 500;
save(fullfile(outdir, 'pressure_impulse_1200rpm_-10dB.mat'), '-struct', 'chkNew');

%% 汇总
fprintf('\n==================================================\n');
fprintf(' 冲击全部方法 (500 iter) 重跑完成\n');
fprintf('==================================================\n');
fprintf('%-22s %-8s %-10s %-10s %-8s\n','方法','Pd','efMed(%)','nrmMed','Pfa');
for mi = 1:nM
    fprintf('%-22s %-8.2f %-10.3f %-10.3f %-8.2f\n', ...
        methods{mi}, Pd_new(mi), median(efAll(:,mi)), median(nrmAll(:,mi)), Pfa(mi));
end

%% ===== 局部函数 =====
function T = quantile_rank_single(X)
    X = X(~isnan(X)); n = numel(X); k = ceil(0.95*n);
    T = sort(X); T = T(k);
end

function ci = wilson(k, n)
    z = 1.96; p_hat = k/n; den = 1 + z^2/n;
    ctr = (p_hat + z^2/(2*n))/den;
    hw  = z*sqrt(p_hat*(1-p_hat)/n + z^2/(4*n^2))/den;
    ci  = [ctr-hw, ctr+hw];
end
