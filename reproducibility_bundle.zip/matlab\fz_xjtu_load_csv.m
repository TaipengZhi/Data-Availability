﻿function sig = fz_xjtu_load_csv(fp, CUTN)
fid=fopen(fp,'r');
C=textscan(fid,'%f %f','Delimiter',',','HeaderLines',1);
fclose(fid);
sig=C{1}; sig=sig(:)';
if length(sig)>CUTN, sig=sig(1:CUTN); end
end
